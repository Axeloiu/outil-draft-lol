import json, math, collections, numpy as np
G = json.load(open('pro2026.json')); RC = json.load(open('rolecnt.json'))
todo = json.load(open('/tmp/lanepairs.json')); wr = json.load(open('/tmp/prolanewr.json'))
ADV = {(r, a, b): (w - 0.5) * 100 for (r, a, b), w in zip(todo, wr)}  # avantage de a contre b, en points
ORD = {'B': [1, 4, 5, 8, 9], 'R': [2, 3, 6, 7, 10]}
ROLES = ['top', 'jgl', 'mid', 'adc', 'sup']
obs = []  # (rôle, choisi, adversaire, indisponibles, tier, position)
for g in G:
    pos = {}
    for t in 'BR':
        for k, (c, r) in enumerate(g[t]): pos[(t, r)] = (ORD[t][k], c)
    allbans = {b for t in g['bans'] for b in t if b}
    for r in ROLES:
        (pb, cb), (pr_, cr) = pos[('B', r)], pos[('R', r)]
        late, early = (('B', cb, pb), ('R', cr, pr_)) if pb > pr_ else (('R', cr, pr_), ('B', cb, pb))
        taken = set(allbans) | {c for (t, rr), (p, c) in pos.items() if p < late[2]}
        obs.append((r, late[1], early[1], taken, g['tier'], late[2]))
def ll(k, sub):
    s = 0
    for r, e, a, taken, *_ in sub:
        C = RC[r]; num = None; den = 0
        for c, n in C.items():
            c = int(c)
            if c in taken and c != e: continue
            u = math.log(n) + k * ADV.get((r, c, a), 0)
            den += math.exp(u)
            if c == e: num = u
        s += num - math.log(den)
    return s
def best(sub, grid=np.arange(-0.02, 0.21, 0.01)):
    v = [(ll(k, sub), k) for k in grid]; m = max(v)
    # intervalle à 95 % : log-vraisemblance à moins de 1,92 du maximum
    ok = [k for L, k in v if L >= m[0] - 1.92]
    return round(m[1], 3), (round(min(ok), 3), round(max(ok), 3)), len(sub)
#print('tout', best(obs))
#print('tier 1', best([o for o in obs if o[4] == 1]))
#print('tier 2', best([o for o in obs if o[4] == 2]))
#for r in ROLES: print(r, best([o for o in obs if o[0] == r]))
#for p in [(1, 5), (6, 8), (9, 10)]: print('position', p, best([o for o in obs if p[0] <= o[5] <= p[1]]))
# placebo : le premier laner « contre » un adversaire qu'il ne connaissait pas encore
pl = []
for g in G:
    pos = {}
    for t in 'BR':
        for k, (c, r) in enumerate(g[t]): pos[(t, r)] = (ORD[t][k], c)
    allbans = {b for t in g['bans'] for b in t if b}
    for r in ROLES:
        (pb, cb), (pr_, cr) = pos[('B', r)], pos[('R', r)]
        early, late = (('B', cb, pb), ('R', cr, pr_)) if pb < pr_ else (('R', cr, pr_), ('B', cb, pb))
        taken = set(allbans) | {c for (t, rr), (p, c) in pos.items() if p < early[2]}
        pl.append((r, early[1], late[1], taken, g['tier'], early[2]))
print('placebo (premier laner vs adversaire inconnu)', best(pl))
