# Mesures pros sur les données réorientées (bleu / rouge) : côté, rôles par position, counter-pick (κ), flex picks.
# Usage : python3 mesures_pro.py pro_games.json lanepairs.json lanevals.json sortie.json
import json, sys, collections, numpy as np
from scipy.optimize import minimize
G = json.load(open(sys.argv[1])); LP = json.load(open(sys.argv[2])); LV = json.load(open(sys.argv[3]))
V = {(r, a, b): v for (r, a, b), v in zip(LP, LV) if v}
ROLES = ['top', 'jgl', 'mid', 'adc', 'sup']
ORD = {'B': [1, 4, 5, 8, 9], 'R': [2, 3, 6, 7, 10]}
out = {}
# --- côté
y = np.array([g['w'] for g in G]); tier = np.array([g['tier'] for g in G])
for k in (1, 2):
    m = tier == k; out[f'bleu_tier{k}'] = [round(y[m].mean(), 4), int(m.sum())]
    print(f'tier {k} : le bleu gagne {y[m].mean()*100:.1f} % (± {196*np.sqrt(.25/m.sum()):.1f}) sur {m.sum()} parties')
# --- rôles par position
PR = [collections.Counter() for _ in range(10)]
for g in G:
    for t in 'BR':
        for k, (c, r) in enumerate(g[t]): PR[ORD[t][k] - 1][r] += 1
out['posRole'] = [[PR[i][r] for r in ROLES] for i in range(10)]
print('rôles par position (top, jgl, mid, adc, sup) :', out['posRole'])
# --- κ : logit conditionnel sur le choix du laner qui pick après son adversaire de lane
RC = {r: collections.Counter() for r in ROLES}
for g in G:
    for t in 'BR':
        for c, r in g[t]: RC[r][c] += 1
CAND = {r: np.array(sorted(RC[r])) for r in ROLES}
LOGN = {r: np.log(np.array([RC[r][c] for c in CAND[r]], float)) for r in ROLES}
def bans_before(g, p):
    return {b for t in g['bans'] for b in (t[:3] if p <= 6 else t) if b}
obs = []
for g in G:
    pos = {}
    for t in 'BR':
        for k, (c, r) in enumerate(g[t]): pos[(t, r)] = (ORD[t][k], c)
    for r in ROLES:
        (pb, cb), (pr_, cr) = pos[('B', r)], pos[('R', r)]
        late, early = ((cb, pb), (cr, pr_)) if pb > pr_ else ((cr, pr_), (cb, pb))
        taken = bans_before(g, late[1]) | {c for (t, rr), (p, c) in pos.items() if p < late[1]}
        obs.append(dict(r=r, c=late[0], e=early[0], p=late[1], taken=taken, tier=g['tier'], early_p=early[1]))
def design(o, e=None):
    r = o['r']; e = o['e'] if e is None else e; C = CAND[r]
    ok = np.array([(c not in o['taken']) or c == o['c'] for c in C])
    raw = np.array([V.get((r, c, e), [0] * 5)[0] for c in C]); res = np.array([V.get((r, c, e), [0] * 5)[1] for c in C])
    st = np.array([V.get((r, c, e), [0, 0, 0])[2] if (r, c, e) in V else 0 for c in C])
    ch = int(np.where(C == o['c'])[0][0]) if o['c'] in set(C) else None
    return ok, LOGN[r], raw, res, st, ch
DES = [design(o) for o in obs]
def fitk(idx, cols, des=DES):
    data = [(des[i][0], des[i][1], np.column_stack([des[i][k] for k in cols]), des[i][5]) for i in idx if des[i][5] is not None]
    def nll(b):
        s = 0
        for ok, ln, X, ch in data:
            u = ln[ok] + X[ok] @ b; m = u.max(); s -= (ln[ch] + X[ch] @ b) - (m + np.log(np.exp(u - m).sum()))
        return s
    r = minimize(nll, np.zeros(len(cols)), method='BFGS')
    # erreurs-types par la hessienne numérique (information observée)
    k = len(cols); h = 1e-3; H = np.zeros((k, k)); f0 = nll(r.x)
    for i in range(k):
        for j in range(i, k):
            ei = np.eye(k)[i] * h; ej = np.eye(k)[j] * h
            H[i, j] = H[j, i] = (nll(r.x + ei + ej) - nll(r.x + ei) - nll(r.x + ej) + f0) / (h * h)
    se = np.sqrt(np.diag(np.linalg.inv(H)))
    return [(round(a, 4), round(1.96 * s, 4)) for a, s in zip(r.x, se)], len(data)
K_RAW, K_RES, K_STR = 2, 3, 4
sel = lambda f: [i for i, o in enumerate(obs) if f(o)]
res = {}
for lab, f in [('picks 1-5', lambda o: o['p'] <= 5), ('picks 6-8', lambda o: 6 <= o['p'] <= 8), ('picks 9-10', lambda o: o['p'] >= 9), ('tout', lambda o: True)] + \
        [(r, (lambda rr: lambda o: o['r'] == rr)(r)) for r in ROLES]:
    ix = sel(f)
    a, n = fitk(ix, [K_RAW]); b, _ = fitk(ix, [K_RES, K_STR])
    res[lab] = {'n': n, 'kappa_brut': a[0], 'kappa_residuel': b[0], 'force_solo': b[1]}
    print(f'{lab:11s} n={n:5d}  κ sur duel brut {a[0][0]:+.3f} ± {a[0][1]:.3f}   |   κ sur duel résiduel {b[0][0]:+.3f} ± {b[0][1]:.3f}, force solo {b[1][0]:+.3f} ± {b[1][1]:.3f}', flush=True)
out['kappa'] = res
# placebo propre : même modèle, mais l'adversaire de lane remplacé par le champion d'une autre partie au même rôle
rng = np.random.default_rng(3)
pl = []
for r in ROLES:
    ix = [i for i, o in enumerate(obs) if o['r'] == r]; perm = rng.permutation(ix)
    for i, j in zip(ix, perm):
        o = dict(obs[i]); fake = obs[j]['e']
        if fake == o['c']: continue
        pl.append(design(o, fake))
b, n = fitk(range(len(pl)), [K_RES, K_STR], des=pl)
print(f'placebo (adversaire tiré dans une autre partie) n={n} : κ résiduel {b[0][0]:+.3f} ± {b[0][1]:.3f}')
out['placebo'] = b[0]
# --- flex : pénalité d'exposition au counter, comparée à l'intérieur de chaque champion
RS = collections.defaultdict(collections.Counter)
for g in G:
    for t in 'BR':
        for c, r in g[t]: RS[c][r] += 1
rows = []
for g in G:
    pos = {}
    for t in 'BR':
        for k, (c, r) in enumerate(g[t]): pos[(t, r)] = (ORD[t][k], c)
    for t in 'BR':
        o = 'R' if t == 'B' else 'B'
        mine = {p_: r for (tt, r), (p_, c) in pos.items() if tt == t}
        for k, (c, r) in enumerate(g[t]):
            p = ORD[t][k]; po, co = pos[(o, r)]
            tot = sum(RS[c].values())
            if tot < 20: continue
            roles_c = {rr for rr, n in RS[c].items() if n / tot >= 0.2}
            open_now = {rr for rr in ROLES if not any(p_ < p and mine[p_] == rr for p_ in mine)}
            amb_now = len(roles_c & open_now) >= 2
            v = V.get((r, c, co)); win = (g['w'] == 1) == (t == 'B')
            rows.append((f'{c}|{r}', po > p, amb_now, v[1] if v else 0.0, float(win), p))
cr = np.array([x[0] for x in rows]); E = np.array([x[1] for x in rows], float); A = np.array([x[2] for x in rows], float)
Y1 = np.array([x[3] for x in rows]); Y2 = np.array([x[4] for x in rows])
def within(x):
    out_ = x.copy(); idx = collections.defaultdict(list)
    for i, k in enumerate(cr): idx[k].append(i)
    for k, ii in idx.items(): out_[ii] -= x[ii].mean()
    return out_
X = np.column_stack([E, E * A, A]); Xw = np.column_stack([within(c) for c in X.T])
flexres = {}
for nm, Yv in [('duel résiduel (pts)', Y1), ('victoire (pts)', Y2 * 100)]:
    Yw = within(Yv); b, *_ = np.linalg.lstsq(Xw, Yw, rcond=None); e = Yw - Xw @ b
    se = np.sqrt(np.diag(np.linalg.inv(Xw.T @ Xw)) * e.var() * len(e) / (len(e) - len(set(cr)) - 3))
    flexres[nm] = {'exposé (mono)': [round(b[0], 3), round(1.96 * se[0], 3)], 'en plus si rôle ambigu au moment du pick': [round(b[1], 3), round(1.96 * se[1], 3)]}
    print(f'flex, {nm} : exposé au counter {b[0]:+.2f} ± {1.96*se[0]:.2f} ; différence si le rôle était ambigu au moment du pick {b[1]:+.2f} ± {1.96*se[1]:.2f}  (n={len(e)}, picks ambigus exposés {int((E*A).sum())})')
out['flex'] = flexres
json.dump(out, open(sys.argv[4], 'w'), ensure_ascii=False, indent=1)
