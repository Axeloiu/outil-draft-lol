# leaguepedia-2026-cotes.json (orienté bleu / rouge) -> pro2026_games.json (ids de champions de l'outil, équipes, heure exacte)
# + lanepairs.json (couples de duels pour lanepairs.js)
import json, collections, unicodedata, re, sys
src, outil, out_games, out_pairs = sys.argv[1:5]
G = json.load(open(src))
D = json.loads(open(outil + '/data.js').read()[len('const DATA='):-2])
norm = lambda s: re.sub(r'[^a-z]', '', unicodedata.normalize('NFKD', s).lower())
ID = {norm(c['n']): c['id'] for c in D['champs']}
ID.update({norm(c.get('k', '')): c['id'] for c in D['champs'] if c.get('k')})
alias = {'nunuwillump': 'nunu', 'wukong': 'monkeyking', 'renataglasc': 'renata'}
RM = {'Top': 'top', 'Jungle': 'jgl', 'Mid': 'mid', 'Bot': 'adc', 'Support': 'sup'}
out = []; drop = collections.Counter()
for o, d, p, w, tier, picks, bans, gid, dtm, blue, red in G:
    ok = True; teams = []
    for t in picks:
        tm = []
        for name, role in t:
            n = norm(name or ''); cid = ID.get(n) or ID.get(alias.get(n, ''))
            if not cid or role not in RM: ok = False; continue
            tm.append([cid, RM[role]])
        teams.append(tm)
    if w not in ('1', '2'): drop['vainqueur'] += 1; continue
    if not ok or any(len(t) != 5 or len({r for _, r in t}) != 5 for t in teams): drop['picks'] += 1; continue
    out.append({'id': gid, 'o': o, 'dt': dtm, 'p': p, 'w': 1 if w == '1' else 0, 'tier': tier, 'tb': blue, 'tr': red,
                'B': teams[0], 'R': teams[1], 'bans': [[ID.get(norm(b or '')) for b in t] for t in bans]})
out.sort(key=lambda g: (g['dt'], g['id']))
json.dump(out, open(out_games, 'w'), ensure_ascii=False); print(len(out), 'parties gardées', dict(drop))
cnt = {r: collections.Counter() for r in ['top', 'jgl', 'mid', 'adc', 'sup']}
for g in out:
    for t in ('B', 'R'):
        for c, r in g[t]: cnt[r][c] += 1
json.dump([[r, a, b] for r, C in cnt.items() for a in sorted(C) for b in sorted(C) if a != b], open(out_pairs, 'w'))
