# Le WR pro d'un champion vaut-il pour un rôle où il est peu joué ? Comparaison sur les parties contenant un pick « hors rôle »
# (rôle qui représentait moins de 30 % des parties pros antérieures du champion, avec au moins 10 parties).
# Variantes de la variable WR pro (point de vue bleu) :
#   champion : WR du champion tous rôles, lissé vers 50 % (outil actuel)
#   rôle→50 % : WR du champion à ce rôle, lissé vers 50 % (hors rôle ≈ neutre)
#   rôle→champion : WR à ce rôle, ramené vers le WR du champion
import json, sys, collections, numpy as np
from sklearn.linear_model import LogisticRegression
G = json.load(open(sys.argv[1])); n = len(G); y = np.array([g['w'] for g in G]); K = 200
R0 = collections.defaultdict(float); E = np.zeros(n)
for i, g in enumerate(G):
    d = R0[g['tb']] - R0[g['tr']]; E[i] = d; p = 1 / (1 + 10 ** (-d / 400)); R0[g['tb']] += 32 * (g['w'] - p); R0[g['tr']] -= 32 * (g['w'] - p)
W = collections.defaultdict(lambda: [0, 0]); WR = collections.defaultdict(lambda: [0, 0])
X = {k: np.zeros(n) for k in ('champion', 'rôle→50 %', 'rôle→champion')}; off = np.zeros(n, bool); noff = np.zeros(n)
for i, g in enumerate(G):
    for side, sg in (('B', 1), ('R', -1)):
        for c, r in g[side]:
            nc, wc = W[c]; base = (wc + K / 2) / (nc + K); nr, wr_ = WR[(c, r)]
            X['champion'][i] += sg * (base - .5) * 100
            X['rôle→50 %'][i] += sg * ((wr_ + K / 2) / (nr + K) - .5) * 100
            X['rôle→champion'][i] += sg * ((wr_ + 200 * base) / (nr + 200) - .5) * 100
            if nc >= 10 and nr / nc < 0.3: off[i] = True; noff[i] += 1
    for side in 'BR':
        win = (g['w'] == 1) == (side == 'B')
        for c, r in g[side]: W[c][0] += 1; W[c][1] += win; WR[(c, r)][0] += 1; WR[(c, r)][1] += win
start = n // 3; idx = np.arange(start, n)
def wf(x):
    P = np.zeros(n); Z = np.column_stack([E, x])
    for b in np.array_split(idx, 8)[1:]:
        tr = np.arange(start, b[0]); P[b] = LogisticRegression(C=1e4).fit(Z[tr], y[tr]).predict_proba(Z[b])[:, 1]
    return P
ev = idx[len(np.array_split(idx, 8)[0]):]
li = lambda P, s: -(y[s] * np.log(P[s]) + (1 - y[s]) * np.log(1 - P[s]))
Ps = {k: wf(v) for k, v in X.items()}
rng = np.random.default_rng(0)
for lab, s in [('toutes les parties', ev), ('parties avec un pick hors rôle', ev[off[ev]])]:
    print(f'== {lab} : n = {len(s)}')
    base = li(Ps['champion'], s)
    for k, P in Ps.items():
        d = base - li(P, s); bs = [d[rng.integers(0, len(d), len(d))].mean() for _ in range(2000)]
        print(f'   {k:15s} log loss {li(P, s).mean():.5f}   gain sur « champion » {d.mean():+.5f} IC95 {np.percentile(bs, [2.5, 97.5]).round(5)}')
