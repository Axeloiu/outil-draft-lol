// Reconstruit prodraft.json et proshape.json à partir des parties pros RÉORIENTÉES (bleu = équipe qui drafte en premier).
// Usage : node formes_pro.js <dossier outil> <pro_games.json> <niveau max (1 = tier 1 seulement)>
const fs = require('fs'), vm = require('vm');
const D = process.argv[2].replace(/\/?$/, '/'); const rd = f => fs.readFileSync(D + f, 'utf8');
const src = rd('data.js') + '\n' + rd('app.js') + '\n' + rd('comp.js') + '\n' + rd('fit.js') + '\nconst CTX=' + rd('data/ctx.json') + ';\nconst PRODRAFT=' + rd('data/prodraft.json').trim() +
  ';\nconst PROSHAPE=' + rd('data/proshape.json').trim() + ';\nconst BIAS=' + rd('data/bias.json') + ';\nconst MODEL=' + rd('data/model.json') + ';\nconst PRO26=' + rd('data/pro2026.json') + ';\n' + rd('ctx.js') +
  '\n;globalThis.__api = { BY, traitsSum, identity, curveLab, engB };';
const ctx = { console, localStorage: { getItem: () => null, setItem: () => {} }, window: {}, document: { addEventListener() {}, querySelector() { return null; } }, setTimeout, Math, JSON };
ctx.globalThis = ctx; vm.createContext(ctx); vm.runInContext(src, ctx);
const { BY, traitsSum, identity, curveLab, engB } = ctx.__api;
const G = JSON.parse(fs.readFileSync(process.argv[3], 'utf8')).filter(g => g.tier <= +process.argv[4]);
const ORD = { B: [1, 4, 5, 8, 9], R: [2, 3, 6, 7, 10] }, L1 = { top: 'T', jgl: 'J', mid: 'M', adc: 'B', sup: 'S' };
const PD = { games: G.length, fdW: 0, c: {}, b: {}, rs: {} }, SH = { teams: 0 };
const add = (tab, key, win) => { const t = SH[tab] = SH[tab] || {}; const v = t[key] = t[key] || [0, 0]; v[0]++; v[1] += win ? 1 : 0; };
for (const r of ['top', 'jgl', 'mid', 'adc', 'sup']) PD.rs[r] = [0, 0, 0, 0, G.length];
for (const g of G) {
  PD.fdW += g.w;
  const pos = {}; for (const s of ['B', 'R']) g[s].forEach(([c, r], k) => pos[s + r] = ORD[s][k]);
  for (const s of ['B', 'R']) {
    const o = s === 'B' ? 'R' : 'B', win = (g.w === 1) === (s === 'B');
    const cs = g[s].map(([c]) => BY[c]), es = g[o].map(([c]) => BY[c]);
    let ncnt = 0;
    g[s].forEach(([c, r], k) => {
      const p = ORD[s][k], key = BY[c].n + '|' + r, x = PD.c[key] = PD.c[key] || [0, 0, 0, 0, 0, 0, 0, 0];
      const counter = pos[o + r] < p; if (counter) ncnt++;
      x[0]++; x[1] += win; x[2] += p; x[3] += p === 1; x[4] += p <= 6; x[5] += p >= 9; x[6] += counter; x[7] += counter && win;
      const rs = PD.rs[r]; rs[0]++; rs[1] += p; rs[2] += p === 1; rs[3] += p <= 6;
      add(r + 'c', counter ? 'c' : 'b', win);
    });
    (g.bans[s === 'B' ? 0 : 1] || []).forEach((b, k) => {
      if (!b || !BY[b]) return; const x = PD.b[BY[b].n] = PD.b[BY[b].n] || [0, 0, 0, 0, 0];
      x[0]++; x[1] += k < 3; x[2] += k >= 3; x[3] += k === 0; x[4] += s === 'B';
    });
    SH.teams++;
    const t = traitsSum(cs), et = traitsSum(es), id = identity(t), eid = identity(et);
    add('dmg', `${t.AD}-${t.AP}`, win); add('tanks', String(t.T), win); add('eng', engB(t.e), win);
    add('engdiff', t.e > et.e + 1 ? '+' : et.e > t.e + 1 ? '-' : '=', win);
    add('curve', curveLab(t.c), win); add('curvevs', `${curveLab(t.c)}|${curveLab(et.c)}`, win);
    add('style', id.main, win); if (id.main !== eid.main) add('stylevs', `${id.main}|${eid.main}`, win);
    const order = g[s].map(([c, r]) => L1[r]);
    add('p1', order.slice(0, 3).slice().sort().join(''), win);
    if (s === 'B') add('first', order[0], win); else add('first2', order.slice(0, 2).slice().sort().join(''), win);
    add('last', order[4], win); add('cnt', String(ncnt), win);
    const pa = pos[s + 'adc'] <= 6, ps = pos[s + 'sup'] <= 6; add('duo', pa && ps ? 'p1' : !pa && !ps ? 'p2' : 'split', win);
    add('topp', pos[s + 'top'] <= 6 ? 'p1' : 'p2', win); add('fd', s === 'B' ? '1' : '2', win);
  }
}
fs.writeFileSync(D + 'data/prodraft.json', JSON.stringify(PD)); fs.writeFileSync(D + 'data/proshape.json', JSON.stringify(SH));
console.log(G.length, 'parties ; bleu gagne', (PD.fdW / G.length * 100).toFixed(1), '%');
