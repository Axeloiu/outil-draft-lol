import json, math, collections, numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import log_loss
ORD = {'B': [1, 4, 5, 8, 9], 'R': [2, 3, 6, 7, 10]}
G = json.load(open('pro2026.json')); T = json.load(open('/tmp/pro_tool.json'))
for g, t in zip(G, T): g['tool'] = (t['wr'] - 50) / 100
G.sort(key=lambda g: g['d'])
y = np.array([g['w'] for g in G])
# winrate et présence pro de chaque champion, calculés uniquement sur les parties ANTÉRIEURES
def feats(mode):
    W = collections.defaultdict(lambda: [0, 0]); P = collections.Counter(); ngames = 0; X = []
    hist = []
    for g in G:
        # τ² (variance réelle des WR pro) estimé sur l'historique courant
        f = []
        for t in 'BR':
            s = 0; pres = 0
            for c, r in g[t]:
                n, w = W[c]
                s += (w + K * 0.5) / (n + K) - 0.5
                pres += P[c] / max(ngames, 1)
            f.append((s, pres))
        X.append([f[0][0] - f[1][0], f[0][1] - f[1][1]])
        for t in 'BR':
            win = (g['w'] == 1) == (t == 'B')
            for c, r in g[t]: W[c][0] += 1; W[c][1] += win; P[c] += 1
            for b in g['bans'][0 if t == 'B' else 1]:
                if b: P[b] += 1
        ngames += 1
    return np.array(X)
# τ² estimé une fois sur l'ensemble (Bayes empirique) -> K = 0,25 / τ²
W = collections.defaultdict(lambda: [0, 0])
for g in G:
    for t in 'BR':
        for c, r in g[t]: W[c][0] += 1; W[c][1] += (g['w'] == 1) == (t == 'B')
ns = np.array([v[0] for v in W.values()]); ws = np.array([v[1] for v in W.values()])
m = ns >= 30; p = ws[m] / ns[m]
tau2 = max(1e-6, np.average((p - 0.5) ** 2, weights=ns[m]) - np.average(0.25 / ns[m], weights=ns[m]))
K = 0.25 / tau2
print(f'écart-type réel des WR pro par champion : {math.sqrt(tau2)*100:.2f} points ; lissage = {K:.0f} parties fictives à 50 %')
X = feats('all')
tool = np.array([g['tool'] for g in G]); tier = np.array([g['tier'] for g in G]); n = len(G)
start = n // 3  # on évalue sur les 2/3 les plus récents (historique suffisant)
def cv(cols, sel):
    idx = np.where(sel)[0]; idx = idx[idx >= start]
    Z = np.column_stack(cols)
    # validation « en avançant dans le temps » : entraîné sur tout ce qui précède chaque bloc
    blocks = np.array_split(idx, 8); P = []; Y = []
    for b in blocks[1:]:
        tr = np.arange(start, b[0]); tr = tr[sel[tr]]
        lr = LogisticRegression(C=1e4).fit(Z[tr], y[tr]); P += list(lr.predict_proba(Z[b])[:, 1]); Y += list(y[b])
    return round(log_loss(Y, P), 5), round(np.mean((np.array(P) > .5) == np.array(Y)), 4), lr.coef_.round(3).tolist(), lr.intercept_.round(3).tolist()
for lab, sel in [('tier 1', tier == 1), ('tier 2', tier == 2), ('tout', tier > 0)]:
    print(lab, 'côté seul', cv([np.zeros(n)], sel))
    print(lab, 'outil (solo)', cv([tool], sel))
    print(lab, 'outil + WR pro', cv([tool, X[:, 0]], sel))
    print(lab, 'outil + WR pro + présence', cv([tool, X[:, 0], X[:, 1]], sel))
# coefficients finaux (toutes les parties avec historique) et données pour l'outil
sel = np.arange(n) >= start
lr = LogisticRegression(C=1e4).fit(np.column_stack([tool, X[:, 0]])[sel], y[sel])
a_tool, a_pro = lr.coef_[0]; b0 = lr.intercept_[0]
print('final : outil x', round(a_tool / 4, 3), '; WR pro x', round(a_pro / 4, 3), '; côté bleu', round(b0 * 25, 2), 'pts')
W = collections.defaultdict(lambda: [0, 0]); F = {r: collections.Counter() for r in ['top','jgl','mid','adc','sup']}
PR = [collections.Counter() for _ in range(10)]
for g in G:
    for t in 'BR':
        for k, (c, r) in enumerate(g[t]):
            W[c][0] += 1; W[c][1] += (g['w'] == 1) == (t == 'B'); F[r][c] += 1; PR[ORD[t][k] - 1][r] += 1
out = {'n': len(G), 'K': round(K), 'mt': round(a_tool / 4, 3), 'mp': round(a_pro / 4, 3), 'side': round(b0 * 25, 2),
       'kappa': [0.03] * 5 + [0.09] * 3 + [0.11] * 2, 'wr': {c: v for c, v in W.items()},
       'freq': {r: dict(C) for r, C in F.items()}, 'posRole': [[PR[i][r] for r in ['top','jgl','mid','adc','sup']] for i in range(10)]}
json.dump(out, open('/home/claude/draft/data/pro2026.json', 'w'), separators=(',', ':'))
D = json.loads(open('/home/claude/draft/data.js').read()[len('const DATA='):-2]); NM = {c['id']: c['n'] for c in D['champs']}
sh = lambda c: (W[c][1] + K * .5) / (W[c][0] + K)
for name in ['Rumble', 'Azir', 'Orianna', 'Vi', 'Nocturne', 'Poppy', 'Syndra', 'Hwei', 'Yunara']:
    c = next(i for i, x in NM.items() if x == name); print(name, W[c], f'brut {W[c][1]/max(1,W[c][0])*100:.1f} %, lissé {sh(c)*100:.1f} %')
print('rôles par position', out['posRole'])
