# Score du modèle Master+ (sans côté) pour chaque partie pro, en points, point de vue bleu.
# Usage : python3 score_pro.py pro_games.json ../../outil sortie.json
import json, sys, subprocess, os, tempfile
import numpy as np
G = json.load(open(sys.argv[1])); outil = sys.argv[2]
tmp = tempfile.NamedTemporaryFile('w', suffix='.json', delete=False)
json.dump([{'B': {r: c for c, r in g['B']}, 'R': {r: c for c, r in g['R']}} for g in G], tmp); tmp.close()
here = os.path.dirname(os.path.abspath(__file__))
P = np.array(json.loads(subprocess.run(['node', os.path.join(here, '..', 'modele', 'tool_clean.js'), outil, tmp.name], capture_output=True, text=True, check=True).stdout), float)
mult = np.array(json.load(open(os.path.join(outil, 'data', 'model.json')))['mult'])
json.dump([round(float(x), 4) for x in P @ mult], open(sys.argv[3], 'w')); os.unlink(tmp.name); print(len(G), 'parties')
