# Recalage du modèle sur les parties pros (mode unique « tendu vers le pro »).
# Variables (point de vue bleu) : score du modèle Master+ (sans côté), écart de WR pro lissé des champions (parties ANTÉRIEURES,
# avec oubli exponentiel des vieilles parties), écart d'Elo des équipes (contrôle du niveau, mis à 0 à l'usage).
# Tous les réglages (K de l'Elo, demi-vie, lissage) sont choisis par vraisemblance en validation chronologique.
# Usage : python3 calib_pro.py pro_games.json [solo_scores.json] sortie.json
import json, sys, math, collections, numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import log_loss
G = json.load(open(sys.argv[1])); SOLO = json.load(open(sys.argv[2])) if len(sys.argv) > 3 else None; OUT = sys.argv[-1]
n = len(G); y = np.array([g['w'] for g in G]); tier = np.array([g['tier'] for g in G])
day = np.array([(np.datetime64(g['dt'][:10]) - np.datetime64('2026-01-01')).astype(int) for g in G], float)
def elo(K):
    R = collections.defaultdict(float); X = np.zeros(n); ll = 0
    for i, g in enumerate(G):
        d = R[g['tb']] - R[g['tr']]; X[i] = d
        p = 1 / (1 + 10 ** (-d / 400)); R[g['tb']] += K * (g['w'] - p); R[g['tr']] -= K * (g['w'] - p)
    return X
def prowr(hl, K):
    # WR des champions sur les parties antérieures, poids 2^(−âge/demi-vie), lissé vers 50 % avec K parties fictives
    W = collections.defaultdict(lambda: [0.0, 0.0, -1e9]); X = np.zeros(n)
    lam = math.log(2) / hl if hl else 0
    def get(c, t):
        w = W[c]; dec = math.exp(-lam * (t - w[2])) if w[2] > -1e8 else 0; return w[0] * dec, w[1] * dec
    for i, g in enumerate(G):
        t = day[i]; s = 0
        for side, sg in (('B', 1), ('R', -1)):
            for c, r in g[side]:
                nn, ww = get(c, t); s += sg * ((ww + K * .5) / (nn + K) - .5)
        X[i] = s * 100
        for side in 'BR':
            win = (g['w'] == 1) == (side == 'B')
            for c, r in g[side]:
                nn, ww = get(c, t); W[c] = [nn + 1, ww + win, t]
    return X
def prowr_role(K, K2):
    # WR du champion à ce rôle, sur les parties antérieures, ramené vers le WR lissé du champion (tous rôles) avec K2 parties fictives
    W = collections.defaultdict(lambda: [0, 0]); WR = collections.defaultdict(lambda: [0, 0]); X = np.zeros(n)
    for i, g in enumerate(G):
        s = 0
        for side, sg in (('B', 1), ('R', -1)):
            for c, r in g[side]:
                nc, wc = W[c]; base = (wc + K * .5) / (nc + K)
                nr, wr_ = WR[(c, r)]; s += sg * (((wr_ + K2 * base) / (nr + K2) if K2 < 1e8 else base) - .5)
        X[i] = s * 100
        for side in 'BR':
            win = (g['w'] == 1) == (side == 'B')
            for c, r in g[side]: W[c][0] += 1; W[c][1] += win; WR[(c, r)][0] += 1; WR[(c, r)][1] += win
    return X
start = n // 3
def wf(cols, sel=None, ret=False):
    sel = np.ones(n, bool) if sel is None else sel
    idx = np.where(sel)[0]; idx = idx[idx >= start]; Z = np.column_stack(cols) if cols else np.zeros((n, 1))
    P = []; Y = []
    for b in np.array_split(idx, 8)[1:]:
        tr = np.arange(start, b[0]); tr = tr[sel[tr]]
        m = LogisticRegression(C=1e4).fit(Z[tr], y[tr]); P += list(m.predict_proba(Z[b])[:, 1]); Y += list(y[b])
    P, Y = np.array(P), np.array(Y)
    return (log_loss(Y, P), P, Y) if ret else log_loss(Y, P)
# 1. Elo : K par vraisemblance
best = min(((wf([elo(K)]), K) for K in (8, 16, 24, 32, 48, 64)), key=lambda x: x[0]); KE = best[1]; E = elo(KE)
print('Elo : K =', KE, 'log loss', round(best[0], 5), flush=True)
# 2. WR pro : demi-vie et lissage par vraisemblance (avec Elo dans le modèle)
grid = [(hl, K) for hl in (0, 30, 60, 120) for K in (100, 200, 313, 500)]
res = sorted((wf([E, prowr(hl, K)]), hl, K) for hl, K in grid)
_, HL, KW = res[0]; PW_champ = prowr(HL, KW)
# 2b. WR par rôle : K2 par vraisemblance (K2 = ∞ revient au WR par champion)
res2 = sorted((wf([E, prowr_role(KW, K2)]), K2) for K2 in (2, 10, 25, 50, 100, 200, 1e9))
for v, K2 in sorted(res2, key=lambda x: x[1]): print(f'   WR pro par rôle, K2 = {K2:g} : log loss {v:.5f}', flush=True)
K2 = res2[0][1]; PW = prowr_role(KW, K2) if K2 < 1e8 else PW_champ
print('WR pro : K2 retenu', K2, flush=True)
print('WR pro : demi-vie', HL or 'aucune', 'jours ; lissage', KW, 'parties ; log loss', round(res[0][0], 5), '| sans oubli, K=313 :', round([r for r in res if r[1] == 0 and r[2] == 313][0][0], 5), flush=True)
rng = np.random.default_rng(0)
def gain(a, b, sel=None, B=2000):
    _, P0, Y = wf(a, sel, True); _, P1, _ = wf(b, sel, True)
    d = -(Y * np.log(P0) + (1 - Y) * np.log(1 - P0)) + (Y * np.log(P1) + (1 - Y) * np.log(1 - P1)); m = len(d)
    bs = [d[rng.integers(0, m, m)].mean() for _ in range(B)]
    return round(d.mean(), 5), np.percentile(bs, [2.5, 97.5]).round(5).tolist(), m
cols = {'côté': [], 'Elo': [E], 'WR pro': [PW], 'Elo + WR pro': [E, PW], 'Elo + WR pro champion': [E, PW_champ]}
if SOLO is not None:
    S = np.array(SOLO, float); cols.update({'Elo + solo': [E, S], 'Elo + WR pro + solo': [E, PW, S], 'WR pro + solo': [PW, S]})
rep = {}
for lab, sel in [('tier 1', tier == 1), ('tier 2', tier == 2), ('tout', None)]:
    print('==', lab, flush=True)
    for a, b in [('côté', 'WR pro'), ('côté', 'Elo'), ('Elo', 'Elo + WR pro'), ('Elo + WR pro champion', 'Elo + WR pro')] + ([('Elo', 'Elo + solo'), ('Elo + WR pro', 'Elo + WR pro + solo')] if SOLO is not None else []):
        g = gain(cols[a], cols[b], sel); rep[f'{lab}: {a} -> {b}'] = g
        print(f'   {a:14s} -> {b:22s} gain de log loss {g[0]:+.5f}  IC95 {g[1]}  (n={g[2]})', flush=True)
# 3. coefficients finaux (toutes les parties avec historique), Elo contrôlé puis mis à 0 à l'usage
sel = np.arange(n) >= start
Z = np.column_stack([E, PW] + ([S] if SOLO is not None else []))
m = LogisticRegression(C=1e4).fit(Z[sel], y[sel])
co = m.coef_[0]; b0 = m.intercept_[0]
fin = {'K_elo': KE, 'demi_vie': HL, 'K': KW, 'K2': K2, 'mp': round(co[1] * 25, 4), 'side': round(b0 * 25, 2), 'elo_pts_par_100': round(co[0] * 100 * 25, 3)}
if SOLO is not None: fin['mt'] = round(co[2] * 25, 4)
print('final :', fin)
# coefficients sans contrôle Elo, pour comparer (biais de confusion par le niveau des équipes)
m2 = LogisticRegression(C=1e4).fit(Z[sel][:, 1:], y[sel]); print('sans Elo : WR pro x', round(m2.coef_[0][0] * 25, 4), ('; solo x ' + str(round(m2.coef_[0][1] * 25, 4))) if SOLO is not None else '')
json.dump({'final': fin, 'gains': rep}, open(OUT, 'w'), ensure_ascii=False, indent=1)
