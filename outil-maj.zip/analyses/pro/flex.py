import json, collections, numpy as np
exec(open('kappa.py').read().split('def ll(')[0])
# répartition des rôles de chaque champion chez les pros
RS = collections.defaultdict(collections.Counter)
for g in G:
    for t in 'BR':
        for c, r in g[t]: RS[c][r] += 1
amb = {c: 1 - max(v.values()) / sum(v.values()) for c, v in RS.items()}
rows = []
for g in G:
    pos = {}
    for t in 'BR':
        for k, (c, r) in enumerate(g[t]): pos[(t, r)] = (ORD[t][k], c)
    for t in 'BR':
        o = 'R' if t == 'B' else 'B'
        for k, (c, r) in enumerate(g[t]):
            p = ORD[t][k]; po, co = pos[(o, r)]
            if po < p: continue  # seulement les picks faits avant leur adversaire de lane (exposés au counter)
            n = sum(RS[c].values())
            rows.append((p, amb[c], ADV.get((r, c, co), 0), (g['w'] == 1) == (t == 'B'), n, g['tier']))
A = np.array([(p, a, adv, w, n) for p, a, adv, w, n, _ in rows], float)
A = A[A[:, 4] >= 20]  # rôle estimé sur au moins 20 parties
print('picks exposés au counter', len(A))
for lo, hi in [(1, 3), (4, 6), (7, 9)]:
    m = (A[:, 0] >= lo) & (A[:, 0] <= hi)
    X = np.column_stack([np.ones(m.sum()), A[m, 1]])
    b, *_ = np.linalg.lstsq(X, A[m, 2], rcond=None)
    res = A[m, 2] - X @ b; se = np.sqrt(res.var() * np.linalg.inv(X.T @ X)[1, 1])
    q = A[m, 1] >= 0.2
    print(f'picks {lo}-{hi}: n={m.sum()}, duel moyen {A[m,2].mean():+.2f} pts ; effet de l’ambiguïté de rôle {b[1]:+.2f} pts par unité (± {1.96*se:.2f}) ;',
          f'flex (≥20 % hors rôle principal) {A[m][q][:,2].mean():+.2f} pts (n={q.sum()}) vs mono {A[m][~q][:,2].mean():+.2f} ; WR {A[m][q][:,3].mean():.3f} vs {A[m][~q][:,3].mean():.3f}')
print('champions les plus flex :', sorted(((round(amb[c], 2), c, dict(RS[c])) for c in RS if sum(RS[c].values()) >= 40), reverse=True)[:8])
