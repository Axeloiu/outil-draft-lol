// Comment les équipes pros choisissent-elles leurs picks ? Logit conditionnel sur chaque pick réel (rôle connu) :
//   utilité = log(fréquence du terrain) + λ × gain estimé par le modèle (du point de vue de l'équipe qui pick)
//             + κ_rôle × écart de duel résiduel contre l'adversaire de lane s'il est déjà connu
// Le gain est celui de la simulation (gainCore : force, duel, synergies, effets contre eux, WR pro), sans aisance.
// Usage : node comportement_pro.js <dossier outil> <pro_games.json> <sortie.json>
const fs = require('fs'), vm = require('vm');
const D = process.argv[2].replace(/\/?$/, '/'); const rd = f => fs.readFileSync(D + f, 'utf8');
const src = rd('data.js') + '\n' + rd('app.js') + '\n' + rd('comp.js') + '\n' + rd('fit.js') + '\nconst CTX=' + rd('data/ctx.json') + ';\nconst PRODRAFT=' + rd('data/prodraft.json').trim() +
  ';\nconst PROSHAPE=' + rd('data/proshape.json').trim() + ';\nconst BIAS=' + rd('data/bias.json') + ';\nconst MODEL=' + rd('data/model.json') + ';\nconst PRO26=' + rd('data/pro2026.json') + ';\n' + rd('ctx.js') + '\n' + rd('sim.js') +
  '\n;globalThis.__api = { BY, ROLES, simField, gainCore, fsRes, fsF };';
const ctx = { console, localStorage: { getItem: () => null, setItem: () => {} }, window: {}, document: { addEventListener() {}, querySelector() { return null; } }, setTimeout: f => { f(); return 0; }, Math, JSON, Date };
ctx.globalThis = ctx; vm.createContext(ctx); vm.runInContext(src, ctx);
const A = ctx.__api, ROLES = A.ROLES, F = A.simField();
const G = JSON.parse(fs.readFileSync(process.argv[3], 'utf8'));
const ORD = { B: [1, 4, 5, 8, 9], R: [2, 3, 6, 7, 10] };
const obs = []; // { ri, ch, X: [[logp, G, res], ...] }
for (const g of G) {
  if ([...g.B, ...g.R].some(([c]) => !A.BY[c])) continue;
  const seq = []; for (const s of ['B', 'R']) g[s].forEach(([c, r], k) => seq.push({ s, c, r, p: ORD[s][k] }));
  seq.sort((a, b) => a.p - b.p);
  const team = { B: {}, R: {} }, taken = new Set();
  for (const x of seq) {
    const nb = x.p <= 6 ? 3 : 5;
    for (const t of [0, 1]) for (const b of g.bans[t].slice(0, nb)) if (b) taken.add(b);
    const me = team[x.s], en = team[x.s === 'B' ? 'R' : 'B'], r = x.r;
    let L = F[r].filter(o => !taken.has(o.c.id));
    let ch = L.findIndex(o => o.c.id === x.c);
    if (ch >= 0) {
      const opp = en[r];
      obs.push({ ri: ROLES.indexOf(r), ch, X: L.map(o => [Math.log(o.p), A.gainCore(o.c, r, me, en), opp ? A.fsRes(o.c, opp, r) : 0]) });
    }
    me[r] = A.BY[x.c]; taken.add(x.c);
  }
}
console.error(obs.length, 'picks (champion dans le terrain des 40 plus probables)');
// logit conditionnel, Newton ; params : liste de fonctions (obs, ligne) -> valeur
function fit(feats) {
  const k = feats.length; let b = new Array(k).fill(0), ll = 0, H = null;
  for (let it = 0; it < 30; it++) {
    const gr = new Array(k).fill(0); H = Array.from({ length: k }, () => new Array(k).fill(0)); ll = 0;
    for (const o of obs) {
      const Z = o.X.map(x => feats.map(f => f(o, x)));
      const u = o.X.map((x, i) => x[0] + Z[i].reduce((s, z, j) => s + z * b[j], 0)); const m = Math.max(...u);
      const e = u.map(v => Math.exp(v - m)), S = e.reduce((a, c) => a + c, 0), p = e.map(v => v / S);
      ll += u[o.ch] - m - Math.log(S);
      const zb = new Array(k).fill(0); Z.forEach((z, i) => z.forEach((v, j) => zb[j] += p[i] * v));
      for (let j = 0; j < k; j++) gr[j] += Z[o.ch][j] - zb[j];
      Z.forEach((z, i) => { for (let a = 0; a < k; a++) for (let c = 0; c < k; c++) H[a][c] -= p[i] * (z[a] - zb[a]) * (z[c] - zb[c]); });
    }
    // b ← b − H⁻¹ g
    const M = H.map((row, i) => [...row.map(v => -v), gr[i]]);
    for (let i = 0; i < k; i++) { let piv = i; for (let r = i + 1; r < k; r++) if (Math.abs(M[r][i]) > Math.abs(M[piv][i])) piv = r; [M[i], M[piv]] = [M[piv], M[i]];
      for (let r = 0; r < k; r++) if (r !== i) { const f = M[r][i] / M[i][i]; for (let c = i; c <= k; c++) M[r][c] -= f * M[i][c]; } }
    const step = M.map((row, i) => row[k] / row[i]); b = b.map((v, i) => v + step[i]);
    if (Math.max(...step.map(Math.abs)) < 1e-6) break;
  }
  // erreurs-types : inverse de −H
  const k2 = feats.length, I = H.map((row, i) => [...row.map(v => -v), ...Array.from({ length: k2 }, (_, j) => +(i === j))]);
  for (let i = 0; i < k2; i++) { const d = I[i][i]; for (let c = 0; c < 2 * k2; c++) I[i][c] /= d; for (let r = 0; r < k2; r++) if (r !== i) { const f = I[r][i]; for (let c = 0; c < 2 * k2; c++) I[r][c] -= f * I[i][c]; } }
  return { b: b.map(v => +v.toFixed(4)), se: I.map((row, i) => +Math.sqrt(row[k2 + i]).toFixed(4)), ll: +ll.toFixed(1) };
}
const res = {};
res.frequences = { ll: +obs.reduce((s, o) => { const m = Math.max(...o.X.map(x => x[0])); const S = o.X.reduce((a, x) => a + Math.exp(x[0] - m), 0); return s + o.X[o.ch][0] - m - Math.log(S); }, 0).toFixed(1) };
const kr = ROLES.map((_, r) => (o, x) => o.ri === r ? x[2] : 0);
res.counter_seul = fit(kr);
res.gain = fit([(o, x) => x[1]]);
res.gain_et_counter = fit([(o, x) => x[1], ...kr]);
for (const [k, v] of Object.entries(res)) console.log(k.padEnd(16), JSON.stringify(v));
fs.writeFileSync(process.argv[4], JSON.stringify({ n: obs.length, ...res }));
