# leaguepedia-2026.json (export brut) -> pro2026.json (parties nettoyées, ids de champions de l'outil)
# + /tmp/lanepairs.json (couples de duels pour lanewr.js), rolecnt.json, /tmp/progames.json (pour tool.js)
import json, collections, unicodedata, re, sys
G = json.load(open(sys.argv[1] if len(sys.argv) > 1 else '../../donnees/leaguepedia-2026.json'))
D = json.loads(open('../../outil/data.js').read()[len('const DATA='):-2])
norm = lambda s: re.sub(r'[^a-z]', '', unicodedata.normalize('NFKD', s).lower())
ID = {norm(c['n']): c['id'] for c in D['champs']}
ID.update({norm(c.get('k', '')): c['id'] for c in D['champs'] if c.get('k')})
alias = {'nunuwillump': 'nunu', 'wukong': 'monkeyking', 'renataglasc': 'renata'}
RM = {'Top': 'top', 'Jungle': 'jgl', 'Mid': 'mid', 'Bot': 'adc', 'Support': 'sup'}
out = []
# format brut : [OverviewPage, date, patch, vainqueur ('1' = Team1 = bleu), niveau (1/2),
#                picks [[[nom, rôle] x5] x2] dans l'ordre de pick de chaque équipe, bans [[x5] x2]]
for o, d, p, w, tier, picks, bans in G:
    ok = True; teams = []
    for t in picks:
        tm = []
        for name, role in t:
            n = norm(name or ''); cid = ID.get(n) or ID.get(alias.get(n, ''))
            if not cid or role not in RM: ok = False; continue
            tm.append([cid, RM[role]])
        teams.append(tm)
    if not ok or any(len(t) != 5 or len({r for _, r in t}) != 5 for t in teams) or w not in ('1', '2'): continue
    out.append({'o': o, 'd': d, 'p': p, 'w': 1 if w == '1' else 0, 'tier': tier, 'B': teams[0], 'R': teams[1],
                'bans': [[ID.get(norm(b or '')) for b in t] for t in bans]})
json.dump(out, open('pro2026.json', 'w')); print(len(out), 'parties')
cnt = {r: collections.Counter() for r in ['top', 'jgl', 'mid', 'adc', 'sup']}
for g in out:
    for t in ('B', 'R'):
        for c, r in g[t]: cnt[r][c] += 1
todo = [[r, a, b] for r, C in cnt.items() for a in sorted(C) for b in sorted(C) if a != b]
json.dump(todo, open('/tmp/lanepairs.json', 'w')); json.dump({r: dict(C) for r, C in cnt.items()}, open('rolecnt.json', 'w'))
json.dump([{'B': {r: c for c, r in g['B']}, 'R': {r: c for c, r in g['R']}} for g in out], open('/tmp/progames.json', 'w'))
