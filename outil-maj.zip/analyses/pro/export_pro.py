# Écrit outil/data/pro2026.json pour le mode unique : recalage pro, κ par rôle, terrain adverse, rôles par position.
# Usage : python3 export_pro.py pro_games.json calib.json mesures_pro.json terrain.json sortie.json
import json, sys, collections
G, C, Mz, T = [json.load(open(f)) for f in sys.argv[1:5]]
ROLES = ['top', 'jgl', 'mid', 'adc', 'sup']
W = collections.defaultdict(lambda: [0, 0]); F = {r: collections.Counter() for r in ROLES}
for g in G:
    for s in 'BR':
        for c, r in g[s]: W[c][0] += 1; W[c][1] += (g['w'] == 1) == (s == 'B'); F[r][c] += 1
f = C['final']
out = {'n': len(G), 'K': f['K'], 'mt': round(f['mt'], 4), 'mp': round(f['mp'], 4), 'side': f['side'],
       'kres': {r: Mz['kappa'][r]['kappa_residuel'][0] for r in ROLES}, 'kstr': {r: Mz['kappa'][r]['force_solo'][0] for r in ROLES},
       'alpha': T['alpha'], 'wr': {c: v for c, v in W.items()}, 'freq': {r: dict(Cn) for r, Cn in F.items()}, 'posRole': Mz['posRole'],
       'note': 'Leaguepedia 2026 réorienté bleu/rouge ; recalage avec Elo d\'équipe (mis à 0 à l\'usage) ; κ sur duel résiduel'}
json.dump(out, open(sys.argv[5], 'w'), separators=(',', ':'), ensure_ascii=False)
print({k: v for k, v in out.items() if k not in ('wr', 'freq', 'posRole')})
