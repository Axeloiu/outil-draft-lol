# Terrain adverse (champions joués par rôle) : fréquences pros lissées vers les fréquences Master+.
# p(c | rôle) = (picks pros antérieurs + α × part Master+) / (picks pros antérieurs au rôle + α) ; α par vraisemblance
# des picks pros suivants (validation chronologique sur les 2/3 les plus récents).
import json, sys, math, collections, numpy as np
G = json.load(open(sys.argv[1])); D = json.loads(open(sys.argv[2] + '/data.js').read()[len('const DATA='):-2])
ROLES = ['top', 'jgl', 'mid', 'adc', 'sup']
S = {r: {} for r in ROLES}
for c in D['champs']:
    for r in ROLES:
        x = c['r'].get(r)
        if x: S[r][c['id']] = x[1]
for r in ROLES:
    t = sum(S[r].values()); S[r] = {c: v / t for c, v in S[r].items()}
n = len(G); start = n // 3
def score(alpha):
    cnt = {r: collections.Counter() for r in ROLES}; N = collections.Counter(); ll = 0; m = 0
    for i, g in enumerate(G):
        for side in 'BR':
            for c, r in g[side]:
                if i >= start:
                    p = (cnt[r][c] + alpha * S[r].get(c, 0) + 1e-3) / (N[r] + alpha + 1e-3 * 200); ll += math.log(p); m += 1
        for side in 'BR':
            for c, r in g[side]: cnt[r][c] += 1; N[r] += 1
    return ll / m
res = [(score(a), a) for a in (0, 10, 30, 100, 300, 1000, 3000, 10000, 1e6)]
for v, a in res: print(f'α = {a:>9g} : log-vraisemblance moyenne par pick {v:.4f}')
best = max(res); print('α retenu', best[1])
json.dump({'alpha': best[1]}, open(sys.argv[3], 'w'))
