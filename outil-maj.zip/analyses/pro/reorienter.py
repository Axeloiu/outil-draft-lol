# Réoriente l'export Leaguepedia en bleu / rouge.
# Masque : 1 = PB.Team1 est l'équipe rouge (PB.Team1 == SG.Team2), pour les GameId triés.
# Le masque a été calculé dans le navigateur avec l'API cargo (PicksAndBansS7 joint à ScoreboardGames, 18/11/2026) ;
# somme de contrôle FNV-1a des GameId triés : 9190637e, 2 354 parties inversées, aucun cas ambigu.
import json, sys
src, mask, out = sys.argv[1:4]
G = json.load(open(src))
ids = sorted({g[7] for g in G})
bits = open(mask).read().strip()
assert len(bits) == len(ids) == len(G)
h = 0x811c9dc5
for b in '\n'.join(ids).encode(): h ^= b; h = (h * 0x01000193) & 0xffffffff
assert format(h, '08x') == '9190637e'
sw = {g: bits[i] == '1' for i, g in enumerate(ids)}
res = []
for g in G:
    o, d, p, w, tier, picks, bans, gid, dt, blue, red = g
    if sw[gid]:
        picks, bans = [picks[1], picks[0]], [bans[1], bans[0]]
        w = {'1': '2', '2': '1'}.get(w, w)
    # format : [page, date, patch, vainqueur ('1' = bleu), niveau, picks [bleu, rouge] dans l'ordre de pick, bans [bleu, rouge],
    #           GameId, DateTime_UTC, équipe bleue, équipe rouge]
    res.append([o, d, p, w, tier, picks, bans, gid, dt, blue, red])
json.dump(res, open(out, 'w'), ensure_ascii=False)
print(len(res), 'parties,', sum(sw.values()), 'réorientées')
