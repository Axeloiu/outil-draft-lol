// Mesure du « biais de spécialiste » : un champion joué à un poste rare l'est surtout par des joueurs
// qui le maîtrisent, ce qui gonfle son WR Master+ à ce poste. Deux mesures :
//  A) intra-champion : WR(poste secondaire) − WR(poste principal) en fonction de log(part du poste)
//  B) inter-champions : WR(c, r) en fonction de log(taux de pick au poste), par poste
const fs = require('fs'), vm = require('vm');
const src = fs.readFileSync(process.argv[2], 'utf8'); const ctx = {}; vm.runInNewContext(src + ';this.DATA=DATA;', ctx);
const D = ctx.DATA, T = D.T;
function wls(pts) { // pts: [x, y, w]
  let sw = 0, sx = 0, sy = 0; pts.forEach(([x, y, w]) => { sw += w; sx += w * x; sy += w * y; });
  const mx = sx / sw, my = sy / sw; let sxx = 0, sxy = 0;
  pts.forEach(([x, y, w]) => { sxx += w * (x - mx) ** 2; sxy += w * (x - mx) * (y - my); });
  return { b: sxy / sxx, a: my - sxy / sxx * mx };
}
let seed = 7; const rnd = () => (seed = (seed * 1103515245 + 12345) % 2147483648) / 2147483648;
function boot(groups, f, n = 2000) { // rééchantillonnage par champion
  const bs = []; for (let i = 0; i < n; i++) { const p = []; for (let j = 0; j < groups.length; j++) p.push(...groups[Math.floor(rnd() * groups.length)]); bs.push(f(p).b); }
  bs.sort((a, b) => a - b); return [bs[Math.floor(n * .025)], bs[Math.floor(n * .975)]];
}
const MIN = +process.argv[3] || 300;
// A
const gA = [];
D.champs.forEach(c => {
  const rs = Object.entries(c.r).filter(([, x]) => x[1] >= MIN); if (rs.length < 2) return;
  const tot = Object.values(c.r).reduce((s, x) => s + x[1], 0);
  rs.sort((a, b) => b[1][1] - a[1][1]); const [, m] = rs[0], wm = m[0] / m[1];
  const g = rs.slice(1).map(([r, x]) => { const w = x[0] / x[1], v = 0.25 / x[1] + 0.25 / m[1]; return [Math.log(x[1] / tot), (w - wm) * 100, 1 / v, c.n, r]; });
  gA.push(g);
});
const pA = gA.flat(), fA = wls(pA), ciA = boot(gA, wls);
console.log(`A intra-champion : ${pA.length} postes secondaires (${gA.length} champions), pente ${fA.b.toFixed(2)} pts par unité de log(part), IC95 [${ciA.map(x => x.toFixed(2)).join(', ')}], ordonnée ${fA.a.toFixed(2)}`);
// B
const gB = {}; const pB = [];
D.champs.forEach(c => Object.entries(c.r).forEach(([r, x]) => { if (x[1] < MIN) return; const p = [Math.log(x[1] / T), (x[0] / x[1] - 0.5) * 100, x[1]]; pB.push(p); (gB[c.id] = gB[c.id] || []).push(p); }));
const fB = wls(pB), ciB = boot(Object.values(gB), wls);
console.log(`B inter-champions : ${pB.length} couples, pente ${fB.b.toFixed(2)} pts par unité de log(pick), IC95 [${ciB.map(x => x.toFixed(2)).join(', ')}]`);
// B seulement avec effet fixe champion : déjà A. B avec effet fixe poste :
const byR = {}; D.champs.forEach(c => Object.entries(c.r).forEach(([r, x]) => { if (x[1] >= MIN) (byR[r] = byR[r] || []).push([Math.log(x[1] / T), (x[0] / x[1] - .5) * 100, x[1]]); }));
Object.entries(byR).forEach(([r, p]) => console.log(`  ${r}: pente ${wls(p).b.toFixed(2)} (${p.length})`));
fs.writeFileSync('specialistes.json', JSON.stringify({ A: { n: pA.length, b: fA.b, a: fA.a, ci: ciA }, B: { n: pB.length, b: fB.b, ci: ciB }, min: MIN }, null, 1));
// exemples
const ex = pA.filter(p => ['Hwei', 'Syndra', "Rek'Sai", 'Karthus', 'Qiyana', 'Aurelion Sol'].includes(p[3]));
ex.forEach(p => console.log(`  ex ${p[3]} ${p[4]} part ${(Math.exp(p[0]) * 100).toFixed(1)}% écart obs ${p[1].toFixed(1)} prédit ${(fA.a + fA.b * p[0]).toFixed(1)}`));
// Part réelle des écarts résiduels (au-delà du bruit d'échantillonnage)
let sr = 0, sv = 0; pA.forEach(p => { const r = p[1] - (fA.a + fA.b * p[0]); sr += r * r; sv += 1e4 / p[2]; });
console.log(`résidus : variance ${(sr / pA.length).toFixed(2)} pts², bruit attendu ${(sv / pA.length).toFixed(2)} pts² → part réelle ${(100 * (1 - sv / sr)).toFixed(0)} %`);
const nm = n => D.champs.find(c => c.n === n);
[['Hwei', 'adc'], ['Syndra', 'adc'], ["Rek'Sai", 'top'], ['Karthus', 'adc']].forEach(([n, r]) => { const c = nm(n); console.log(`  ${n} ${r} : ${c.r[r][1]} parties, WR ${(100 * c.r[r][0] / c.r[r][1]).toFixed(1)} %, pro ${JSON.stringify(c.p[3])}`); });
