// Pour chaque couple (rôle, a, b) : duel brut, duel résiduel rétréci (au-delà des forces, comme draftScore), forces de a et b.
// Tout est calculé SANS correction apprise (priors seuls), en points. Usage : node lanepairs.js <dossier outil> <lanepairs.json>
const fs = require('fs'), vm = require('vm');
const D = process.argv[2].replace(/\/?$/, '/'); const rd = f => fs.readFileSync(D + f, 'utf8');
const real = JSON.parse(rd('data/model.json'));
const neutral = { n: 0, patch: real.patch, side: 0, flex: 0, mult: [1, 1, 1, 1, 0], pk: real.pk, comp: real.comp.map(() => 0), ch: {}, du: {}, al: {} };
const src = 'const MODEL=' + JSON.stringify(neutral) + ';\n' + rd('data.js') + '\n' + rd('app.js') + '\nconst BIAS=' + rd('data/bias.json') + ';\n' +
  'function selBias(c, r) { const b = BIAS[c.id + "|" + r]; return b ? (b[1] + b[2]) / 100 : 0; }\n;globalThis.__api = { wrVs, BY, bwr, selBias };';
const ctx = { console, localStorage: { getItem: () => null, setItem: () => {} }, window: {}, document: { addEventListener() {}, querySelector() { return null; } }, setTimeout, Math, JSON };
ctx.globalThis = ctx; vm.createContext(ctx); vm.runInContext(src, ctx);
const { wrVs, BY, bwr, selBias } = ctx.__api;
const f = (c, r) => (bwr(c, r) - selBias(c, r) - 0.5) * 100;
const todo = JSON.parse(fs.readFileSync(process.argv[3], 'utf8'));
process.stdout.write(JSON.stringify(todo.map(([r, a, b]) => {
  const A = BY[a], B = BY[b]; if (!A || !B) return null;
  const v = wrVs(A, B, r), exp = 0.5 + f(A, r) / 100 - f(B, r) / 100;
  const prior = Math.min(0.62, Math.max(0.38, exp)), raw = v.g ? (v.wr * (v.g + 100) - 100 * prior) / v.g : exp;
  const res = v.g ? (raw - exp) * 100 * 3 / (3 + 2500 / v.g) : 0;
  return [+((v.wr - 0.5) * 100).toFixed(3), +res.toFixed(3), +f(A, r).toFixed(3), +f(B, r).toFixed(3), v.g];
})));
