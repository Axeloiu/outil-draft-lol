# Modèle retenu : priors u.gg / LoLalytics recalés (4 multiplicateurs) + côté + effet flex,
# estimés sur toutes les parties postérieures à la date des priors. Intervalles par bootstrap.
import json, sys, datetime as dt, numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import log_loss
P = np.array(json.load(open(sys.argv[1])), float) / 100; M = json.load(open(sys.argv[2]))
y = np.array([m['y'] for m in M]); t = np.array([m['t'] for m in M]); fl = np.array([m['q'] == 440 for m in M], float)
keep = t >= dt.datetime(2026, 11, 8).timestamp()
X = np.column_stack([P, fl])[keep]; yy = y[keep]
m = LogisticRegression(C=1e6).fit(X, yy)
rng = np.random.default_rng(0); B = []
for _ in range(200):
    i = rng.integers(0, len(yy), len(yy)); B.append(np.r_[LogisticRegression(C=1e6).fit(X[i], yy[i]).coef_[0], 0])
B = np.array(B)
co = m.coef_[0]; lo, hi = np.percentile(B, [2.5, 97.5], axis=0)
names = ['force', 'synergies', 'duels', 'compo contre compo']
for k, nm in enumerate(names): print(f'{nm:20s} x {co[k]/4:.3f}  [{lo[k]/4:.3f} ; {hi[k]/4:.3f}]')
side = m.intercept_[0] * 25; flex = co[4] * 25
print(f'côté bleu {side:+.2f} pts ; en plus en flex {flex:+.2f} pts [{lo[4]*25:+.2f} ; {hi[4]*25:+.2f}] ; n = {len(yy)}')
p = m.predict_proba(X)[:, 1]; bins = np.digitize(p, [.35, .4, .45, .5, .55, .6, .65])
print('calibration (dans l\'échantillon)', [(round(float(p[bins == k].mean()), 3), round(float(yy[bins == k].mean()), 3), int((bins == k).sum())) for k in range(8) if (bins == k).sum()])
real = json.load(open(sys.argv[3]))
out = {'n': int(len(yy)), 'patch': real['patch'], 'priors': '2026-11-07', 'side': round(side, 3), 'flex': round(flex, 3),
       'mult': [round(float(c / 4), 4) for c in co[:4]], 'pk': real['pk'], 'comp': [0] * len(real['comp']), 'ch': {}, 'du': {}, 'al': {}}
json.dump(out, open(sys.argv[4], 'w'), separators=(',', ':')); print('écrit', sys.argv[4])
