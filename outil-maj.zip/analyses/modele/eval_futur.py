# Test honnête du modèle sur des parties jouées APRÈS une date (ex. le 16.23, collecté après le gel des priors et du modèle).
# Rien n'est réappris : le modèle (outil/data/model.json) et les priors sont figés ; on compare au côté seul.
# Étapes : python3 ../../outil/... (voir LISEZMOI) ; en bref :
#   python3 dump_parties.py parties.json meta.json
#   node tool_clean.js ../../outil parties.json > composantes.json
#   python3 eval_futur.py composantes.json meta.json ../../outil/data/model.json 2026-11-19 [16.23]
import json, sys, datetime as dt, numpy as np
from sklearn.metrics import log_loss, roc_auc_score
P = np.array(json.load(open(sys.argv[1])), float); M = json.load(open(sys.argv[2])); MOD = json.load(open(sys.argv[3]))
since = dt.datetime.fromisoformat(sys.argv[4]).timestamp(); patch = sys.argv[5] if len(sys.argv) > 5 else None
sel = np.array([m['t'] >= since and (patch is None or m['p'] == patch) for m in M])
y = np.array([m['y'] for m in M])[sel]; fl = np.array([m['q'] == 440 for m in M], float)[sel]
pts = P[sel] @ np.array(MOD['mult']) + MOD['side'] + MOD['flex'] * fl
p = 1 / (1 + np.exp(-pts / 25)); p0 = 1 / (1 + np.exp(-(MOD['side'] + MOD['flex'] * fl) / 25))
li = lambda q: -(y * np.log(q) + (1 - y) * np.log(1 - q)); d = li(p0) - li(p)
rng = np.random.default_rng(0); bs = [d[rng.integers(0, len(d), len(d))].mean() for _ in range(2000)]
print(f'{sel.sum()} parties ; log loss côté seul {log_loss(y, p0):.5f}, modèle {log_loss(y, p):.5f} ; gain {d.mean():+.5f} IC95 {np.percentile(bs, [2.5, 97.5]).round(5)} ; AUC {roc_auc_score(y, p):.4f}')
bins = np.digitize(p, [.4, .45, .5, .55, .6])
print('calibration (prévu, observé, n)', [(round(float(p[bins == k].mean()), 3), round(float(y[bins == k].mean()), 3), int((bins == k).sum())) for k in range(6) if (bins == k).sum()])
