// Charge le moteur de l'outil actuel (sans interface) et calcule draftScore pour des parties
const fs = require('fs'), vm = require('vm'), zlib = require('zlib');
const D = '/home/claude/draft/';
const src = fs.readFileSync(D + 'data.js', 'utf8') + '\n' + fs.readFileSync(D + 'app.js', 'utf8') + '\n' + fs.readFileSync(D + 'comp.js', 'utf8') + '\n' + fs.readFileSync(D + 'fit.js', 'utf8') + '\n' +
  'const CTX=' + fs.readFileSync(D + 'data/ctx.json', 'utf8') + ';\nconst PRODRAFT=' + fs.readFileSync(D + 'data/prodraft.json', 'utf8').trim() + ';\nconst PROSHAPE=' + fs.readFileSync(D + 'data/proshape.json', 'utf8').trim() + ';\nconst BIAS=' + fs.readFileSync(D + 'data/bias.json', 'utf8') + ';\nconst MODEL=' + fs.readFileSync(D + 'data/model.json', 'utf8') + ';\n' + fs.readFileSync(D + 'ctx.js', 'utf8') +
  '\n;globalThis.__api = { draftScore, BY, S, ROLES };';
const ctx = { console, localStorage: { getItem: () => null, setItem: () => {} }, window: {}, document: { addEventListener() {}, querySelector() { return null; } }, setTimeout, Math, JSON };
ctx.globalThis = ctx; vm.createContext(ctx); vm.runInContext(src, ctx);
const api = ctx.__api;
const mode = process.argv[3] || 'solo';
api.S.ref = mode; api.S.side = 'B';
const games = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
const out = games.map(g => {
  const B = {}, R = {};
  for (const r of api.ROLES) { B[r] = api.BY[g.B[r]]; R[r] = api.BY[g.R[r]]; }
  if (api.ROLES.some(r => !B[r] || !R[r])) return null;
  const s = api.draftScore(B, R);
  return { wr: s.wr, parts: s.parts.map(p => p[1]) };
});
process.stdout.write(JSON.stringify(out));
