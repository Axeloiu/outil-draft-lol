# Même bilan, mais à niveau d'équipe égal : régression du vainqueur sur la prévision de l'outil ET l'écart d'Elo.
# Une pente de 1 sur la prévision = calibrée ; l'écart moyen restant (à Elo égal) = biais propre à la simulation.
import json, sys, collections, numpy as np
from sklearn.linear_model import LogisticRegression
G = json.load(open(sys.argv[1])); R0 = collections.defaultdict(float); E = []
for g in G:
    d = R0[g['tb']] - R0[g['tr']]; E.append(d); p = 1 / (1 + 10 ** (-d / 400)); R0[g['tb']] += 32 * (g['w'] - p); R0[g['tr']] -= 32 * (g['w'] - p)
E = np.array(E)
for f in sys.argv[2:]:
    R = json.load(open(f)); i = np.array([r['i'] for r in R]); y = np.array([r['y'] for r in R])
    for key in ('sim6', 'fin'):
        x = np.array([r[key] for r in R]) / 100; lg = np.log((0.5 + x) / (0.5 - x))  # logit du WR prévu
        Z = np.column_stack([lg, E[i] / 400 * np.log(10)])
        m = LogisticRegression(C=1e6).fit(Z, y)
        off = LogisticRegression(C=1e6, fit_intercept=False).fit(np.ones((len(y), 1)), y)  # (référence)
        # biais à Elo égal : intercept quand la pente est fixée à 1 (offset)
        from scipy.optimize import minimize_scalar
        el = m.coef_[0][1] * Z[:, 1]
        nll = lambda a: -np.sum(y * (lg + el + a) - np.log1p(np.exp(lg + el + a)))
        a = minimize_scalar(nll).x
        print(f'{f.split("/")[-1]:24s} {key:5s} pente sur la prévision {m.coef_[0][0]:.2f} ; biais à Elo égal {-a*25:+.2f} pts (positif = l’outil surestime le bleu)')
