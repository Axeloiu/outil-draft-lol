# Construction des variables du modèle de draft (point de vue : côté bleu)
import gzip, json, glob, collections, os
import numpy as np, scipy.sparse as sp

ROLES = ['top', 'jgl', 'mid', 'adc', 'sup']
LET = 'epkodfswchmguaxyt'
HERE = os.path.dirname(os.path.abspath(__file__))
# chemins par défaut : le dossier du projet ; surchargeables par OUTIL_DIR et ROWS_DIR
OUTIL = os.environ.get('OUTIL_DIR', os.path.join(HERE, '..', '..', 'outil'))
ROWS = os.environ.get('ROWS_DIR', os.path.join(HERE, '..', '..', 'donnees', 'rows'))
D = json.loads(open(os.path.join(OUTIL, 'data.js')).read()[len('const DATA='):-2])
TR = {c['id']: dict(zip(LET, c['tr'])) for c in D['champs']}
DM = {c['id']: c['d'] for c in D['champs']}
NAME = {c['id']: c['n'] for c in D['champs']}


def prof(c):
    t, d = TR.get(c), DM.get(c)
    if not t:
        return None
    carry = d != 'T' and t['f'] <= 1
    return {
        'AD': d == 'AD', 'AP': d == 'AP', 'tank': d == 'T', 'engage': t['e'] >= 2, 'peel': t['p'] >= 2,
        'poke': t['o'] >= 2, 'dive': t['d'] >= 3, 'front': t['f'] >= 2, 'pick': t['k'] >= 2, 'antitank': t['a'] >= 2,
        'early': t['c'] == 0, 'late': t['c'] == 2, 'melee': t['g'] == 0, 'carry_imm': carry and t['m'] == 0,
        'hyper': t['h'] >= 1, 'mobile': t['m'] >= 2,
    }


PK = list(prof(D['champs'][0]['id']).keys())


def load_rows():
    R = []
    for f in sorted(glob.glob(os.path.join(ROWS, '*.jsonl.gz'))):
        with gzip.open(f, 'rt') as fh:
            R += [json.loads(l) for l in fh]
    out = []
    for r in R:
        if r['w'] not in ('B', 'R'):
            continue
        ok = True
        tm = {}
        for s in 'BR':
            m = {x[1]: x[0] for x in r[s]}
            if sorted(m) != sorted(ROLES):
                ok = False
                break
            tm[s] = m
        if ok:
            out.append({'B': tm['B'], 'R': tm['R'], 'y': 1 if r['w'] == 'B' else 0, 'q': r['q'], 'p': r['p'], 'd': r['d'], 't': r['t']})
    return out


def comp_vec(m):
    v = np.zeros(len(PK))
    for r in ROLES:
        p = prof(m[r])
        if p:
            v += np.array([p[k] for k in PK], float)
    return v


class Featurizer:
    """Groupes : base, champ (champion|rôle), duel (même rôle), ally (paires d'une équipe), cross (paires adverses hors lane),
    comp (profil de compo : différences, interactions internes, interactions face à face)."""

    def __init__(self, games, min_pair=30):
        cnt = collections.Counter()
        for g in games:
            for k, _ in self._pairs(g):
                cnt[k] += 1
        self.idx = {}
        self.group = []
        def add(k, grp):
            if k not in self.idx:
                self.idx[k] = len(self.group)
                self.group.append(grp)
        for k in ('base:flex', 'base:16.21'):
            add(k, 'base')
        for k, n in cnt.items():
            grp = k[0]
            if grp == 'champ' or n >= min_pair:
                add(k, grp)
        n = len(PK)
        self.comp_names = [f'diff:{a}' for a in PK] + [f'in:{PK[i]}*{PK[j]}' for i in range(n) for j in range(i, n)] + \
                          [f'vs:{PK[i]}>{PK[j]}' for i in range(n) for j in range(n) if i != j]
        for k in self.comp_names:
            add(('comp', k), 'comp')
        self.group = np.array(self.group)

    @staticmethod
    def _pairs(g):
        B, R = g['B'], g['R']
        for r in ROLES:
            yield ('champ', B[r], r), 1
            yield ('champ', R[r], r), -1
            a, b = B[r], R[r]
            yield (('duel', a, b, r), 1) if a < b else (('duel', b, a, r), -1)
        for s, sg in ((B, 1), (R, -1)):
            for i in range(5):
                for j in range(i + 1, 5):
                    ri, rj = ROLES[i], ROLES[j]
                    yield ('ally', s[ri], ri, s[rj], rj), sg
        for ri in ROLES:
            for rj in ROLES:
                if ri == rj:
                    continue
                a, b = (B[ri], ri), (R[rj], rj)
                yield (('cross',) + a + b, 1) if a < b else (('cross',) + b + a, -1)

    def comp_feats(self, g):
        b, r = comp_vec(g['B']), comp_vec(g['R'])
        n = len(PK)
        diff = b - r
        inn = [b[i] * b[j] - r[i] * r[j] for i in range(n) for j in range(i, n)]
        vs = [b[i] * r[j] - r[i] * b[j] for i in range(n) for j in range(n) if i != j]
        return np.concatenate([diff, inn, vs])

    def matrix(self, games):
        rows, cols, vals = [], [], []
        comp_off = self.idx[('comp', self.comp_names[0])]
        for i, g in enumerate(games):
            if g['q'] == 440:
                rows.append(i); cols.append(self.idx['base:flex']); vals.append(1.0)
            if g['p'] == '16.21':
                rows.append(i); cols.append(self.idx['base:16.21']); vals.append(1.0)
            acc = collections.defaultdict(float)
            for k, s in self._pairs(g):
                j = self.idx.get(k)
                if j is not None:
                    acc[j] += s
            for j, v in acc.items():
                if v:
                    rows.append(i); cols.append(j); vals.append(v)
            cf = self.comp_feats(g)
            for t, v in enumerate(cf):
                if v:
                    rows.append(i); cols.append(comp_off + t); vals.append(v)
        X = sp.csr_matrix((vals, (rows, cols)), shape=(len(games), len(self.group)))
        y = np.array([g['y'] for g in games])
        return X, y
