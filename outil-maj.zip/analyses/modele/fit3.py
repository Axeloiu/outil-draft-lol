# Modèle de fin de draft, version 3 : entraîné et testé UNIQUEMENT sur des parties postérieures aux priors
# (u.gg daté du 07/11/2026 : les parties d'avant sont dans les priors, ce qui gonfle leurs poids et l'évaluation).
# Découpage chronologique : 70 % les plus anciennes pour l'entraînement, 10 % pour le réglage, 20 % les plus récentes pour le test.
# Usage : python3 fit3.py <prior_parts.json> <meta.json> <sortie.pkl> [random]
import sys, json, pickle, time, datetime as dt
import numpy as np, scipy.sparse as sp
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import log_loss, roc_auc_score
from feat import load_rows, Featurizer
t0 = time.time()
PRIOR_DATE = dt.datetime(2026, 11, 8).timestamp()
games = load_rows()
PP = np.array(json.load(open(sys.argv[1])), float) / 100
meta = json.load(open(sys.argv[2])); assert len(meta) == len(games) and all(m['t'] == g['t'] for m, g in zip(meta[:1000], games[:1000]))
t = np.array([g['t'] for g in games]); y = np.array([g['y'] for g in games])
keep = np.where(t >= PRIOR_DATE)[0]
if len(sys.argv) > 4 and sys.argv[4] == 'random':
    order = keep[np.random.default_rng(7).permutation(len(keep))]
else:
    order = keep[np.argsort(t[keep], kind='stable')]
n = len(order); tr_i, va_i, te_i = order[:int(.7 * n)], order[int(.7 * n):int(.8 * n)], order[int(.8 * n):]
G = lambda ix: [games[i] for i in ix]
F = Featurizer(G(tr_i), min_pair=30)
# paires d'alliés adc + support à part (duos premade possibles en solo/duo)
inv = {v: k for k, v in F.idx.items()}
grp = F.group.astype(object)
for j, k in inv.items():
    if isinstance(k, tuple) and k[0] == 'ally' and {k[2], k[4]} == {'adc', 'sup'}: grp[j] = 'allybot'
F.group = np.array(list(grp) + ['prior'] * 4)
NG = len(F.group) - 4
def M(ix):
    X, yy = F.matrix(G(ix)); return sp.hstack([X[:, :NG], sp.csr_matrix(PP[ix])]).tocsr(), yy
Xtr, ytr = M(tr_i); Xva, yva = M(va_i); Xte, yte = M(te_i)
cm = F.group == 'comp'; sd = np.ones(len(F.group))
sd[cm] = np.sqrt(np.asarray(Xtr[:, cm].multiply(Xtr[:, cm]).mean(axis=0)).ravel()) + 1e-9
print(f'{n} parties après les priors ; entraînement {len(tr_i)}, réglage {len(va_i)}, test {len(te_i)}', {g: int((F.group == g).sum()) for g in np.unique(F.group)}, f'{time.time()-t0:.0f}s', flush=True)
def fit(scales, X=Xtr, yy=ytr):
    s = np.array([scales[g] for g in F.group]) / sd
    m = LogisticRegression(C=1.0, max_iter=500, tol=1e-6).fit(X @ sp.diags(s), yy)
    return m.intercept_[0], m.coef_.ravel() * s
pred = lambda b, w, X: 1 / (1 + np.exp(-(X @ w + b)))
def ll(sc): b, w = fit(sc); return log_loss(yva, pred(b, w, Xva)), (b, w)
GROUPS = ['champ', 'duel', 'ally', 'allybot', 'cross', 'comp']
sc = {'base': 1.0, 'prior': 10.0, 'champ': 0.02, 'duel': 0.02, 'ally': 0.01, 'allybot': 0.01, 'cross': 0.01, 'comp': 0.01}
best, bw = ll(sc); print('départ', round(best, 5), flush=True)
for it in range(2):
    for g in GROUPS:
        for f in ((0.0, 0.25, 4) if it == 0 else (0.5, 2)):
            s2 = dict(sc); s2[g] = sc[g] * f if f else 1e-6
            v, bwv = ll(s2)
            if v < best - 1e-6: best, sc, bw = v, s2, bwv
        print(it, g, {k: round(v, 5) for k, v in sc.items()}, round(best, 5), f'{time.time()-t0:.0f}s', flush=True)
# modèle final sur entraînement + réglage, noté une fois sur le test
Xtv = sp.vstack([Xtr, Xva]).tocsr(); ytv = np.concatenate([ytr, yva])
b, w = fit(sc, Xtv, ytv); p = pred(b, w, Xte)
lli = lambda p, yy: -(yy * np.log(p) + (1 - yy) * np.log(1 - p))
rng = np.random.default_rng(1)
def boot(p0, p1, B=2000):
    d = lli(p0, yte) - lli(p1, yte); m = len(d); bs = [d[rng.integers(0, m, m)].mean() for _ in range(B)]
    return round(d.mean(), 5), np.percentile(bs, [2.5, 97.5]).round(5)
metr = lambda p: (round(log_loss(yte, p), 5), round(roc_auc_score(yte, p), 4), round(float(((p > .5) == yte).mean()), 4))
fl = lambda ix: np.array([games[i]['q'] == 440 for i in ix], float)[:, None]
side = LogisticRegression(C=1e6).fit(fl(np.concatenate([tr_i, va_i])), ytv); ps = side.predict_proba(fl(te_i))[:, 1]
Ztv = np.column_stack([PP[np.concatenate([tr_i, va_i])], fl(np.concatenate([tr_i, va_i]))]); Zte = np.column_stack([PP[te_i], fl(te_i)])
pr_ = LogisticRegression(C=1e6).fit(Ztv, ytv); pp = pr_.predict_proba(Zte)[:, 1]
print('TEST côté seul', metr(ps)); print('TEST priors seuls recalibrés', metr(pp), 'gain sur côté', boot(ps, pp))
print('TEST modèle', metr(p), 'gain sur côté', boot(ps, p), 'gain sur priors', boot(pp, p))
bins = np.digitize(p, [.35, .4, .45, .5, .55, .6, .65])
print('calibration', [(round(float(p[bins == k].mean()), 3), round(float(yte[bins == k].mean()), 3), int((bins == k).sum())) for k in range(8) if (bins == k).sum()])
for g in GROUPS:
    s2 = dict(sc); s2[g] = 1e-6; b2, w2 = fit(s2, Xtv, ytv); p2 = pred(b2, w2, Xte)
    print('sans', g, 'apport du groupe', boot(p2, p))
print('côté bleu', round(b * 25, 2), 'pts ; flex', round(float(w[F.idx['base:flex']]) * 25, 2), 'pts ; poids des priors', np.round(w[-4:] / 4, 3))
pickle.dump({'F': F, 'sc': sc, 'sd': sd, 'b': b, 'w': w, 'split': (tr_i, va_i, te_i)}, open(sys.argv[3], 'wb'))
