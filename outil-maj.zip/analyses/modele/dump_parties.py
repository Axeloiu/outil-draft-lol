# Exporte les parties Master+ (ordre de feat.load_rows) : parties.json (champions) et meta.json (vainqueur, file, patch, durée, date)
# Usage : python3 dump_parties.py parties.json meta.json
import sys, json, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from feat import load_rows
G = load_rows()
json.dump([{'B': g['B'], 'R': g['R']} for g in G], open(sys.argv[1], 'w'))
json.dump([{k: g[k] for k in ('y', 'q', 'p', 'd', 't')} for g in G], open(sys.argv[2], 'w'))
print(len(G), 'parties')
