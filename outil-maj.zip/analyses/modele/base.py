import json, numpy as np
from sklearn.metrics import log_loss, roc_auc_score
from sklearn.linear_model import LogisticRegression
from feat import load_rows
games = load_rows(); n = len(games); perm = np.random.default_rng(7).permutation(n)
tr, va, te = perm[:int(.7*n)], perm[int(.7*n):int(.8*n)], perm[int(.8*n):]
y = np.array([g['y'] for g in games])
def metr(p, yy): return round(log_loss(yy, p), 5), round(roc_auc_score(yy, p), 4), round(((p > .5) == yy).mean(), 4)
pb = y[tr].mean(); print('taux de victoire bleu (entraînement)', round(pb, 4))
print('côté seul', metr(np.full(len(te), pb), y[te]))
for m in ('solo', 'pro'):
    tv = json.load(open(f'/tmp/tool_va_{m}.json')); tt = json.load(open(f'/tmp/tool_te_{m}.json'))
    ok_v = np.array([x is not None for x in tv]); ok_t = np.array([x is not None for x in tt])
    wv = np.array([x['wr'] if x else 50 for x in tv]) / 100; wt = np.array([x['wr'] if x else 50 for x in tt]) / 100
    print(m, 'manquants', (~ok_t).sum(), 'brut', metr(wt, y[te]))
    # recalibré : intercept (côté) + pente apprise sur la validation
    lr = LogisticRegression(C=1e6).fit(np.log(wv / (1 - wv))[:, None], y[va])
    pt = lr.predict_proba(np.log(wt / (1 - wt))[:, None])[:, 1]
    print(m, 'recalibré', metr(pt, y[te]), 'pente', round(lr.coef_[0][0], 3), 'intercept', round(lr.intercept_[0], 3))
    # parties : quelle composante prédit
    Pv = np.array([x['parts'] if x else [0]*5 for x in tv]); Pt = np.array([x['parts'] if x else [0]*5 for x in tt])
    lr2 = LogisticRegression(C=1e6).fit(Pv / 100, y[va]); print(m, 'par composante', metr(lr2.predict_proba(Pt / 100)[:, 1], y[te]), np.round(lr2.coef_[0] / 4, 3))
    # calibration brute par tranches
    bins = np.digitize(wt, [.4, .45, .48, .5, .52, .55, .6])
    print(m, 'calibration brute', [(round(wt[bins == b].mean(), 3), round(y[te][bins == b].mean(), 3), int((bins == b).sum())) for b in range(8) if (bins == b).sum()])
