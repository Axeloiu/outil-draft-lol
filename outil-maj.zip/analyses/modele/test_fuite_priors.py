# Usage : python3 test_fuite_priors.py composantes.json meta.json
# Test de fuite : les priors u.gg sont datés du 07/11/2026. Les parties jouées après ne peuvent pas y être.
import json, sys, numpy as np, datetime as dt
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import log_loss, roc_auc_score
P = np.array(json.load(open(sys.argv[1]))) / 100
M = json.load(open(sys.argv[2]))
y = np.array([m['y'] for m in M]); t = np.array([m['t'] for m in M]); fl = np.array([m['q'] == 440 for m in M], float)
cut = dt.datetime(2026, 11, 8).timestamp()
X = np.column_stack([P, fl])
post = t >= cut
print('parties avant le 8/11', (~post).sum(), 'après', post.sum())
rng = np.random.default_rng(0)
def boot(l0, l1, B=1000):
    d = l0 - l1; m = len(d); bs = [d[rng.integers(0, m, m)].mean() for _ in range(B)]
    return round(d.mean(), 5), np.percentile(bs, [2.5, 97.5]).round(5)
def ll_i(p, yy): return -(yy * np.log(p) + (1 - yy) * np.log(1 - p))
# entraînement de la recalibration sur une moitié aléatoire des parties d'avant, test sur l'autre moitié d'avant et sur l'après
pre_idx = np.where(~post)[0]; rng.shuffle(pre_idx); a, b = pre_idx[:len(pre_idx) // 2], pre_idx[len(pre_idx) // 2:]
lr = LogisticRegression(C=1e6).fit(X[a], y[a]); base = LogisticRegression(C=1e6).fit(fl[a][:, None], y[a])
print('poids (pts par pt)', (lr.coef_[0] / 4).round(3), 'intercept', round(lr.intercept_[0] * 25, 2))
for lab, ix in [('avant (même période que les priors)', b), ('après le 7/11 (hors priors)', np.where(post)[0])]:
    p = lr.predict_proba(X[ix])[:, 1]; p0 = base.predict_proba(fl[ix][:, None])[:, 1]
    print(f'{lab:38s} n={len(ix)} AUC {roc_auc_score(y[ix], p):.4f}  gain de log loss sur côté seul', boot(ll_i(p0, y[ix]), ll_i(p, y[ix])))
    # par composante
    for k, nm in enumerate(['force', 'synergies', 'duels', 'compo']):
        Xk = np.column_stack([P[:, k], fl]); lk = LogisticRegression(C=1e6).fit(Xk[a], y[a]); pk = lk.predict_proba(Xk[ix])[:, 1]
        print(f'     {nm:10s} pente {lk.coef_[0][0]/4:.3f}  gain', boot(ll_i(p0, y[ix]), ll_i(pk, y[ix]))[0])
# pentes estimées sur l'après seul (moitié) : si les priors « connaissent » les parties d'avant, la pente d'avant est gonflée
pi = np.where(post)[0]; rng.shuffle(pi)
lr2 = LogisticRegression(C=1e6).fit(X[pi[:len(pi)//2]], y[pi[:len(pi)//2]])
print('pentes estimées sur l\'après', (lr2.coef_[0] / 4).round(3))
