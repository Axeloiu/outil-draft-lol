import pickle, json, sys
import numpy as np, scipy.sparse as sp
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import log_loss, roc_auc_score
sys.argv = ['x', '30']
exec(open('fit2.py').read().split("sc = {'base'")[0])  # mêmes données et fonctions que l'entraînement
P = pickle.load(open('fit2.pkl', 'rb'))
sc = P['sc']
# modèle final appris sur entraînement + validation, noté une seule fois sur le test
Xtv = sp.vstack([Xtr, Xva]).tocsr(); ytv = np.concatenate([ytr, yva])
b, w = fit(sc, Xtv, ytv)
p = pred(b, w, Xte)
def metr(p, y=yte): return round(log_loss(y, p), 5), round(roc_auc_score(y, p), 4), round(float(((p > .5) == y).mean()), 4)
print('MODELE test', metr(p))
pb = ytv.mean(); print('côté seul', metr(np.full(len(yte), pb)))
# outil actuel recalibré (côté + pente) sur entraînement+validation
T = np.array([x['wr'] for x in json.load(open('/tmp/tool_all_solo.json'))]) / 100
lt = np.log(T / (1 - T))
lr = LogisticRegression(C=1e6).fit(lt[np.concatenate([tr_i, va_i])][:, None], ytv)
print('OUTIL recalibré test', metr(lr.predict_proba(lt[te_i][:, None])[:, 1]))
print('OUTIL brut test', metr(T[te_i]))
# calibration du modèle
bins = np.digitize(p, [.35, .4, .45, .5, .55, .6, .65])
print('calibration', [(round(float(p[bins == k].mean()), 3), round(float(yte[bins == k].mean()), 3), int((bins == k).sum())) for k in range(8) if (bins == k).sum()])
# ablations : retirer un groupe (réappris)
for g in ['champ', 'duel', 'ally', 'cross', 'comp']:
    s2 = dict(sc); s2[g] = 1e-6
    b2, w2 = fit(s2, Xtv, ytv)
    print('sans', g, metr(pred(b2, w2, Xte)))
print('base', {k: round(float(w[F.idx[k]]), 3) for k in ('base:flex', 'base:16.21')}, 'intercept (bleu)', round(float(b), 3))
print('poids des composantes de l\'outil', np.round(w[-5:] , 3))
inv = {v: k for k, v in F.idx.items() if isinstance(k, tuple)}
from feat import NAME
NM = lambda c: NAME.get(c, str(c))
for g in ['duel', 'ally', 'cross', 'comp', 'champ']:
    ix = np.where(F.group == g)[0]
    top = ix[np.argsort(-np.abs(w[ix]))][:12]
    print('==', g)
    for j in top:
        k = inv.get(j)
        lab = k[1] if g == "comp" else ' '.join(NM(x) if isinstance(x, int) else x for x in k[1:])
        print(f'   {w[j] * 25:+.2f} pts', lab)
pickle.dump({'b': b, 'w': w, 'sc': sc}, open('final.pkl', 'wb'))
