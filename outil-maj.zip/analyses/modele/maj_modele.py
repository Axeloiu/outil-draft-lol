# Garde-fou et réapprentissage du modèle Master+ (priors recalés + côté + flex).
# Apprend sur les 80 % de parties les plus anciennes (postérieures aux priors), compare au modèle en place sur les 20 % les
# plus récentes ; si le nouveau ne fait pas moins bien (tolérance), réapprend sur toutes ces parties et écrit le candidat.
# Usage : python3 maj_modele.py composantes.json meta.json model_actuel.json date_priors tolerance sortie.json
import json, sys, datetime as dt, numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import log_loss
P = np.array(json.load(open(sys.argv[1])), float) / 100; M = json.load(open(sys.argv[2])); CUR = json.load(open(sys.argv[3]))
since = (dt.datetime.fromisoformat(sys.argv[4]) + dt.timedelta(days=1)).timestamp(); tol = float(sys.argv[5])
y = np.array([m['y'] for m in M]); t = np.array([m['t'] for m in M]); fl = np.array([m['q'] == 440 for m in M], float)
k = np.where(t >= since)[0]; k = k[np.argsort(t[k], kind='stable')]; n = len(k)
tr, te = k[:int(.8 * n)], k[int(.8 * n):]
X = np.column_stack([P, fl])
m = LogisticRegression(C=1e6).fit(X[tr], y[tr]); pn = m.predict_proba(X[te])[:, 1]
cur = 1 / (1 + np.exp(-((P[te] * 100) @ np.array(CUR['mult']) + CUR['side'] + CUR.get('flex', 0) * fl[te]) / 25))
side = LogisticRegression(C=1e6).fit(fl[tr][:, None], y[tr]).predict_proba(fl[te][:, None])[:, 1]
ll_n, ll_c, ll_s = log_loss(y[te], pn), log_loss(y[te], cur), log_loss(y[te], side)
ok = n >= 20000 and ll_n <= ll_c + tol and ll_n < ll_s
res = {'n': int(n), 'n_test': int(len(te)), 'll_nouveau': ll_n, 'll_actuel': ll_c, 'll_cote': ll_s, 'accepte': bool(ok)}
if ok:
    m = LogisticRegression(C=1e6).fit(X[k], y[k]); co = m.coef_[0]
    out = dict(CUR); out.update({'n': int(n), 'side': round(float(m.intercept_[0] * 25), 3), 'flex': round(float(co[4] * 25), 3), 'mult': [round(float(c / 4), 4) for c in co[:4]]})
    json.dump(out, open(sys.argv[6], 'w'), separators=(',', ':')); res.update({'mult': out['mult'], 'side': out['side'], 'flex': out['flex']})
print(json.dumps(res))
