// Type de compo principal (coherence().id.main) de chaque équipe : parties pros et parties flex/solo Master+
const { JSDOM, VirtualConsole } = require('jsdom'); const fs = require('fs');
const vc = new VirtualConsole(); const dom = new JSDOM(fs.readFileSync(process.argv[2], 'utf8'), { runScripts: 'dangerously', pretendToBeVisual: true, virtualConsole: vc, url: 'https://example.org/' });
const w = dom.window; const W = '/home/claude/w/maj_test/sortie/travail/';
setTimeout(() => {
  const PG = JSON.parse(fs.readFileSync(W + 'pro_games.json')), G = JSON.parse(fs.readFileSync(W + 'parties.json')), M = JSON.parse(fs.readFileSync(W + 'meta.json'));
  w.PGX = PG.map(g => [g.B, g.R].map(t => { const o = {}; t.forEach(([id, r]) => o[r] = id); return o; }));
  const keep = []; G.forEach((g, i) => { if (M[i].q === 440 && M[i].t >= Date.UTC(2026, 10, 8) / 1000) keep.push(i); });
  w.GX = keep.map(i => [G[i].B, G[i].R]);
  const t0 = Date.now();
  const typ = w.eval(`(() => { const R = ['top','jgl','mid','adc','sup']; const f = (A, B) => { try { const a = R.map(r => BY[A[r]]), b = R.map(r => BY[B[r]]); if (a.some(x => !x) || b.some(x => !x)) return null; return coherence(a, b).id.main; } catch (e) { return null; } };
    return JSON.stringify({ pro: PGX.map(([A, B]) => [f(A, B), f(B, A)]), flex: GX.map(([A, B]) => [f(A, B), f(B, A)]) }); })()`);
  const o = JSON.parse(typ); o.flexIdx = keep;
  fs.writeFileSync('/home/claude/w/types_compos.json', JSON.stringify(o));
  const cnt = {}; o.pro.flat().forEach(x => cnt[x] = (cnt[x] || 0) + 1);
  console.log(`${Date.now() - t0} ms ; pro ${o.pro.length}, flex ${o.flex.length} ; types pro :`, cnt); process.exit(0);
}, 2000);
