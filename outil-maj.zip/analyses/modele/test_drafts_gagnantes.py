# Les drafts que l'outil estime gagnantes gagnent-elles vraiment autant qu'il le dit ?
# Master+ : poids appris sur les 80 % de parties les plus anciennes (après les priors), vérifiés sur les 20 % les plus récentes.
# Pros : formule de l'outil (Elo appris puis mis à 0, comme à l'usage), apprise en avançant dans le temps.
# Usage : python3 test_drafts_gagnantes.py composantes.json meta.json pro_games.json pro_solo.json
import json, sys, datetime as dt, collections, numpy as np
from sklearn.linear_model import LogisticRegression
P = np.array(json.load(open(sys.argv[1])), float) / 100; M = json.load(open(sys.argv[2]))
y = np.array([m['y'] for m in M]); t = np.array([m['t'] for m in M]); fl = np.array([m['q'] == 440 for m in M], float)
k = np.where(t >= dt.datetime(2026, 11, 8).timestamp())[0]; k = k[np.argsort(t[k], kind='stable')]
tr, te = k[:int(.8 * len(k))], k[int(.8 * len(k)):]
X = np.column_stack([P, fl]); m = LogisticRegression(C=1e6).fit(X[tr], y[tr])
w = m.coef_[0]; draft = (P[te] @ w[:4]) * 25; p = m.predict_proba(X[te])[:, 1]
def table(score, prob, yy, edges, lab):
    print(lab)
    b = np.digitize(score, edges)
    for i in range(len(edges) + 1):
        s = b == i
        if s.sum() < 30: continue
        lo = '−∞' if i == 0 else f'{edges[i-1]:+g}'; hi = '+∞' if i == len(edges) else f'{edges[i]:+g}'
        e = 1.96 * np.sqrt(yy[s].mean() * (1 - yy[s].mean()) / s.sum())
        print(f'   draft {lo:>4s} à {hi:>4s} pts  n={s.sum():6d}  prévu {prob[s].mean()*100:5.1f} %  observé {yy[s].mean()*100:5.1f} % ± {e*100:.1f}')
# du point de vue de l'équipe qui a la meilleure draft (on retourne les parties où c'est le rouge)
sg = np.where(draft >= 0, 1, -1); sc = draft * sg; pr = np.where(sg > 0, p, 1 - p); yy = np.where(sg > 0, y[te], 1 - y[te])
table(sc, pr, yy, [1, 2, 3, 4, 5, 6, 8], f'Master+ : {len(te)} parties récentes, du point de vue de la meilleure draft (côté compris dans « prévu »)')
# --- pros
G = json.load(open(sys.argv[3])); S = np.array(json.load(open(sys.argv[4])), float); n = len(G)
yp = np.array([g['w'] for g in G]); day = np.array([(np.datetime64(g['dt'][:10]) - np.datetime64('2026-01-01')).astype(int) for g in G], float)
R = collections.defaultdict(float); E = np.zeros(n)
for i, g in enumerate(G):
    d = R[g['tb']] - R[g['tr']]; E[i] = d; pe = 1 / (1 + 10 ** (-d / 400)); R[g['tb']] += 32 * (g['w'] - pe); R[g['tr']] -= 32 * (g['w'] - pe)
W = collections.defaultdict(lambda: [0, 0]); PW = np.zeros(n)
for i, g in enumerate(G):
    PW[i] = 100 * sum(sg_ * ((W[c][1] + 100) / (W[c][0] + 200) - .5) for s_, sg_ in (('B', 1), ('R', -1)) for c, r in g[s_])
    for s_ in 'BR':
        for c, r in g[s_]: W[c][0] += 1; W[c][1] += (g['w'] == 1) == (s_ == 'B')
start = n // 3; idx = np.arange(start, n); Pp = []; Yp = []; Dp = []
for b in np.array_split(idx, 8)[1:]:
    trn = np.arange(start, b[0]); Z = np.column_stack([E, PW, S])
    lr = LogisticRegression(C=1e4).fit(Z[trn], yp[trn]); Zb = Z[b].copy(); Zb[:, 0] = 0  # Elo mis à 0, comme dans l'outil
    Pp += list(lr.predict_proba(Zb)[:, 1]); Yp += list(yp[b]); Dp += list((Zb[:, 1:] @ lr.coef_[0][1:]) * 25)
Pp, Yp, Dp = map(np.array, (Pp, Yp, Dp))
sg = np.where(Dp >= 0, 1, -1); table(Dp * sg, np.where(sg > 0, Pp, 1 - Pp), np.where(sg > 0, Yp, 1 - Yp), [2, 4, 6, 8, 10, 13, 16], f'\nPros : {len(Yp)} parties, du point de vue de la meilleure draft (côté bleu compris dans « prévu », Elo mis à 0)')
