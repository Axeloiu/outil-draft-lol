const fs = require('fs'), vm = require('vm'); const D = '/home/claude/draft/';
const src = fs.readFileSync(D + 'data.js', 'utf8') + '\n' + fs.readFileSync(D + 'app.js', 'utf8') + '\n;globalThis.__api = { wrVs, BY };';
const ctx = { console, localStorage: { getItem: () => null, setItem: () => {} }, window: {}, document: { addEventListener() {}, querySelector() { return null; } }, setTimeout, Math, JSON };
ctx.globalThis = ctx; vm.createContext(ctx); vm.runInContext('const MODEL=' + fs.readFileSync(D + 'data/model.json', 'utf8') + ';\n' + src, ctx);
const { wrVs, BY } = ctx.__api;
const todo = JSON.parse(fs.readFileSync('/tmp/lanepairs.json', 'utf8'));
process.stdout.write(JSON.stringify(todo.map(([r, a, b]) => (BY[a] && BY[b]) ? wrVs(BY[a], BY[b], r).wr : null)));
