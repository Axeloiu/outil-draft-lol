// Composantes « a priori » de l'outil (u.gg / LoLalytics seuls), SANS aucune correction apprise :
// MODEL est neutralisé (ch, du, al vides, comp à 0, multiplicateurs à 1, côté à 0) et le recalage pro aussi (mt = 1, mp = 0).
// Sortie : pour chaque partie, [force, synergies, duels, compo contre compo] en points, du point de vue bleu.
// Usage : node tool_clean.js <dossier outil> <parties.json> > composantes.json
const fs = require('fs'), vm = require('vm');
const D = process.argv[2].replace(/\/?$/, '/');
const rd = f => fs.readFileSync(D + f, 'utf8');
const real = JSON.parse(rd('data/model.json'));
const neutral = { n: 0, patch: real.patch, side: 0, flex: 0, mult: [1, 1, 1, 1, 0], pk: real.pk, comp: real.comp.map(() => 0), ch: {}, du: {}, al: {} };
const src = rd('data.js') + '\n' + rd('app.js') + '\n' + rd('comp.js') + '\n' + rd('fit.js') + '\nconst CTX=' + rd('data/ctx.json') + ';\nconst PRODRAFT=' + rd('data/prodraft.json').trim() +
  ';\nconst PROSHAPE=' + rd('data/proshape.json').trim() + ';\nconst BIAS=' + rd('data/bias.json') + ';\nconst MODEL=' + JSON.stringify(neutral) + ';\nconst PRO26=' + JSON.stringify({ n: 0, K: 200, mt: 1, mp: 0, side: 0, wr: {} }) + ';\n' + rd('ctx.js') +
  '\n;globalThis.__api = { draftScore, BY, S, ROLES };';
const ctx = { console, localStorage: { getItem: () => null, setItem: () => {} }, window: {}, document: { addEventListener() {}, querySelector() { return null; } }, setTimeout, Math, JSON };
ctx.globalThis = ctx; vm.createContext(ctx); vm.runInContext(src, ctx);
const api = ctx.__api; api.S.ref = 'solo'; api.S.side = 'B';
const games = JSON.parse(fs.readFileSync(process.argv[3], 'utf8'));
process.stdout.write(JSON.stringify(games.map(g => {
  const B = {}, R = {};
  for (const r of api.ROLES) { B[r] = api.BY[g.B[r]]; R[r] = api.BY[g.R[r]]; }
  if (api.ROLES.some(r => !B[r] || !R[r])) return null;
  return api.draftScore(B, R).parts.slice(0, 4).map(p => +p[1].toFixed(4));
})));
