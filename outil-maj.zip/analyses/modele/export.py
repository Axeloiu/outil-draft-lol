import pickle, json, numpy as np
from feat import PK, ROLES
F = pickle.load(open('fit2.pkl', 'rb'))['F']
M = pickle.load(open('final.pkl', 'rb'))
w, b = M['w'], M['b']
inv = {v: k for k, v in F.idx.items()}
P = lambda x: round(float(x) * 25, 3)  # logit -> points de winrate (autour de 50 %)
ch, du, al = {}, {}, {}
for j, g in enumerate(F.group[:len(w) - 5]):
    k = inv.get(j); v = P(w[j])
    if g == 'champ' and abs(v) >= 0.02: ch[f'{k[1]}|{k[2]}'] = v
    elif g == 'duel' and abs(v) >= 0.05: du[f'{k[1]}|{k[2]}|{k[3]}'] = v
    elif g == 'ally' and abs(v) >= 0.05: al[f'{k[1]}|{k[2]}|{k[3]}|{k[4]}'] = v
co = [P(w[F.idx[('comp', n)]]) for n in F.comp_names]
k = w[-5:] / 4
out = {'n': 195440, 'patch': '16.22', 'side': P(b), 'flex': P(w[F.idx['base:flex']]),
       'mult': [round(float(x), 3) for x in k], 'pk': PK, 'comp': co, 'ch': ch, 'du': du, 'al': al}
json.dump(out, open('/home/claude/draft/data/model.json', 'w'), separators=(',', ':'))
print(len(ch), len(du), len(al), out['side'], out['flex'], out['mult'], len(json.dumps(out)))
