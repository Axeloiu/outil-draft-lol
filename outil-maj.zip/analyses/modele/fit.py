import pickle, time, sys
import numpy as np, scipy.sparse as sp
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import log_loss, roc_auc_score
from feat import load_rows, Featurizer

t0 = time.time()
games = load_rows()
rng = np.random.default_rng(7)
perm = rng.permutation(len(games))
n = len(games)
tr_i, va_i, te_i = perm[:int(.7 * n)], perm[int(.7 * n):int(.8 * n)], perm[int(.8 * n):]
G = lambda ix: [games[i] for i in ix]
F = Featurizer(G(tr_i), min_pair=int(sys.argv[1]) if len(sys.argv) > 1 else 30)
Xtr, ytr = F.matrix(G(tr_i)); Xva, yva = F.matrix(G(va_i)); Xte, yte = F.matrix(G(te_i))
# colonnes de compo standardisées
cm = F.group == 'comp'
sd = np.ones(len(F.group))
sd[cm] = np.sqrt(np.asarray(Xtr[:, cm].multiply(Xtr[:, cm]).mean(axis=0)).ravel()) + 1e-9
print(f'{n} parties, {len(F.group)} variables', {g: int((F.group == g).sum()) for g in np.unique(F.group)}, f'{time.time()-t0:.0f}s', flush=True)

GROUPS = ['base', 'champ', 'duel', 'ally', 'cross', 'comp']


def fit(scales, X=Xtr, y=ytr):
    s = np.array([scales[g] for g in F.group]) / sd
    D = sp.diags(s)
    m = LogisticRegression(C=1.0, max_iter=400, tol=1e-6)
    m.fit(X @ D, y)
    w = m.coef_.ravel() * s
    return m.intercept_[0], w


def pred(b, w, X):
    return 1 / (1 + np.exp(-(X @ w + b)))


def ll(scales):
    b, w = fit(scales)
    return log_loss(yva, pred(b, w, Xva)), (b, w)


sc = {'base': 1.0, 'champ': 0.05, 'duel': 0.02, 'ally': 0.02, 'cross': 0.02, 'comp': 0.02}
best, bw = ll(sc)
print('départ', round(best, 5), flush=True)
for it in range(3):
    for g in GROUPS[1:]:
        for f in (0.0, 0.25, 0.5, 2, 4):
            s2 = dict(sc); s2[g] = sc[g] * f if f else 1e-6
            v, bwv = ll(s2)
            if v < best - 1e-6:
                best, sc, bw = v, s2, bwv
        print(it, g, {k: round(v, 5) for k, v in sc.items()}, round(best, 5), f'{time.time()-t0:.0f}s', flush=True)
pickle.dump({'F': F, 'sc': sc, 'sd': sd, 'split': (tr_i, va_i, te_i), 'bw': bw}, open('/home/claude/model/fit.pkl', 'wb'))
print('fin', sc, best)
