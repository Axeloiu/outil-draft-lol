# Bilan de test_sim_pros.js : calibration de la prévision au 6e pick, comparée au côté seul et à la draft finale.
import json, sys, numpy as np
from sklearn.metrics import log_loss, roc_auc_score
R = json.load(open(sys.argv[1])); y = np.array([r['y'] for r in R]); s6 = np.array([r['sim6'] for r in R]); fin = np.array([r['fin'] for r in R])
pr = lambda pts: 1 / (1 + np.exp(-pts / 25)) if False else np.clip(0.5 + pts / 100, 0.01, 0.99)
p6, pf = pr(s6), pr(fin); side = np.full(len(y), y.mean())
for lab, p in [('côté seul (taux observé)', side), ('simulation au 6e pick', p6), ('draft finale réelle', pf)]:
    print(f'{lab:26s} log loss {log_loss(y, p):.5f}  AUC {roc_auc_score(y, p) if p.std() > 0 else 0.5:.4f}  WR prévu moyen {p.mean()*100:.1f} %  observé {y.mean()*100:.1f} %')
print('calibration au 6e pick, du point de vue de l’équipe favorite :')
sg = np.where(p6 >= .5, 1, -1); q = np.where(sg > 0, p6, 1 - p6); yy = np.where(sg > 0, y, 1 - y)
for lo, hi in [(.5, .53), (.53, .56), (.56, .59), (.59, .62), (.62, 1)]:
    m = (q >= lo) & (q < hi)
    if m.sum() > 30: print(f'   prévu {lo*100:.0f}-{hi*100:.0f} %  n={m.sum():5d}  prévu {q[m].mean()*100:.1f} %  observé {yy[m].mean()*100:.1f} % ± {196*np.sqrt(yy[m].mean()*(1-yy[m].mean())/m.sum()):.1f}')
