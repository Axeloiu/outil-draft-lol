// La simulation prévoit-elle juste en cours de draft ? On rejoue les drafts pros jusqu'au 6e pick (fin de la phase 1),
// on laisse l'outil simuler la fin (200 fins de draft) du point de vue du bleu, et on compare au vainqueur réel.
// Pools inconnus : chaque rôle prend les 6 champions les plus probables du terrain (aisance neutre).
// Usage : node test_sim_pros.js <dossier outil> <pro_games.json> <sortie.json> [pas]
const fs = require('fs'), vm = require('vm');
const D = process.argv[2].replace(/\/?$/, '/'); const rd = f => fs.readFileSync(D + f, 'utf8');
const src = rd('data.js') + '\n' + rd('app.js') + '\n' + rd('comp.js') + '\n' + rd('fit.js') + '\nconst CTX=' + rd('data/ctx.json') + ';\nconst PRODRAFT=' + rd('data/prodraft.json').trim() +
  ';\nconst PROSHAPE=' + rd('data/proshape.json').trim() + ';\nconst BIAS=' + rd('data/bias.json') + ';\nconst MODEL=' + rd('data/model.json') + ';\nconst PRO26=' + rd('data/pro2026.json') + ';\n' + rd('ctx.js') + '\n' + rd('sim.js') +
  '\n;globalThis.__api = { BY, S, ROLES, D, newDraft, simValue, simReset, simField, draftScore, SIM_OPT };';
const ctx = { console, localStorage: { getItem: () => null, setItem: () => {} }, window: {}, document: { addEventListener() {}, querySelector() { return null; } }, setTimeout: f => { f(); return 0; }, Math, JSON, Date };
ctx.globalThis = ctx; vm.createContext(ctx); vm.runInContext(src, ctx);
const A = ctx.__api;
const G = JSON.parse(fs.readFileSync(process.argv[3], 'utf8')); const step = +(process.argv[5] || 1);
A.SIM_OPT.us = process.argv[6] || 'outil'; // 'outil' : le bleu suit l'outil ; 'terrain' : le bleu joue comme les pros
A.S.mode = 'tourn'; A.S.side = 'B';
const F = A.simField(); A.S.team.forEach(p => { p.pool = F[p.role].slice(0, 6).map(o => o.c.id); p.comf = {}; });
const out = []; const t0 = Date.now();
for (let gi = Math.floor(G.length / 3); gi < G.length; gi += step) {
  const g = G[gi];
  if ([...g.B, ...g.R].some(([c]) => !A.BY[c])) continue;
  A.newDraft(); const d = A.D(); A.simReset();
  const bans = [g.bans[0][0], g.bans[1][0], g.bans[0][1], g.bans[1][1], g.bans[0][2], g.bans[1][2]].map(b => b && A.BY[b] ? b : null);
  const picks = [['B', 0], ['R', 0], ['R', 1], ['B', 1], ['B', 2], ['R', 2]];
  bans.forEach(b => d.fill.push(b));
  picks.forEach(([s, k]) => { const [c, r] = g[s][k]; d.roles[d.fill.length] = r; d.fill.push(c); });
  const v = A.simValue(null).v;
  // score de la draft finale réelle, pour comparaison
  const B = {}, R = {}; g.B.forEach(([c, r]) => B[r] = A.BY[c]); g.R.forEach(([c, r]) => R[r] = A.BY[c]);
  out.push({ i: gi, y: g.w, tier: g.tier, sim6: +v.toFixed(3), fin: +(A.draftScore(B, R).total).toFixed(3) });
  if (out.length % 500 === 0) console.error(out.length, 'parties', ((Date.now() - t0) / 1000).toFixed(0), 's');
}
fs.writeFileSync(process.argv[4], JSON.stringify(out)); console.log(out.length, 'parties en', ((Date.now() - t0) / 1000).toFixed(0), 's');
