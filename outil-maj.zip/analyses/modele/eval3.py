import pickle, json, sys
import numpy as np, scipy.sparse as sp
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import log_loss, roc_auc_score
sys.argv = ['x', '30']
exec(open('fit2.py').read().split("sc = {'base'")[0])  # mêmes données et fonctions que l'entraînement
P = pickle.load(open('fit2.pkl', 'rb'))
sc = P['sc']
# modèle final appris sur entraînement + validation, noté une seule fois sur le test
Xtv = sp.vstack([Xtr, Xva]).tocsr(); ytv = np.concatenate([ytr, yva])
b, w = fit(sc, Xtv, ytv)
p = pred(b, w, Xte)
def metr(p, y=yte): return round(log_loss(y, p), 5), round(roc_auc_score(y, p), 4), round(float(((p > .5) == y).mean()), 4)
print('MODELE test', metr(p))
pb = ytv.mean(); print('côté seul', metr(np.full(len(yte), pb)))
print('base', {k: round(float(w[F.idx[k]]), 3) for k in ('base:flex', 'base:16.21')}, 'intercept (bleu)', round(float(b), 3))
print('poids des composantes de l\'outil', np.round(w[-5:] , 3))
inv = {v: k for k, v in F.idx.items() if isinstance(k, tuple)}
from feat import NAME
NM = lambda c: NAME.get(c, str(c))
for g in ['duel', 'ally', 'cross', 'comp', 'champ']:
    ix = np.where(F.group == g)[0]
    top = ix[np.argsort(-np.abs(w[ix]))][:12]
    print('==', g)
    for j in top:
        k = inv.get(j)
        lab = k[1] if g == 'comp' else ' '.join(NM(x) if isinstance(x, int) else x for x in k[1:])
        print(f'   {w[j] * 25:+.2f} pts', lab)
pickle.dump({'b': b, 'w': w, 'sc': sc}, open('final.pkl', 'wb'))
