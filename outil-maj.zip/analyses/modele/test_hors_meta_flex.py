# Les picks « hors méta pro » (champion presque jamais joué à ce rôle chez les pros, ex. Hwei ADC) perdent-ils
# davantage en flex (équipes de 5) qu'en solo/duo, à composantes solo queue égales ? Et la présence pro d'un pick
# (log du nombre de parties pros à ce rôle) prédit-elle le résultat en flex, là où le WR pro ne prédit rien ?
# Validation chronologique 80/20, IC95 par bootstrap. Mesures en points de WR.
# Usage : python3 test_hors_meta_flex.py parties.json meta.json composantes.json pro2026.json sortie.json
import json, sys, datetime as dt, numpy as np
from sklearn.linear_model import LogisticRegression
G = json.load(open(sys.argv[1])); M = json.load(open(sys.argv[2])); P = np.array(json.load(open(sys.argv[3])), float) / 100
PRO = json.load(open(sys.argv[4])); OUT = sys.argv[5]; F = PRO['freq']; N = PRO['n']
fr = lambda c, r: F[r].get(str(c), 0)
y = np.array([m['y'] for m in M], float); t = np.array([m['t'] for m in M]); q = np.array([m['q'] for m in M])
def team(g, s): return [(c, r) for r, c in g[s].items()]
OM = np.array([sum(fr(c, r) < 10 for c, r in team(g, 'B')) - sum(fr(c, r) < 10 for c, r in team(g, 'R')) for g in G], float)
LP = np.array([sum(np.log1p(fr(c, r)) for c, r in team(g, 'B')) - sum(np.log1p(fr(c, r)) for c, r in team(g, 'R')) for g in G])
keep = t >= dt.datetime(2026, 11, 8).timestamp(); idx = np.where(keep)[0]; idx = idx[np.argsort(t[idx], kind='stable')]
rng = np.random.default_rng(0); rep = {}
fit = lambda cols, rows: LogisticRegression(C=1e6, max_iter=500).fit(np.column_stack(cols)[rows], y[rows])
def ll(m, cols, rows):
    p = m.predict_proba(np.column_stack(cols)[rows])[:, 1]; return -(y[rows] * np.log(p) + (1 - y[rows]) * np.log(1 - p))
for lab, sel in (('solo/duo', q == 420), ('flex', q == 440)):
    rows = idx[sel[idx]]; cut = int(len(rows) * .8); tr, te = rows[:cut], rows[cut:]
    rep[lab] = {'n': int(len(rows)), 'hors_meta_moy_par_equipe': round(float(np.mean([sum(fr(c, r) < 10 for c, r in team(G[i], 'B')) for i in rows])), 3)}
    print(f'== {lab} ({len(rows)} parties, {rep[lab]["hors_meta_moy_par_equipe"]} pick hors méta par équipe en moyenne)')
    for nm, X in (('hors méta (nb de picks)', OM), ('présence pro (log parties)', LP)):
        base, full = [P], [P, X]
        m0, m1 = fit(base, tr), fit(full, tr); d = ll(m0, base, te) - ll(m1, full, te)
        bs = np.percentile([d[rng.integers(0, len(d), len(d))].mean() for _ in range(2000)], [2.5, 97.5])
        co = fit(full, rows).coef_[0][-1] * 25
        B = [fit(full, rows[rng.integers(0, len(rows), len(rows))]).coef_[0][-1] * 25 for _ in range(200)]
        lo, hi = np.percentile(B, [2.5, 97.5])
        rep[lab][nm] = {'coef_pts': [round(float(co), 3), round(float(lo), 3), round(float(hi), 3)], 'gain_ll': [round(float(d.mean()), 5)] + [round(float(x), 5) for x in bs]}
        print(f'   {nm:28s} {co:+.2f} pt par unité [{lo:+.2f} ; {hi:+.2f}]   gain log loss {d.mean():+.5f} [{bs[0]:+.5f} ; {bs[1]:+.5f}]')
json.dump(rep, open(OUT, 'w'), ensure_ascii=False, indent=1)
