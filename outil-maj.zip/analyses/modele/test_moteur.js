// Vérifie le moteur sans interface : cohérence fastScore / draftScore, temps de calcul, recommandations sur une draft type.
// Usage : node test_moteur.js <dossier outil> <parties.json (liste {B, R})>
const fs = require('fs'), vm = require('vm');
const D = process.argv[2].replace(/\/?$/, '/'); const rd = f => fs.readFileSync(D + f, 'utf8');
const src = rd('data.js') + '\n' + rd('app.js') + '\n' + rd('comp.js') + '\n' + rd('fit.js') + '\nconst CTX=' + rd('data/ctx.json') + ';\nconst PRODRAFT=' + rd('data/prodraft.json').trim() +
  ';\nconst PROSHAPE=' + rd('data/proshape.json').trim() + ';\nconst BIAS=' + rd('data/bias.json') + ';\nconst MODEL=' + rd('data/model.json') + ';\nconst PRO26=' + rd('data/pro2026.json') + ';\n' + rd('ctx.js') + '\n' + rd('sim.js') +
  '\n;globalThis.__api = { draftScore, fastScore, BY, CH, S, ROLES, D, newDraft, pickValue, dangerRecs, banSimRecs, simValue, simReset, bestComps, idealOrder, pickRecs, evalPick, simField, sideBlue };';
const ctx = { console, localStorage: { getItem: () => null, setItem: () => {} }, window: {}, document: { addEventListener() {}, querySelector() { return null; } }, setTimeout: f => { f(); return 0; }, Math, JSON, Date };
ctx.globalThis = ctx; vm.createContext(ctx); vm.runInContext(src, ctx);
const A = ctx.__api;
const games = JSON.parse(fs.readFileSync(process.argv[3], 'utf8')).slice(-3000);
for (const mode of ['flex', 'tourn']) {
  A.S.mode = mode; A.S.side = 'B'; let maxd = 0, n = 0, s = 0;
  for (const g of games) {
    const B = {}, R = {}; for (const r of A.ROLES) { B[r] = A.BY[g.B[r]]; R[r] = A.BY[g.R[r]]; }
    if (A.ROLES.some(r => !B[r] || !R[r])) continue;
    const d = A.draftScore(B, R), f = A.fastScore(B, R); maxd = Math.max(maxd, Math.abs((d.total) - f)); s += d.wr; n++;
  }
  console.log(`${mode} : écart max fastScore / draftScore ${maxd.toFixed(6)} pt ; côté bleu ${A.sideBlue().toFixed(2)} pts ; WR moyen bleu ${(s / n).toFixed(2)} % sur ${n} drafts`);
}
const id = n => { const c = A.CH.find(c => c.n === n); if (!c) throw new Error(n); return c.id; };
const T = A.S.team;
T[0].pool = ['Gwen', 'Camille', 'Sett'].map(id); T[1].pool = ['Lee Sin', 'Vi', 'Xin Zhao'].map(id);
T[2].pool = ['Syndra', 'Hwei', 'Viktor'].map(id); T[3].pool = ["Kai'Sa", 'Varus', 'Ezreal'].map(id); T[4].pool = ['Leona', 'Nautilus', 'Rakan'].map(id);
T[2].comf = { [id('Syndra')]: 9, [id('Hwei')]: 6 };
for (const mode of ['flex', 'tourn']) {
  A.S.mode = mode; A.S.side = 'B'; A.newDraft(); A.simReset();
  let t = Date.now();
  const vals = A.ROLES.map(r => [r, T.find(p => p.role === r).pool.map(cid => `${A.BY[cid].n} ${A.pickValue(A.BY[cid], r).toFixed(2)}`)]);
  console.log(`\n${mode}, début de draft (${Date.now() - t} ms) :`, JSON.stringify(vals));
  t = Date.now(); const bc = A.bestComps(3); console.log(`compos (${Date.now() - t} ms) :`, bc.map(c => c.cs.map(x => x.n).join(', ') + ` | modèle ${c.model.toFixed(2)} (champions ${(c.parts.force + c.parts.lane).toFixed(2)}, syn ${c.parts.syn.toFixed(2)}, contre ${c.parts.vs.toFixed(2)}, pro ${c.parts.pro.toFixed(2)}, aisance ${c.parts.comf.toFixed(2)})`).join(' || '));
  A.banSimRecs(6); t = Date.now(); const bans = A.banSimRecs(6); console.log(`bans (${Date.now() - t} ms) :`, (bans || []).map(x => `${x.c.n} +${x.gain.toFixed(2)}`).join(', '));
  // côté rouge : l'adversaire (bleu) ouvre avec Azir, le counter devient possible pour nous
  A.S.side = 'R'; A.newDraft();
  const d = A.D(); const seq = d.seq; let i = d.fill.length;
  while (seq[i].t === 'ban') { d.fill.push(null); i++; }
  d.fill.push(id('Azir')); d.roles[i] = undefined; // pick bleu ou rouge selon la séquence
  A.simReset(); t = Date.now();
  A.pickRecs(); const recs = A.pickRecs();
  console.log(`après un premier pick ${A.BY[id('Azir')].n} (${seq[i].s === A.S.side ? 'nous' : 'eux'}) (${Date.now() - t} ms) :`, recs.map(g => `${g.r}: ` + g.poolEv.slice(0, 3).map(e => `${e.c.n} ${(50 + (e.sim ?? e.inst)).toFixed(2)}`).join(' / ')).join(' | '));
}
const F = A.simField(); console.log('\nterrain adverse, mid :', F.mid.slice(0, 8).map(o => `${o.c.n} ${(o.p * 100).toFixed(1)}%`).join(', '));
