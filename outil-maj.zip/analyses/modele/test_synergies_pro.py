# Synergies et types de compo mesurés CHEZ LES PROS : prédisent-ils nos parties flex Master+, à force, matchups,
# synergies Master+ et présence pro égales ?
#  1) paires de champions d'une même équipe : résidu pro (résultat − prévision par l'Elo des équipes et le côté),
#     lissé vers 0 avec K parties fictives ; valeur d'une équipe = somme sur ses 10 paires
#  2) type de compo principal (engage, poke, protect, dive, pick, split ; coherence() de l'outil) : résidu pro moyen lissé
# Validation chronologique 80/20 sur la flex, IC95 par bootstrap. Usage :
# python3 test_synergies_pro.py travail/ types_compos.json pro2026.json sortie.json
import json, sys, itertools, numpy as np
from collections import defaultdict
from sklearn.linear_model import LogisticRegression
W = sys.argv[1]; T = json.load(open(sys.argv[2])); PRO = json.load(open(sys.argv[3])); OUT = sys.argv[4]
PG = json.load(open(W + 'pro_games.json')); G = json.load(open(W + 'parties.json')); M = json.load(open(W + 'meta.json'))
P = np.array(json.load(open(W + 'composantes.json')), float) / 100
# --- Elo des équipes pros, en ligne (cote avant la partie), puis prévision par Elo + côté
PG = sorted(enumerate(PG), key=lambda x: x[1]['dt']); el = defaultdict(lambda: 1500.0); d = []; yp = []
for i, g in PG:
    a, b = el[g['tb']], el[g['tr']]; d.append(a - b); yp.append(g['w'])
    e = 1 / (1 + 10 ** ((b - a) / 400)); el[g['tb']] += 24 * (g['w'] - e); el[g['tr']] -= 24 * (g['w'] - e)
d = np.array(d); yp = np.array(yp, float)
me = LogisticRegression().fit(d[:, None] / 100, yp); pe = me.predict_proba(d[:, None] / 100)[:, 1]; res = yp - pe
print(f'pros : {len(yp)} parties, Elo : {me.coef_[0][0]:.3f} par 100 points, bleu {100 * yp.mean():.1f} %')
# --- résidus par paire et par type (signés du point de vue de l'équipe)
pr = defaultdict(lambda: [0.0, 0]); ty = defaultdict(lambda: [0.0, 0])
for k, (i, g) in enumerate(PG):
    for side, s in (('B', 1), ('R', -1)):
        ids = sorted(c for c, _ in g[side])
        for a, b in itertools.combinations(ids, 2): x = pr[(a, b)]; x[0] += s * res[k]; x[1] += 1
        t = T['pro'][i][0 if side == 'B' else 1]
        if t: ty[t][0] += s * res[k]; ty[t][1] += 1
npair = np.array([v[1] for v in pr.values()])
print(f'paires vues chez les pros : {len(pr)} ; parties par paire : médiane {np.median(npair):.0f}, ≥ 50 : {(npair >= 50).sum()}')
print('types (résidu moyen brut, points) :', {t: [round(100 * v[0] / v[1], 2), v[1]] for t, v in ty.items()})
# --- parties flex
idx = np.array(T['flexIdx']); y = np.array([M[i]['y'] for i in idx], float); tt = np.array([M[i]['t'] for i in idx])
o = np.argsort(tt, kind='stable'); idx, y = idx[o], y[o]; TF = [T['flex'][k] for k in o]
F = PRO['freq']; lp = lambda c, r: np.log1p(F[r].get(str(c), 0))
LP = np.array([sum(lp(c, r) for r, c in G[i]['B'].items()) - sum(lp(c, r) for r, c in G[i]['R'].items()) for i in idx])
base = [P[idx], LP[:, None]]
cut = int(len(y) * .8); tr, te = np.arange(cut), np.arange(cut, len(y)); rng = np.random.default_rng(0)
def run(nm, X):
    cols = base + [X[:, None]]; Xa = np.column_stack(cols); X0 = np.column_stack(base)
    m0 = LogisticRegression(C=1e6, max_iter=500).fit(X0[tr], y[tr]); m1 = LogisticRegression(C=1e6, max_iter=500).fit(Xa[tr], y[tr])
    l = lambda m, Z: -(y[te] * np.log(m.predict_proba(Z[te])[:, 1]) + (1 - y[te]) * np.log(1 - m.predict_proba(Z[te])[:, 1]))
    dl = l(m0, X0) - l(m1, Xa); bs = np.percentile([dl[rng.integers(0, len(dl), len(dl))].mean() for _ in range(2000)], [2.5, 97.5])
    sd = X.std(); co = LogisticRegression(C=1e6, max_iter=500).fit(Xa, y).coef_[0][-1] * 25 * sd
    B = [LogisticRegression(C=1e6, max_iter=500).fit(Xa[j], y[j]).coef_[0][-1] * 25 * sd for j in (rng.integers(0, len(y), len(y)) for _ in range(200))]
    lo, hi = np.percentile(B, [2.5, 97.5])
    print(f'  {nm:34s} {co:+.2f} pt par écart-type [{lo:+.2f} ; {hi:+.2f}] ; gain log loss {dl.mean():+.5f} [{bs[0]:+.5f} ; {bs[1]:+.5f}]')
    return {'coef_pts_par_sd': [round(float(co), 3), round(float(lo), 3), round(float(hi), 3)], 'gain_ll': [round(float(dl.mean()), 5)] + [round(float(x), 5) for x in bs]}
rep = {'n_flex': int(len(y)), 'n_pro': int(len(yp))}
print(f'flex : {len(y)} parties (test {len(te)})')
for K in (10, 30, 100, 300):
    sv = {k: v[0] / (v[1] + K) for k, v in pr.items()}
    def team(t): ids = sorted(t.values()); return sum(sv.get((a, b), 0) for a, b in itertools.combinations(ids, 2))
    X = np.array([team(G[i]['B']) - team(G[i]['R']) for i in idx]) * 100
    rep[f'paires_K{K}'] = run(f'synergies de paires pros (K = {K})', X)
for K in (30, 300):
    tv = {t: v[0] / (v[1] + K) for t, v in ty.items()}
    X = np.array([tv.get(a, 0) - tv.get(b, 0) if a and b else 0 for a, b in TF]) * 100
    rep[f'types_K{K}'] = run(f'type de compo pro (K = {K})', X)
json.dump(rep, open(OUT, 'w'), ensure_ascii=False, indent=1)
