const fs = require('fs'), vm = require('vm'); const D = '/home/claude/draft/';
const rd = f => fs.readFileSync(D + f, 'utf8');
const src = rd('data.js') + '\n' + rd('app.js') + '\n' + rd('comp.js') + '\n' + rd('fit.js') + '\nconst CTX=' + rd('data/ctx.json') + ';\nconst PRODRAFT=' + rd('data/prodraft.json').trim() + ';\nconst PROSHAPE=' + rd('data/proshape.json').trim() + ';\nconst BIAS=' + rd('data/bias.json') + ';\nconst MODEL=' + rd('data/model.json') + ';\nconst PRO26=' + rd('data/pro2026.json') + ';\n' + rd('ctx.js') + '\n' + rd('sim.js') +
  '\n;globalThis.__api = { dangerRecs: (...a) => dangerRecs(...a), setSeed: s => { SIM_SEED = s; simReset(); }, draftScore, fastScore, BY, CH, S, ROLES, D, newDraft, pickValue, dangerRecs, simValue, simReset };';
const ctx = { console, localStorage: { getItem: () => null, setItem: () => {} }, window: {}, document: { addEventListener() {}, querySelector() { return null; } }, setTimeout, Math, JSON, Date };
ctx.globalThis = ctx; vm.createContext(ctx); vm.runInContext(src, ctx);
module.exports = ctx.__api;
if (require.main === module) {
  const A = ctx.__api; A.S.ref = 'solo'; A.S.side = 'B';
  const games = JSON.parse(fs.readFileSync('/tmp/te2.json', 'utf8')).slice(0, 3000);
  let maxd = 0;
  for (const g of games) {
    const B = {}, R = {}; for (const r of A.ROLES) { B[r] = A.BY[g.B[r]]; R[r] = A.BY[g.R[r]]; }
    const d = A.draftScore(B, R), f = A.fastScore(B, R);
    maxd = Math.max(maxd, Math.abs((d.wr - 50) - f));
  }
  console.log('écart max fastScore / draftScore (points)', maxd.toFixed(6));
  // timing d'une draft vide puis partielle
  const id = n => A.CH.find(c => c.n === n);
  A.S.team[0].pool = ['Gwen', 'Camille', 'Sett'].map(n => id(n).id); A.S.team[1].pool = ['Lee Sin', 'Vi', 'Xin Zhao'].map(n => id(n).id);
  A.S.team[2].pool = ['Syndra', 'Hwei', 'Viktor'].map(n => id(n).id); A.S.team[3].pool = ["Kai'Sa", 'Varus', 'Ezreal'].map(n => id(n).id);
  A.S.team[4].pool = ['Leona', 'Nautilus', 'Rakan'].map(n => id(n).id);
  A.S.mode = 'flex'; A.newDraft();
  let t = Date.now();
  const vals = A.ROLES.map(r => [r, A.S.team.find(p => p.role === r).pool.map(cid => [A.BY[cid].n, A.pickValue(A.BY[cid], r).toFixed(2)])]);
  console.log('début de draft', Date.now() - t, 'ms', JSON.stringify(vals));
  t = Date.now(); const dg = A.dangerRecs(8);
  console.log('dangers', Date.now() - t, 'ms', dg.map(x => `${x.c.n} ${x.r} −${x.drop.toFixed(2)} p=${(x.p * 100).toFixed(1)}%`).join(' | '));
}
