# Table « joueur × partie » pour l'analyse des objets : champion, rôle, objets finis, bottes, victoire, durée, file,
# date, nombre d'objets finis, profil de la compo adverse (étiquettes du collecteur : ap3, ad4, cc3, heal2, shield2, tank2, burst2, auto3).
# Usage : python3 table_items.py catalogue.json champtraits.json sortie.npz
import gzip, glob, json, os, sys, numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
ROWS = os.environ.get('ROWS_DIR', os.path.join(HERE, '..', '..', 'donnees', 'rows'))
CAT = {int(k): v for k, v in json.load(open(sys.argv[1]))['items'].items()}
# objets transformés (absents de la boutique) ramenés à leur objet d'origine ; bottes « légèrement magiques » comptées comme bottes
ALIAS = {3042: 3004, 3040: 3003, 3121: 3119, 2422: 1001}
GOLD = {k: v['g'] for k, v in CAT.items()}
_TK = ('cc', 'tank', 'burst', 'heal', 'shield', 'auto')
TR = {int(k): dict(d=v[:-6], **{n: int(v[-6 + i]) for i, n in enumerate(_TK)}) for k, v in json.load(open(sys.argv[2])).items()}
TAGS = ['ap3', 'ad4', 'cc3', 'heal2', 'shield2', 'tank2', 'burst2', 'auto3']
def counts_of(en):
    # profil fin de la compo adverse : nombre de champions AP, AD, tanks, puis sommes des drapeaux cc, tank, burst, heal, shield, auto
    tr = [TR.get(c) for c in en]; tr = [t for t in tr if t]
    return [sum(t['d'] == 'AP' for t in tr), sum(t['d'] == 'AD' for t in tr), sum(t['d'] == 'T' for t in tr)] + [sum(t[k] for t in tr) for k in _TK]
def tags_of(en):
    tr = [TR.get(c) for c in en]; tr = [t for t in tr if t]; s = lambda k: sum(t[k] for t in tr)
    return [sum(t['d'] == 'AP' for t in tr) >= 3, sum(t['d'] == 'AD' for t in tr) >= 4, s('cc') >= 3, s('heal') >= 2, s('shield') >= 2, s('tank') >= 2, s('burst') >= 2, s('auto') >= 3]
ROLES = {'top': 0, 'jgl': 1, 'mid': 2, 'adc': 3, 'sup': 4}
champ, role, win, dur, q, t, gid, nleg, tag, ecnt, gold = [], [], [], [], [], [], [], [], [], [], []
leg_r, leg_c, boot = [], [], []  # objets finis en format creux (ligne, objet), bottes (une par joueur, 0 sinon)
row = 0; g = 0
# fenêtre de parties (mise à jour automatique) : les ITEMS_FENETRE_JOURS derniers jours, au plus ITEMS_MAX_PARTIES parties
FEN = int(os.environ.get('ITEMS_FENETRE_JOURS', '0')); MAXP = int(os.environ.get('ITEMS_MAX_PARTIES', '0'))
LIGNES = [l for f in sorted(glob.glob(os.path.join(ROWS, '*.jsonl.gz'))) for l in gzip.open(f, 'rt')]
if FEN or MAXP:
    TS = [json.loads(l)['t'] for l in LIGNES]; o = sorted(range(len(LIGNES)), key=lambda i: TS[i])
    if FEN: o = [i for i in o if TS[i] >= max(TS) - FEN * 86400]
    if MAXP: o = o[-MAXP:]
    LIGNES = [LIGNES[i] for i in o]
for _ in [0]:
    for l in LIGNES:
        r = json.loads(l)
        if r['w'] not in ('B', 'R') or len(r['B']) != 5 or len(r['R']) != 5: continue
        if any(x[1] not in ROLES for x in r['B'] + r['R']): continue
        g += 1
        for s, o in (('B', 'R'), ('R', 'B')):
            tg = tags_of([x[0] for x in r[o]]); ec = counts_of([x[0] for x in r[o]])
            for c, ro, items, sp in r[s]:
                items = [ALIAS.get(i, i) for i in items]
                legs = sorted({i for i in items if CAT.get(i, {}).get('c') == 'L'})
                bt = [i for i in items if CAT.get(i, {}).get('c') == 'B']
                champ.append(c); role.append(ROLES[ro]); win.append(r['w'] == s); dur.append(r['d']); q.append(r['q']); t.append(r['t']); gid.append(g)
                nleg.append(len(legs)); tag.append(tg); ecnt.append(ec); gold.append(sum(GOLD[i] for i in legs) + (GOLD[bt[0]] if bt else 0)); boot.append(bt[0] if bt else 0)
                for i in legs: leg_r.append(row); leg_c.append(i)
                row += 1
np.savez_compressed(sys.argv[3], champ=np.array(champ, np.int32), role=np.array(role, np.int8), win=np.array(win, np.int8), dur=np.array(dur, np.int32),
                    q=np.array(q, np.int16), t=np.array(t, np.int64), gid=np.array(gid, np.int32), nleg=np.array(nleg, np.int8), tag=np.array(tag, np.int8), ecnt=np.array(ecnt, np.int8), gold=np.array(gold, np.int32),
                    boot=np.array(boot, np.int32), leg_r=np.array(leg_r, np.int32), leg_c=np.array(leg_c, np.int32))
print(g, 'parties,', row, 'joueurs ;', len(leg_r), 'objets finis')
