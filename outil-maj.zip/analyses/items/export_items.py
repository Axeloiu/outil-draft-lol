# Écrit outil/data/items.json pour l'outil : objets (noms, prix), effet de base par classe, écart par champion|rôle,
# effet selon le profil adverse (si retenu), et part des joueurs de chaque champion|rôle qui finissent chaque objet.
# Usage : python3 export_items.py fit_items.pkl table.npz catalogue.json champtraits.json sortie.json [avec_compo]
import sys, json, pickle, collections, numpy as np
P = pickle.load(open(sys.argv[1], 'rb')); d = dict(np.load(sys.argv[2])); CAT = json.load(open(sys.argv[3]))['items']
TRT = json.load(open(sys.argv[4])); with_compo = len(sys.argv) > 6 and sys.argv[6] == 'avec_compo'
w = P['w'] * 25; dec = P['decode']; items_u = P['items_u']; cr_u = P['cr_u']; NC = len(cr_u)
RL = ['top', 'jgl', 'mid', 'adc', 'sup']
# jamais conseillé : le Voleur d'âmes de Mejai s'achète quand on est déjà en avance (effet mesuré à l'envers)
EXCLU = {3041}
def cols(name):
    off, u = dec[name]; return u, w[off:off + len(u)]
out = {'v': json.load(open(sys.argv[3]))['v'], 'cat': {}, 'base': {0: {}, 1: {}, 2: {}}, 'ch': {}, 'use': {}, 'n': {}}
u, v = cols('objet')
out['base'] = {}
for code, x in zip(u, v):
    ro = int(code % 5); rest = code // 5; cl = int(rest % 3); it = int(items_u[rest // 3])
    out['base'].setdefault(f'{cl}|{RL[ro]}', {})[it] = round(float(x), 3)
u, v = cols('objet_champ')
for code, x in zip(u, v):
    if abs(x) < 0.05: continue
    it, crc = int(items_u[code // NC]), int(cr_u[code % NC]); k = f'{crc // 8}|{RL[crc % 8]}'
    out['ch'].setdefault(k, {})[it] = round(float(x), 3)
if with_compo:
    u, v = cols('objet_compo'); NK = len(P['mu']); out['mu'] = [round(float(m), 3) for m in P['mu']]; out['inter'] = {0: {}, 1: {}, 2: {}}
    for code, x in zip(u, v):
        cl = int(code % 3); rest = code // 3; k = int(rest % NK); it = int(items_u[rest // NK])
        out['inter'][cl].setdefault(it, [0] * NK)[k] = round(float(x), 3)
# part des joueurs de chaque champion|rôle qui finissent l'objet (objets finis et bottes)
cr = d['champ'].astype(np.int64) * 8 + d['role']
n_cr = collections.Counter(cr.tolist())
used = collections.Counter(zip(cr[d['leg_r']].tolist(), d['leg_c'].tolist()))
bt = d['boot'] > 0; used.update(zip(cr[bt].tolist(), d['boot'][bt].tolist()))
for (c, it), n in used.items():
    k = f'{c // 8}|{RL[c % 8]}'; sh = n / n_cr[c]
    if sh >= 0.02 and it not in EXCLU: out['use'].setdefault(k, {})[it] = round(sh, 3)
for c, n in n_cr.items(): out['n'][f'{c // 8}|{RL[c % 8]}'] = n
keep = {int(i) for m in out['use'].values() for i in m} | {int(k) for k, v in CAT.items() if v['c'] in ('L', 'B') and int(k) < 10000}
out['cat'] = {i: [CAT[str(i)]['n'], CAT[str(i)]['g'], CAT[str(i)]['c']] for i in sorted(keep)}
out['traits'] = TRT  # profil des champions (collecteur) pour les objets situationnels
json.dump(out, open(sys.argv[5], 'w'), ensure_ascii=False, separators=(',', ':'))
print(len(out['cat']), 'objets,', len(out['use']), 'champions|rôles,', round(len(json.dumps(out, ensure_ascii=False)) / 1024), 'Ko')
