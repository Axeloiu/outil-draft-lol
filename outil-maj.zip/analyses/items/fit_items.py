# Effet des objets sur la victoire, à nombre d'objets finis et durée égaux, face au profil de la compo adverse.
# Régression logistique sur les joueurs (une ligne par joueur et par partie) :
#   strate (nombre d'objets finis × tranche de durée) + champion|rôle
#   + objet × classe du champion (AD / AP / tank)          [effet de base de l'objet]
#   + objet × champion|rôle (si ≥ 300 joueurs)             [écart propre au champion]
#   + objet × étiquette adverse × classe (ap3, ad4, cc3…)  [ce qui change face à la compo]
# Les bottes sont traitées comme des objets. Forces de pénalité par groupe réglées sur une validation chronologique.
# Usage : python3 fit_items.py table.npz data.js sortie.pkl
import sys, json, time, pickle, collections, numpy as np, scipy.sparse as sp
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import log_loss
t0 = time.time()
d = dict(np.load(sys.argv[1])); DATA = json.loads(open(sys.argv[2]).read()[len('const DATA='):-2])
CLS = {c['id']: {'AD': 0, 'AP': 1, 'T': 2}.get(c['d'], 0) for c in DATA['champs']}
N = len(d['win']); y = d['win'].astype(float)
cls = np.array([CLS.get(int(c), 0) for c in d['champ']], np.int32)
cr = d['champ'].astype(np.int64) * 8 + d['role']
db = np.digitize(d['dur'], [1200, 1500, 1800, 2100])
# strate : valeur en or des objets finis (tranches de 1 000 po) × tranche de durée
strata = np.minimum(d['gold'] // 1000, 20).astype(np.int64) * 5 + db
# objets par joueur (finis + bottes)
it_r = np.concatenate([d['leg_r'], np.where(d['boot'] > 0)[0]]); it_c = np.concatenate([d['leg_c'], d['boot'][d['boot'] > 0]])
# découpage chronologique par partie
gt = collections.OrderedDict(); order = np.argsort(d['t'], kind='stable')
games = d['gid'][order]; _, first = np.unique(games, return_index=True); gorder = games[np.sort(first)]
rank = np.empty(d['gid'].max() + 1, np.int64); rank[gorder] = np.arange(len(gorder))
gr = rank[d['gid']]; G = len(gorder)
tr = gr < .7 * G; va = (gr >= .7 * G) & (gr < .8 * G); te = gr >= .8 * G
# --- variables (construction vectorisée) ; chaque groupe garde la table de décodage de ses colonnes
items_u, it_i = np.unique(it_c, return_inverse=True); NI = len(items_u)
cr_u, cr_i = np.unique(cr, return_inverse=True); NC = len(cr_u)
EC = d['ecnt'].astype(np.float32); mu = EC[tr].mean(0); NK = EC.shape[1]
blocks, group, decode = [], [], {}
off = 0
def block(name, r, code, val=None):
    global off
    u, j = np.unique(code, return_inverse=True)
    blocks.append((np.asarray(r, np.int64), off + j, np.ones(len(r), np.float32) if val is None else val.astype(np.float32)))
    decode[name] = (off, u); group.extend([name] * len(u)); off += len(u)
block('strate', np.arange(N), strata)
block('champ', np.arange(N), cr_i)
block('objet', it_r, (it_i.astype(np.int64) * 3 + cls[it_r]) * 5 + d['role'][it_r])  # objet × classe × rôle
pair = it_i.astype(np.int64) * NC + cr_i[it_r]
pu, pc = np.unique(pair[tr[it_r]], return_counts=True); ok = np.isin(pair, pu[pc >= 300])
block('objet_champ', it_r[ok], pair[ok])
rr, cc, vv = [], [], []
for k in range(NK):
    v = EC[it_r, k] - mu[k]; m = v != 0
    rr.append(it_r[m]); cc.append((it_i[m].astype(np.int64) * NK + k) * 3 + cls[it_r[m]]); vv.append(v[m])
block('objet_compo', np.concatenate(rr), np.concatenate(cc), np.concatenate(vv)); del rr, cc, vv
R = np.concatenate([x[0] for x in blocks]); C = np.concatenate([x[1] for x in blocks]); V = np.concatenate([x[2] for x in blocks]); del blocks
X = sp.csr_matrix((V, (R, C)), shape=(N, off), dtype=np.float32); del R, C, V
group = np.array(group)
print(f'{N} joueurs, {X.shape[1]} variables', dict(collections.Counter(group)), f'{time.time()-t0:.0f}s', flush=True)
Xtr, Xva, Xte = X[tr], X[va], X[te]
def fit(sc, Xa=Xtr, ya=y[tr]):
    s = np.array([sc[g] for g in group]); m = LogisticRegression(C=1.0, max_iter=600, tol=1e-5).fit(Xa @ sp.diags(s), ya)
    return m.intercept_[0], m.coef_.ravel() * s
pred = lambda b, w, Xa: 1 / (1 + np.exp(-(Xa @ w + b)))
sc = {'strate': 10.0, 'champ': 1.0, 'objet': 0.3, 'objet_champ': 0.1, 'objet_compo': 0.1}
ll = lambda sc: log_loss(y[va], pred(*fit(sc), Xva))
sc = {'strate': 10.0, 'champ': 1.0, 'objet': 1.2, 'objet_champ': 0.4, 'objet_compo': 1e-6}  # réglage retenu le 18/11 (objet_compo retiré)
best = ll(sc); print('validation', round(best, 5), f'{time.time()-t0:.0f}s', flush=True)
for it in range(int(sys.argv[4]) if len(sys.argv) > 4 else 0):  # une passe : la seconde ne changeait rien au premier essai
    for g in ['objet', 'objet_champ', 'objet_compo']:
        for f in ((0.0, 0.25, 4) if it == 0 else (0.5, 2)):
            s2 = dict(sc); s2[g] = sc[g] * f if f else 1e-6; v = ll(s2)
            if v < best - 1e-6: best, sc = v, s2
        print(it, g, {k: round(v, 4) for k, v in sc.items()}, round(best, 5), f'{time.time()-t0:.0f}s', flush=True)
# test : modèle final (entraînement + validation) contre la base sans objets
tv = tr | va
b, w = fit(sc, X[tv], y[tv]); p = pred(b, w, Xte)
s0 = dict(sc); s0.update({'objet': 1e-6, 'objet_champ': 1e-6, 'objet_compo': 1e-6}); b0, w0 = fit(s0, X[tv], y[tv]); p0 = pred(b0, w0, Xte)
s1 = dict(sc); s1['objet_compo'] = 1e-6; b1, w1 = fit(s1, X[tv], y[tv]); p1 = pred(b1, w1, Xte)
yt = y[te]; li = lambda q: -(yt * np.log(q) + (1 - yt) * np.log(1 - q))
gte = d['gid'][te]; ug, inv = np.unique(gte, return_inverse=True); rng = np.random.default_rng(0)
def boot(a, b_):  # bootstrap par partie (les 10 joueurs d'une partie ensemble)
    dd = li(a) - li(b_); sg = np.bincount(inv, dd); ng = np.bincount(inv); out = []
    for _ in range(500):
        k = rng.integers(0, len(ug), len(ug)); out.append(sg[k].sum() / ng[k].sum())
    return round(dd.mean(), 5), np.percentile(out, [2.5, 97.5]).round(5).tolist()
print('TEST base (strate + champion)', round(log_loss(yt, p0), 5))
g1 = boot(p0, p1); print('TEST + objets (sans compo)', round(log_loss(yt, p1), 5), 'gain', g1)
json.dump({'gain_objets': [float(g1[0]), g1[1]], 'n_test': int(te.sum())}, open(sys.argv[3] + '.json', 'w'))
print('TEST + objets × compo adverse', round(log_loss(yt, p), 5), 'gain sur objets seuls', boot(p1, p))
pickle.dump({'decode': decode, 'items_u': items_u, 'cr_u': cr_u, 'mu': mu, 'group': group, 'sc': sc, 'b': b, 'w': w}, open(sys.argv[3], 'wb'))
print('fin', f'{time.time()-t0:.0f}s')
