// ===== Interface =====
const $ = s => document.querySelector(s);
const esc = s => String(s).replace(/[&<>"']/g, m => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m]));
let TAB = 'draft', GRID_ROLE = 'all', GRID_Q = '';

function img(c, cls = '') { return c ? `<img class="ic ${cls}" src="${icon(c)}" alt="${esc(c.n)}" title="${esc(c.n)}">` : ''; }

function render() {
  document.querySelectorAll('.tabs button').forEach(b => b.classList.toggle('on', b.dataset.tab === TAB));
  $('#team').hidden = TAB !== 'team';
  $('#comps').hidden = TAB !== 'comps';
  $('#draft').hidden = TAB !== 'draft';
  $('#prof').hidden = TAB !== 'prof';
  $('#ingame').hidden = TAB !== 'ingame';
  if (TAB === 'team') renderTeam(); else if (TAB === 'comps') renderComps(); else if (TAB === 'prof') renderProf(); else if (TAB === 'ingame') renderIngame(); else renderDraft();
  const lb = document.getElementById('live'); if (lb) { lb.innerHTML = liveBar(); bindLive(); }
}

// ----- Équipe -----
function poolText() {
  return S.team.map(p => `${RL[p.role]}${p.name ? ' (' + p.name + ')' : ''} : ${p.pool.map(id => BY[id] ? BY[id].n : '').filter(Boolean).join(', ')}`).join('\n');
}
const ROLE_WORDS = { top: 'top', jungle: 'jgl', jungler: 'jgl', jgl: 'jgl', jng: 'jgl', jgle: 'jgl', mid: 'mid', middle: 'mid', adc: 'adc', bot: 'adc', ad: 'adc', support: 'sup', supp: 'sup', sup: 'sup' };
const normName = x => x.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z]/g, '');
function parsePools(txt) {
  const unknown = [];
  txt.split(/\n/).forEach(line => {
    const m = line.match(/^\s*([A-Za-zé]+)\s*(?:\(([^)]*)\))?\s*[:\-]\s*(.*)$/);
    if (!m) return;
    const r = ROLE_WORDS[normName(m[1])]; if (!r) return;
    const p = playerOf(r);
    if (m[2] != null) p.name = m[2].trim();
    const ids = [];
    m[3].split(/[,;\/]+/).map(x => x.trim()).filter(Boolean).forEach(n => {
      const k = normName(n);
      const c = CH.find(c => normName(c.n) === k || normName(c.k) === k) || CH.find(c => normName(c.n).startsWith(k) && k.length >= 3);
      if (c) { if (!ids.includes(c.id)) ids.push(c.id); } else unknown.push(n);
    });
    p.pool = ids;
  });
  return unknown;
}
let SAVE_MSG = '';
// guides de rôle (docs Claude d'Axel) ; chaque joueur peut mettre un autre lien
const GUIDES = { top: 'https://claude.ai/artifact/7kPUYR83bYX7mLe2v63BRJ', jgl: 'https://claude.ai/artifact/F9vCXinYNLhh1y6KGMzznC', mid: 'https://claude.ai/artifact/1XWvo8Jd1PFbCZX44XEKgd', adc: 'https://claude.ai/artifact/BKE93KxkQfJqugwbzCDLy5', sup: 'https://claude.ai/artifact/RTApha6xe2NyLjGqsGK3ht' };
const REGIONS = ['euw', 'eune', 'na', 'kr', 'br', 'tr', 'jp', 'oce', 'lan', 'las', 'me', 'ru', 'sg', 'tw', 'vn'];
const opggUrl = p => { const id = (p.riot || '').trim(); if (!id) return ''; const [n, t] = id.split('#'); return `https://op.gg/lol/summoners/${p.region || 'euw'}/${encodeURIComponent((n || '').trim())}${t ? '-' + encodeURIComponent(t.trim()) : ''}`; };
const guideOf = p => (p.guide || '').trim() || GUIDES[p.role] || '';
// PDF intégré : celui du rôle (copie des guides d'Axel, dossier guides/) ou un lien .pdf collé dans le profil
const GPAGES = {top: 7, jgl: 10, mid: 22, adc: 6, sup: 20};
const GUIDE_PDF = { top: 'guide-top.pdf', jgl: 'guide-jungle.pdf', mid: 'guide-mid.pdf', adc: 'guide-adc.pdf', sup: 'guide-support.pdf' };
const guidePdf = p => { const g = (p.guide || '').trim(); if (g) return /\.pdf($|[?#])/i.test(g) ? g : ''; return GUIDE_PDF[p.role] || ''; };
function openGuide(i) {
  const p = S.team[i], pdf = guidePdf(p), src = guideOf(p); if (!pdf && !src) return;
  if (!pdf) { window.open(src, '_blank', 'noopener'); return; }
  // dans la version Claude (page isolée), le lecteur PDF du navigateur est bloqué : on affiche les pages en images
  const useImg = !window.FBSTORE_PROMISE && !(p.guide || '').trim() && GPAGES[p.role];
  let v = document.getElementById('gview'); if (v) v.remove();
  v = document.createElement('div'); v.id = 'gview';
  v.innerHTML = `<div class="gbar"><b>Guide ${p.role === 'adc' ? 'ADC' : RL[p.role].toLowerCase()}</b>${p.name ? `<span class="note">${esc(p.name)}</span>` : ''}<span class="grow"></span>
    <button id="gfull" class="on">Plein écran</button><a class="lnk" href="${esc(pdf)}" target="_blank" rel="noopener">Nouvel onglet</a>${src && src !== pdf ? `<a class="lnk" href="${esc(src)}" target="_blank" rel="noopener">Version modifiable</a>` : ''}<button id="gclose" class="ghost">Fermer</button></div>
    ${useImg ? `<div class="gpages">${Array.from({ length: GPAGES[p.role] }, (_, k) => `<img loading="lazy" src="gpages/${p.role}-${k + 1}.webp" alt="Page ${k + 1}">`).join('')}</div>` : `<iframe src="${esc(pdf)}#view=FitH&toolbar=1" title="Guide"></iframe>`}`;
  document.body.appendChild(v);
  // plein écran du navigateur ; si la page n'y a pas droit (version Claude), la fenêtre du guide prend toute la page
  v.querySelector('#gfull').onclick = () => {
    if (document.fullscreenElement) { document.exitFullscreen().catch(() => { }); return; }
    if (v.classList.contains('max')) { v.classList.remove('max'); return; }
    const fb = () => v.classList.add('max');
    try { const pr = v.requestFullscreen && v.requestFullscreen(); if (pr && pr.catch) pr.catch(fb); else if (!pr) fb(); setTimeout(() => { if (!document.fullscreenElement) fb(); }, 400); } catch (e) { fb(); }
  };
  v.querySelector('#gclose').onclick = () => { if (document.fullscreenElement) document.exitFullscreen().catch(() => { }); v.remove(); };
  const k = e => { if (e.key === 'Escape' && !document.fullscreenElement) { v.remove(); document.removeEventListener('keydown', k); } }; document.addEventListener('keydown', k);
}
let TEAM_OPEN = -1;
function renderTeam() {
  let h = `<p class="lead">Le pool de chaque joueur, du main au moins joué. Ouvre un profil pour l’op.gg, le guide du rôle et l’aisance sur chaque champion (sur 10), qui compte dans les compos et la draft. <span class="note" id="savemsg">${esc(SAVE_MSG)}</span></p>`;
  h += S.team.map((p, i) => {
    const open = TEAM_OPEN === i, cf = p.comf || {}, og = opggUrl(p), gd = guideOf(p);
    return `<div class="pcard2 ${open ? 'open' : ''}">
      <div class="phead"><span class="prole">${RL[p.role]}</span><input class="pname" data-i="${i}" placeholder="Pseudo" value="${esc(p.name)}">
        <span class="grow"></span>${og ? `<a class="lnk" href="${esc(og)}" target="_blank" rel="noopener">op.gg</a>` : ''}${gd ? `<button class="lnk" data-guide="${i}">Guide ${p.role === 'adc' ? 'ADC' : RL[p.role].toLowerCase()}</button>` : ''}
        <button class="ghost small" data-open="${i}">${open ? 'Fermer le profil' : 'Profil'}</button></div>
      <div class="chips">${p.pool.map((id, k) => { const c = BY[id]; if (!c) return ''; const v = cf[id];
        return `<span class="chip">${img(c)}<span>${esc(c.n)}</span>${v != null && v !== '' ? `<b class="cf cf${v >= 8 ? 'h' : v <= 4 ? 'l' : 'm'}" title="Aisance">${v}</b>` : ''}
        <button data-mv="${i},${k},-1" title="Monter">←</button><button data-mv="${i},${k},1" title="Descendre">→</button><button data-rm="${i},${k}" title="Retirer">×</button></span>`; }).join('')}
        <span class="addwrap"><input class="addc" data-i="${i}" placeholder="+ champion" autocomplete="off"><div class="sugg" id="sugg${i}"></div></span></div>
      ${open ? `<div class="pdet">
        <div class="pdrow"><label>Riot ID <input class="pf" data-i="${i}" data-f="riot" placeholder="Pseudo#TAG" value="${esc(p.riot || '')}"></label>
          <label>Serveur <select class="pf" data-i="${i}" data-f="region">${REGIONS.map(r => `<option ${r === (p.region || 'euw') ? 'selected' : ''}>${r}</option>`).join('')}</select></label>
          ${og ? `<a class="lnk" href="${esc(og)}" target="_blank" rel="noopener">Ouvrir son op.gg</a>` : ''}</div>
        <div class="pdrow"><label class="wide">Guide du rôle <input class="pf" data-i="${i}" data-f="guide" placeholder="${GUIDES[p.role] ? 'Guide par défaut : celui d’Axel (PDF intégré)' : 'Pas encore de guide pour ce rôle : colle un lien (un .pdf s’affiche dans l’outil)'}" value="${esc(p.guide || '')}"></label>
          ${gd ? `<button class="lnk" data-guide="${i}">Lire le guide</button>` : ''}</div>
        <h4>Aisance sur 10 <span class="note">vide = l’ordre du pool décide ; 8 et plus = champion de confiance, 4 et moins = à éviter en match important</span></h4>
        <div class="cfgrid">${p.pool.map(id => { const c = BY[id]; if (!c) return ''; const v = cf[id]; return `<label class="cfit">${img(c)}<span>${esc(c.n)}</span><select data-cf="${i},${id}"><option value="">–</option>${[10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0].map(n => `<option ${String(v) === String(n) ? 'selected' : ''}>${n}</option>`).join('')}</select></label>`; }).join('') || '<span class="note">Ajoute d’abord des champions.</span>'}</div>
      </div>` : ''}
    </div>`;
  }).join('');
  h += `<details class="notepad"><summary><b>Coller les pools en texte</b> <span class="note">une ligne par joueur : Top (Pseudo) : Jax, Darius, Aatrox</span></summary>
    <textarea id="pooltxt" rows="6" spellcheck="false">${esc(poolText())}</textarea>
    <div class="nbar"><button id="applytxt" class="on">Appliquer</button><button id="copytxt" class="ghost">Copier</button><span id="txtmsg" class="note"></span></div></details>`;
  $('#team').innerHTML = h;
  $('#applytxt').onclick = () => { const u = parsePools($('#pooltxt').value); save(); renderTeam(); $('#txtmsg').textContent = u.length ? `Non reconnus : ${u.join(', ')}` : 'Pools mis à jour.'; };
  $('#copytxt').onclick = async () => { try { await navigator.clipboard.writeText(poolText()); $('#txtmsg').textContent = 'Copié.'; } catch (e) { $('#pooltxt').select(); $('#txtmsg').textContent = 'Sélectionné : Ctrl+C pour copier.'; } };
  document.querySelectorAll('.pname').forEach(el => el.oninput = e => { S.team[+el.dataset.i].name = el.value; save(); });
  document.querySelectorAll('[data-guide]').forEach(b => b.onclick = () => openGuide(+b.dataset.guide));
  document.querySelectorAll('[data-open]').forEach(b => b.onclick = () => { const i = +b.dataset.open; TEAM_OPEN = TEAM_OPEN === i ? -1 : i; renderTeam(); });
  document.querySelectorAll('.pf').forEach(el => el.onchange = () => { S.team[+el.dataset.i][el.dataset.f] = el.value.trim(); save(); renderTeam(); });
  document.querySelectorAll('[data-cf]').forEach(el => el.onchange = () => { const [i, id] = el.dataset.cf.split(',').map(Number); const p = S.team[i]; p.comf = Object.assign({}, p.comf); if (el.value === '') delete p.comf[id]; else p.comf[id] = +el.value; save(); IDC = { k: null, v: null }; renderTeam(); });
  document.querySelectorAll('[data-rm]').forEach(b => b.onclick = () => { const [i, k] = b.dataset.rm.split(',').map(Number); const p = S.team[i]; const id = p.pool[k]; p.pool.splice(k, 1); if (p.comf) delete p.comf[id]; if (p.want) p.want = p.want.filter(x => x !== id); save(); renderTeam(); });
  document.querySelectorAll('[data-mv]').forEach(b => b.onclick = () => { const [i, k, d] = b.dataset.mv.split(',').map(Number); const a = S.team[i].pool; const j = k + d; if (j < 0 || j >= a.length) return; [a[k], a[j]] = [a[j], a[k]]; save(); renderTeam(); });
  document.querySelectorAll('.addc').forEach(el => {
    const i = +el.dataset.i, role = S.team[i].role, box = $('#sugg' + i);
    const add = id => { S.team[i].pool.push(id); save(); renderTeam(); const n = document.querySelector(`.addc[data-i="${i}"]`); n && n.focus(); };
    const show = () => {
      const q = el.value.trim().toLowerCase();
      if (!q) { box.innerHTML = ''; return; }
      const list = CH.filter(c => !S.team[i].pool.includes(c.id) && (c.n.toLowerCase().includes(q) || c.k.toLowerCase().includes(q)))
        .sort((a, b) => games(b, role) - games(a, role)).slice(0, 8);
      box.innerHTML = list.map(c => `<button data-add="${c.id}">${img(c)} ${esc(c.n)} <small>${games(c, role) >= 400 ? pct(pr(c, role)) + ' de pick ' + RL[role] : 'rarement ' + RL[role]}</small></button>`).join('');
      box.querySelectorAll('[data-add]').forEach(b => b.onmousedown = ev => { ev.preventDefault(); add(+b.dataset.add); });
    };
    el.oninput = show;
    el.onkeydown = e => { if (e.key === 'Enter') { const b = box.querySelector('[data-add]'); if (b) add(+b.dataset.add); } };
    el.onblur = () => setTimeout(() => box.innerHTML = '', 150);
  });
}

// ----- Plan de jeu (commun aux compos et au résumé) -----
function planHtml(plan, title) {
  let h = `<div class="plan">${title ? `<h4>${title}</h4>` : ''}<p>${esc(plan.obj)}</p><p>${esc(plan.focusTxt)}</p>`;
  if (plan.weak && plan.weak.length) h += `<div class="read"><h4>Lecture de leur compo</h4><ul>${plan.weak.map(f => `<li class="${f.kind}"><b>${f.kind === 'weak' ? 'Faiblesse' : 'Menace'} : ${esc(f.txt)}</b> <span>${esc(f.plan)}</span></li>`).join('')}</ul></div>`;
  if (plan.threats.length) h += `<p class="note">${plan.threats.map(esc).join(' ')}</p>`;
  h += `<ul>${plan.lines.map(([r, c, txt]) => `<li><b>${RL[r]}${c ? ' \u00b7 ' + esc(c.n) : ''}</b> : ${esc(txt)}</li>`).join('')}</ul>`;
  if (plan.self && plan.self.length) h += `<p class="note">Points faibles de notre compo, que l\u2019adversaire peut exploiter : ${plan.self.map(f => esc(f.txt)).join(' ; ')}.</p>`;
  return h + '</div>';
}
// 5 choix classés par rôle : le champion de la compo idéale d'abord, puis les meilleurs picks dans le contexte actuel
function roleOptions(ideal) {
  const mine = ourRoles(), out = {};
  ROLES.forEach((r, i) => {
    if (mine[r]) { out[r] = []; return; }
    const p = playerOf(r);
    // classement parmi le pool du joueur (hors pool : affiché à part, à titre d'information)
    const pool = new Set(p.pool.map(id => BY[id]).filter(c => c && available(c)));
    if (!pool.size) simField()[r].slice(0, 5).forEach(o => { if (available(o.c)) pool.add(o.c); });
    const ic = ideal && ideal.cs[i];
    const ev = [...pool].filter(c => available(c) && !Object.values(mine).includes(c)).map(c => {
      const e = evalPick(c, r); const pk = poolRank(r, c);
      const pro = proRole(c, r);
      const tag = [pk >= 0 ? 'pool' : 'hors pool', e.opp ? `${pct(e.lane)} vs ${e.opp.n}` : (proRef() && pro.pres >= 0.05 ? `pro ${pct(pro.pick)} pick, ${pct(pro.ban)} ban` : `blind ${pct(e.lane)}`)].join(' \u00b7 ');
      return { c, score: e.score, inst: e.inst, sim: e.sim, why: e.why, tag, star: ic && c.id === ic.id };
    });
    out[r] = ev;
  });
  const ready = simUse(ROLES.flatMap(r => out[r]));
  ROLES.forEach(r => { out[r].forEach(o => { if (ready) o.tag += ` \u00b7 WR attendu ${pct((50 + o.score) / 100)}`; }); out[r] = out[r].sort((a, b) => b.score - a.score).slice(0, 5); });
  return out;
}
// Counters (solo queue) : à côté du classement méta pro, pour chaque rôle dont l'adversaire de lane est connu
function counterBox(opts) {
  const fmt = x => (x >= 0 ? '+' : '−') + Math.abs(x).toFixed(1).replace('.', ',');
  const groups = ROLES.map(r => counterRecs(r, (opts[r] || []).slice(0, 3).map(o => o.c.id))).filter(Boolean);
  if (!groups.length) return '';
  const row = (x, r, opp) => recRow(x.c, r, [`${pct(x.wr)} contre ${opp.n} (${x.g} parties)`, x.pool ? 'pool' : 'hors pool'], `solo ${fmt(x.solo)} · méta ${fmt(x.meta)}`);
  let h = `<details class="cplan" open><summary><b>Counters (solo queue)</b> <span class="note">· classés par le modèle Master+ seul, sans le recalage pro ; « solo » et « méta » donnent le gain du pick en points de winrate dans chacun des deux classements</span></summary>`;
  groups.forEach(g => {
    const p = playerOf(g.r);
    h += `<div class="rgrp"><h4>${RL[g.r]}${p && p.name ? ' · ' + esc(p.name) : ''} <span class="tag">contre ${esc(g.opp.n)}</span></h4>${g.pool.map(x => row(x, g.r, g.opp)).join('')}${g.off.map(x => row(x, g.r, g.opp)).join('')}</div>`;
  });
  return h + `<p class="note">Seuls les duels mesurés sur au moins 50 parties sont montrés, et ils restent réduits selon leur nombre de parties.</p></details>`;
}
function shapeBox() {
  if (S.mode !== 'tourn') return '';
  const ro = roleOrder(true); if (!ro.length) return '';
  const P = PROSHAPE, bits = [];
  const f = (tab, key) => { const v = P[tab][key]; return v ? `${v[0]} fois, ${pct(v[1] / v[0])} de victoires` : 'jamais vu chez les pros'; };
  bits.push(`Nos picks : ${ro.map(r => ROLE_FR1[r]).join(' \u2192 ')}`);
  if (ro.length >= 3) { const k = ro.slice(0, 3).slice().sort().join(''); bits.push(`phase 1 ${ro.slice(0, 3).map(r => ROLE_FR1[r]).join(' + ')} : ${f('p1', k)}`); }
  const tp = ro.indexOf('T'); if (ro.length >= 3) bits.push(tp >= 0 && tp < 3 ? `top pick\u00e9 en phase 1 : ${f('topp', 'p1')}` : `top gard\u00e9 pour la phase 2 : ${f('topp', 'p2')}`);
  return `<div class="read"><h4>Forme de notre draft</h4><p class="note" style="margin:0">${bits.map(esc).join(' \u00b7 ')}</p></div>`;
}
function proShapeRef() {
  const P = PROSHAPE;
  const row = (tab, key, lab) => { const v = P[tab][key]; return v ? `<tr><td>${lab}</td><td>${v[0]}</td><td><b>${pct(v[1] / v[0])}</b></td></tr>` : ''; };
  const sec = (title, rows) => `<tr><th colspan="3" style="text-align:left;padding-top:8px">${title}</th></tr>` + rows.join('');
  const R = ROLE_FR1;
  let h = `<details class="cplan"><summary><b>Formes de draft chez les pros</b> (Leaguepedia 2026, ligues majeures et internationaux, ${PRODRAFT.games} games)</summary><p class="note">Winrate de chaque forme sur les ${PROSHAPE.teams} compos d\u2019\u00e9quipe, \u00e0 titre d\u2019information : ces formes ne comptent pas dans les scores (aucune valeur mesur\u00e9e au-del\u00e0 de ce que le mod\u00e8le capte d\u00e9j\u00e0). Un \u00e9cart de moins de 5 points sur une centaine de compos peut venir du hasard.</p><table class="sum"><tr><th>Forme</th><th>Compos</th><th>Victoires</th></tr>`;
  h += sec('Profil de d\u00e9g\u00e2ts', [['3-1', '3 AD, 1 AP, 1 tank'], ['2-2', '2 AD, 2 AP, 1 tank'], ['3-2', '3 AD, 2 AP, sans tank'], ['2-1', '2 AD, 1 AP, 2 tanks'], ['4-1', '4 AD, 1 AP']].map(([k, l]) => row('dmg', k, l)));
  h += sec('Engage', [['0-3', 'peu d\u2019engage (0-3)'], ['4-5', 'engage 4-5'], ['6-7', 'engage 6-7'], ['8+', 'beaucoup d\u2019engage (8+)']].map(([k, l]) => row('eng', k, l)).concat([row('engdiff', '+', 'plus d\u2019engage que l\u2019adversaire'), row('engdiff', '-', 'moins d\u2019engage que l\u2019adversaire')]));
  h += sec('Style', Object.keys(ARCH).map(k => row('style', k, ARCH[k])).concat(['engage|poke', 'engage|pick', 'dive|engage', 'poke|dive', 'pick|dive'].map(k => row('stylevs', k, k.split('|').map(a => ARCH[a]).join(' contre ')))));
  h += sec('Courbe', [['early|mid', 'early contre mid game'], ['mid|early', 'mid game contre early'], ['early|early', 'early contre early'], ['mid|mid', 'mid game contre mid game']].map(([k, l]) => row('curvevs', k, l)));
  h += sec('Premier pick (\u00e9quipe qui drafte en premier)', ['J', 'M', 'T', 'S', 'B'].map(k => row('first', k, R[k])));
  h += sec('Deux premiers picks (\u00e9quipe qui drafte en second)', ['BS', 'JM', 'BJ', 'JS', 'JT', 'MS'].map(k => row('first2', k, k.split('').map(r => R[r]).join(' + '))));
  h += sec('R\u00f4les pick\u00e9s en phase 1', ['BJS', 'JMT', 'BMS', 'JMS', 'BST', 'BJM', 'BJT'].map(k => row('p1', k, k.split('').map(r => R[r]).join(' + '))));
  h += sec('Dernier r\u00f4le pick\u00e9', ['T', 'M', 'S', 'B', 'J'].map(k => row('last', k, R[k])));
  h += sec('Blind ou counter', [row('midc', 'b', 'mid pick\u00e9 en blind'), row('midc', 'c', 'mid pick\u00e9 en counter'), row('topc', 'c', 'top en counter'), row('adcc', 'c', 'ADC en counter'), row('cnt', '2', '2 lanes en counter'), row('cnt', '3', '3 lanes en counter')]);
  h += sec('Ordre de draft', [row('fd', '1', '\u00e9quipe qui drafte en premier'), row('fd', '2', '\u00e9quipe qui drafte en second')]);
  return h + '</table></details>';
}
function readBox() {
  const R = readComp(Object.values(enemyRoles().m)), O = readComp(Object.values(ourRoles()));
  const ol = O.list.filter(k => ['ad', 'ap', 'nowave', 'nofront', 'imm', 'noeng'].includes(k));
  if (!R.list.length && !ol.length) return '';
  let h = '<div class="read">';
  if (R.list.length) h += `<h4>Lecture de leur compo</h4><ul>${R.list.map(k => { const f = R.f[k]; return `<li class="${f.kind}"><b>${f.kind === 'weak' ? 'Faiblesse' : 'Menace'} : ${esc(f.txt)}</b> <span>${esc(f.plan)}</span></li>`; }).join('')}</ul>`;
  if (ol.length) h += `<h4 style="margin-top:6px">Ce qu\u2019ils peuvent exploiter chez nous</h4><ul>${ol.map(k => `<li class="threat"><b>${esc(O.f[k].txt)}</b></li>`).join('')}</ul>`;
  return h + '</div>';
}

// ----- Compos -----
let COMP_ARCH = '', COMP_STYLE = '', COMP_LOCK = null, COMP_ONLYWANT = false, COMP_N = 6;
const isTarget = cp => S.target && cp.cs.every((c, i) => c.id === S.target.ids[i]);
// style dominant d'une compo, comparé à des compos tirées au hasard (calibrage fait une fois)
let STY_NORM = null;
function styleNorm() {
  if (STY_NORM) return STY_NORM;
  const pools = ROLES.map(r => CH.filter(c => viable(c, r) && pr(c, r) >= 0.01));
  const acc = {}; Object.keys(STYLES).forEach(k => acc[k] = []);
  let seed = 7; const rnd = n => { seed = (seed * 9301 + 49297) % 233280; return Math.floor(seed / 233280 * n); };
  for (let n = 0; n < 400; n++) { const cs = pools.map(l => l[rnd(l.length)]); if (new Set(cs.map(c => c.id)).size < 5) continue; Object.keys(STYLES).forEach(k => acc[k].push(styleScore(k, cs))); }
  STY_NORM = {}; Object.entries(acc).forEach(([k, v]) => { const m = v.reduce((a, b) => a + b, 0) / v.length; STY_NORM[k] = { m, sd: Math.sqrt(v.reduce((a, b) => a + (b - m) ** 2, 0) / v.length) || 1 }; });
  return STY_NORM;
}
const styleZ = (k, cs) => { const n = styleNorm()[k]; return (styleScore(k, cs) - n.m) / n.sd; };
function styleTags(cs, main) {
  const z = Object.keys(STYLES).map(k => [k, styleZ(k, cs)]).sort((a, b) => b[1] - a[1]);
  const top = main ? [[main, styleZ(main, cs)]].concat(z.filter(x => x[0] !== main)) : z;
  return top.slice(0, 2).filter((x, k) => k === 0 || x[1] >= 0.8).map(x => x[0]);
}
// détail du score d'une compo : mêmes termes que la simulation (en points de winrate), plus les choix de l'équipe à part
function compBreak(cp) {
  const p = cp.parts || { force: 0, lane: 0, syn: 0, vs: 0, pro: 0, comf: 0, choix: 0 };
  let nCf = 0, sCf = 0; cp.cs.forEach((c, i) => { const cf = comfortOf(ROLES[i], c); if (cf != null) { nCf++; sCf += cf; } });
  return { ...p, cf: nCf ? sCf / nCf : null, nPro: cp.cs.filter((c, i) => proRole(c, ROLES[i]).pres >= 0.15).length };
}
function scoreRow(cp) {
  const b = compBreak(cp);
  const chip = (lab, v, tip, sub) => `<span class="sc ${v >= 0.5 ? 'up' : v <= -0.5 ? 'down' : ''}" title="${esc(tip)}"><small>${lab}</small><b>${fmtp(v)}</b>${sub ? `<em>${sub}</em>` : ''}</span>`;
  return `<div class="scrow"><span class="sc tot" title="Winrate attendu au-dessus de 50 % pour les champions encore à picker (modèle de la simulation, côté non compris) ; les compos sont classées par ce total plus les choix de l’équipe"><small>Modèle</small><b>${fmtp(cp.model || 0)}</b></span>
    ${chip('Champions', b.force + b.lane, 'Force des champions et duels de lane (contre l’adversaire connu, sinon contre les champions probables), modèle Master+ recalé sur les pros')}
    ${chip('Synergies', b.syn, 'Synergies mesurées entre ces champions et avec ceux déjà pickés')}
    ${chip('Contre eux', b.vs, 'Effets mesurés contre les champions adverses hors lane (connus, sinon probables)')}
    ${chip('Pro', b.pro, 'Winrate pro 2026 des champions, lissé, niveau des équipes contrôlé', b.nPro ? b.nPro + ' très joués' : '')}
    ${chip('Aisance', b.comf, 'Aisance déclarée : (note − 5) × 0,12 point ; hors pool = note 0', b.cf != null ? b.cf.toFixed(1).replace('.', ',') + '/10' : '')}
    ${Math.abs(b.choix) >= 0.3 ? chip('Choix', b.choix, 'Préférences de l’équipe : compo visée, envies du jour, style demandé (ne viennent pas du modèle)') : ''}</div>`;
}
function compCard(cp, k, withPlan, em) {
  const chosen = isTarget(cp), tags = styleTags(cp.cs, COMP_STYLE || null);
  const plan = gamePlan(cp.cs, em || {}, tags[0]);
  let h = `<div class="ccard ${chosen ? 'best' : ''}"><div class="chead"><b>${STYLES[tags[0]]}</b>${tags[1] ? `<span class="note">+ ${STYLES[tags[1]]}</span>` : ''}<span class="grow"></span>
    ${chosen ? '<span class="tag">compo choisie</span>' : `<button class="on" data-choose="${k}">Partir sur cette compo</button>`}</div>
    ${scoreRow(cp)}
    <div class="crow">${ROLES.map((r, i) => { const c = cp.cs[i]; const pk = poolRank(r, c); const cf = comfortOf(r, c); const tip = `En blind : ${pct(blindVal(c, r))} · en counter-pick : ${pct(counterVal(c, r))}`; return `<div class="cc" title="${tip}">${img(c)}<span><small>${RL[r]}${cf != null ? ` · ${cf}/10` : ''}${wantOf(r, c) ? ' · ★ envie' : ''}</small><b>${esc(c.n)}</b>${pk < 0 && !ourRoles()[r] ? '<em>hors pool</em>' : ''}${cp.cslot === i ? `<em class="ctag">à garder pour la fin (counter-pick : +${(cp.cgap * 100).toFixed(1).replace('.', ',')} pts de duel)</em>` : ''}</span></div>`; }).join('')}</div>`;
  const t = cp.co.t;
  h += `<p class="note">${t.AD} AD, ${t.AP} AP, ${t.T} tank · ${t.c < 0.9 ? 'fort tôt' : t.c > 1.3 ? 'fort tard' : 'fort en mid game'}${cp.co.pen.length ? ' · à surveiller : ' + cp.co.pen.join(', ') : ''}</p>`;
  if (withPlan) h += `<details class="cplan"><summary>Plan de jeu</summary>${planHtml(plan)}</details>`;
  return h + '</div>';
}
function targetBox(where) {
  if (!S.target) return '';
  const st = id => { const i = D() ? D().fill.indexOf(id) : -1;
    if (i >= 0) { const s = D().seq[i]; if (s.t === 'ban') return ['banni', 'gone']; return ours(s) ? ['pické', 'ok'] : ['pris en face', 'gone']; }
    if (locked().has(id)) return ['verrouillé (fearless)', 'gone'];
    return ['dispo', '']; };
  const lab = S.target.style ? STYLES[S.target.style] : ARCH[S.target.arch];
  return `<div class="read target"><h4>Compo choisie : ${lab}${where === 'draft' ? ' <span class="note">(à changer dans l’onglet Compos)</span>' : ''}</h4><div class="trow">${ROLES.map((r, i) => { const c = BY[S.target.ids[i]]; const [l, cls] = st(c.id); return `<span class="tch ${cls}">${img(c)}<span><small>${RL[r]} · ${l}</small><b>${esc(c.n)}</b></span></span>`; }).join('')}</div>
    ${where === 'comps' ? '<div class="nbar"><button id="tgo" class="on">Aller à la draft</button><button id="tclear" class="ghost">Retirer</button></div>' : ''}</div>`;
}
function renderComps() {
  const lockObj = COMP_LOCK ? { [COMP_LOCK.r]: BY[COMP_LOCK.id] } : null;
  const comps = bestComps(COMP_N, { style: COMP_STYLE || null, lock: lockObj, onlyWant: COMP_ONLYWANT });
  const anyWant = S.team.some(p => p.want && p.want.length);
  let h = `<div class="ctrl"><div class="seg"><span>Style</span>${[['', 'Les plus fortes'], ...Object.entries(STYLES)].map(([k, l]) => `<button data-sty="${k}" class="${COMP_STYLE === k ? 'on' : ''}">${l}</button>`).join('')}</div></div>
    ${COMP_STYLE ? `<p class="note">${STYLE_TXT[COMP_STYLE]}</p>` : ''}
    <div class="ctrl"><label>Construire autour de <select id="clock"><option value="">personne en particulier</option>${S.team.map(p => `<optgroup label="${RL[p.role]}${p.name ? ' · ' + esc(p.name) : ''}">${p.pool.map(id => BY[id] ? `<option value="${p.role}|${id}" ${COMP_LOCK && COMP_LOCK.id === id && COMP_LOCK.r === p.role ? 'selected' : ''}>${esc(BY[id].n)}</option>` : '').join('')}</optgroup>`).join('')}</select></label>
      <label class="chk"><input type="checkbox" id="offp" ${OPT.offPool ? 'checked' : ''}> Proposer aussi hors pool</label>
      <label class="chk" title="Champion joué au moins ${PRO_MIN_G} fois à ce rôle dans les parties pros de l’année, et profil de dégâts (AD / AP / tanks) vu dans au moins ${SHAPE_MIN} compos pros"><input type="checkbox" id="prook" ${OPT.proOnly ? 'checked' : ''}> Seulement ce qui se joue en pro</label></div>
    ${proOutNote()}
    <details class="wants" ${anyWant ? 'open' : ''}><summary><b>Envies du jour</b> <span class="note">chacun coche ce qu’il a envie de jouer, les compos se construisent autour (partagé en direct)</span></summary>
      ${S.team.map((p, i) => `<div class="wrow"><span class="prole">${RL[p.role]}</span><span class="wname">${esc(p.name || '')}</span>${p.pool.map(id => { const c = BY[id]; if (!c) return ''; const on = p.want && p.want.includes(id); return `<button class="wch ${on ? 'sel' : ''}" data-want="${i},${id}">${img(c)}${esc(c.n)}${on ? ' ★' : ''}</button>`; }).join('')}</div>`).join('')}
      <label class="chk"><input type="checkbox" id="onlyw" ${COMP_ONLYWANT ? 'checked' : ''}> Seulement les envies (pour les joueurs qui en ont coché)</label></details>`;
  h += targetBox('comps');
  if (!comps.length) h += COMP_STYLE ? `<p class="note">Pas de compo « ${STYLES[COMP_STYLE]} » avec ces réglages. Coche « Proposer aussi hors pool »${OPT.proOnly ? ', décoche « Seulement ce qui se joue en pro »' : ''} ou change de style.</p>` : '<p class="note">Remplis au moins un champion par rôle dans l’onglet Équipe.</p>';
  else {
    h += comps.map((cp, k) => compCard(cp, k, true)).join('');
    h += `<div class="nbar">${comps.length >= COMP_N ? `<button id="cmore" class="on">Afficher 5 compos de plus</button>` : `<span class="note">${comps.length} compos différentes possibles avec ces réglages.</span>`}${COMP_N > 6 ? '<button id="cless" class="ghost">Revenir à 6</button>' : ''}</div>`;
  }
  $('#comps').innerHTML = h;
  const cm = $('#cmore'); if (cm) cm.onclick = () => { COMP_N += 5; const y = window.scrollY; renderComps(); window.scrollTo(0, y); };
  const cl = $('#cless'); if (cl) cl.onclick = () => { COMP_N = 6; renderComps(); };
  document.querySelectorAll('[data-sty]').forEach(b => b.onclick = () => { COMP_STYLE = b.dataset.sty; COMP_N = 6; renderComps(); });
  $('#clock').onchange = e => { const v = e.target.value; COMP_LOCK = v ? { r: v.split('|')[0], id: +v.split('|')[1] } : null; renderComps(); };
  document.querySelectorAll('[data-want]').forEach(b => b.onclick = () => { const [i, id] = b.dataset.want.split(',').map(Number); const p = S.team[i]; p.want = (p.want || []).slice(); const k = p.want.indexOf(id); if (k >= 0) p.want.splice(k, 1); else p.want.push(id); save(); renderComps(); });
  $('#onlyw').onchange = e => { COMP_ONLYWANT = e.target.checked; renderComps(); };
  document.querySelectorAll('[data-choose]').forEach(b => b.onclick = () => { const cp = comps[+b.dataset.choose]; S.target = { ids: cp.cs.map(c => c.id), arch: cp.co.id.main, style: COMP_STYLE || styleTags(cp.cs)[0] }; save(); IDC = { k: null, v: null }; renderComps(); });
  const tg = $('#tgo'); if (tg) tg.onclick = () => { TAB = 'draft'; render(); };
  const tc = $('#tclear'); if (tc) tc.onclick = () => { S.target = null; save(); IDC = { k: null, v: null }; renderComps(); };
  $('#offp').onchange = () => { OPT.offPool = $('#offp').checked; renderComps(); };
  $('#prook').onchange = () => { OPT.proOnly = $('#prook').checked; IDC = { k: null, v: null }; renderComps(); };
}
// champions des pools laissés de côté par l'option « Seulement ce qui se joue en pro »
function proOutNote() {
  if (!OPT.proOnly) return '';
  const out = S.team.map(p => p.pool.map(id => BY[id]).filter(c => c && !proOK(c, p.role)).map(c => `${c.n} ${RL[p.role]} (${proGamesAt(c, p.role)})`)).flat();
  return out.length ? `<p class="note">Pas proposés car presque jamais joués à ce rôle chez les pros (parties sur un an) : ${out.map(esc).join(', ')}.</p>` : '';
}

// ----- Profils des champions (questionnaire pré-rempli) -----
let PROF_F = 'pool', PROF_Q = '';
function profList() {
  const q = normName(PROF_Q);
  let list;
  if (q) list = CH.filter(c => normName(c.n).includes(q) || normName(c.k).includes(q));
  else if (PROF_F === 'pool') list = CH.filter(inAnyPool);
  else if (PROF_F === 'meta') list = CH.filter(c => ROLES.some(r => viable(c, r) && (pr(c, r) >= 0.02 || proPres(c) >= 0.15)));
  else if (PROF_F === 'chg') list = CH.filter(c => PROF[c.id]);
  else list = CH.slice();
  return list.sort((a, b) => a.n.localeCompare(b.n));
}
function renderProf() {
  const list = profList();
  const nChg = Object.keys(PROF).length;
  const opts = (k, v) => { let o = ''; for (let i = 0; i <= LMAX(k); i++) o += `<option value="${i}" ${i === v ? 'selected' : ''}>${i}</option>`; return o; };
  let h = `<p class="lead">Chaque champion a un profil not\u00e9 de 0 \u00e0 3 que l\u2019outil utilise pour lire les compos (identit\u00e9, faiblesses, synergies). Je l\u2019ai pr\u00e9-rempli ; corrige ce qui ne te va pas, en commen\u00e7ant par les champions de vos pools. Les valeurs modifi\u00e9es passent en dor\u00e9 et sont gard\u00e9es sur ton compte.</p>
    <div class="legend">${LKEYS.map(k => `<span><b>${LAB[k][0]}</b> : ${LAB[k][1]}</span>`).join('')}<span><b>Type</b> : AD, AP ou T (tank / utilitaire)</span></div>
    <div class="ctrl"><div class="seg"><span>Afficher</span>${[['pool', 'Pools de l\u2019\u00e9quipe'], ['meta', 'M\u00e9ta'], ['chg', `Modifi\u00e9s (${nChg})`], ['all', 'Tous']].map(([k, l]) => `<button data-pf="${k}" class="${PROF_F === k ? 'on' : ''}">${l}</button>`).join('')}</div>
    <input id="pq" placeholder="Chercher un champion\u2026" value="${esc(PROF_Q)}" style="max-width:220px;background:var(--bg);border:1px solid var(--line);color:var(--txt);border-radius:6px;padding:5px 8px">
    <span class="grow"></span><button id="pexp" class="ghost">Copier mes corrections</button><span id="pmsg" class="note"></span></div>`;
  if (!list.length) h += '<p class="note">Aucun champion dans cette liste.</p>';
  else h += `<div class="pwrap"><table class="ptab"><tr><th>Champion</th><th title="AD, AP ou tank / utilitaire">Type</th>${LKEYS.map(k => `<th title="${esc(LAB[k][1])}">${LAB[k][0]}</th>`).join('')}<th></th></tr>` +
    list.map(c => `<tr class="${PROF[c.id] ? 'chg' : ''}"><td class="n">${img(c)}<b>${esc(c.n)}</b></td>
      <td><select data-pc="${c.id}" data-k="dmg" class="${c.d !== c.d0 ? 'chg' : ''}">${['AD', 'AP', 'T'].map(x => `<option ${c.d === x ? 'selected' : ''}>${x}</option>`).join('')}</select></td>
      ${LKEYS.map(k => `<td><select data-pc="${c.id}" data-k="${k}" class="${tv(c, k) !== c.tr0[TI[k]] ? 'chg' : ''}">${opts(k, tv(c, k))}</select></td>`).join('')}
      <td>${PROF[c.id] ? `<button class="ghost" data-prst="${c.id}" title="Revenir \u00e0 mon estimation">\u21ba</button>` : ''}</td></tr>`).join('') + '</table></div>';
  $('#prof').innerHTML = h;
  document.querySelectorAll('[data-pf]').forEach(b => b.onclick = () => { PROF_F = b.dataset.pf; PROF_Q = ''; renderProf(); });
  const pq = $('#pq'); pq.oninput = () => { PROF_Q = pq.value; const pos = pq.selectionStart; renderProf(); const n = $('#pq'); n.focus(); n.setSelectionRange(pos, pos); };
  document.querySelectorAll('[data-pc]').forEach(sel => sel.onchange = () => { const c = BY[+sel.dataset.pc]; const k = sel.dataset.k; setProf(c, k, k === 'dmg' ? sel.value : +sel.value); renderProf(); });
  document.querySelectorAll('[data-prst]').forEach(b => b.onclick = () => { delete PROF[+b.dataset.prst]; applyProf(); saveProf(); renderProf(); });
  $('#pexp').onclick = async () => {
    const txt = Object.keys(PROF).map(id => { const c = BY[id]; if (!c) return ''; const d = []; if (c.d !== c.d0) d.push(`type ${c.d0}\u2192${c.d}`); LKEYS.forEach(k => { const i = TI[k]; if (c.tr[i] !== c.tr0[i]) d.push(`${LAB[k][0]} ${c.tr0[i]}\u2192${c.tr[i]}`); }); return `${c.n} : ${d.join(', ')}`; }).filter(Boolean).join('\n') || 'Aucune correction.';
    try { await navigator.clipboard.writeText(txt); $('#pmsg').textContent = 'Copi\u00e9.'; } catch (e) { $('#pmsg').textContent = 'Copie impossible dans ce navigateur.'; }
  };
}

// ----- Draft -----
function stepLabel(st) {
  const side = st.s === 'B' ? 'bleu' : 'rouge';
  return `${st.t === 'ban' ? 'Ban' : 'Pick'} ${side}${ours(st) ? ' (nous)' : ' (adversaire)'}`;
}

function applyChamp(id, role) {
  const st = curStep(); if (!st) return;
  const c = BY[id]; if (!c || !available(c)) return;
  const i = D().fill.length;
  D().fill.push(id);
  if (st.t === 'pick' && ours(st)) {
    const mine = ourRoles();
    let r = role;
    if (!r || mine[r]) {
      const open = ROLES.filter(x => !mine[x]);
      r = open.find(x => playerOf(x).pool.includes(id)) || open.sort((a, b) => share(c, b) - share(c, a))[0];
    }
    D().roles[i] = r;
  }
  save(); renderDraft();
}

function slot(i) {
  const st = D().seq[i], id = D().fill[i], c = id != null ? BY[id] : null;
  const cur = i === D().fill.length;
  if (st.t === 'ban') return `<div class="bslot ${cur ? 'cur' : ''}">${c ? img(c, 'gray') : ''}</div>`;
  let roleSel = '';
  if (c) {
    const isOurs = ours(st);
    const r = isOurs ? D().roles[i] : (D().roles[i] || enemyRoles().idx[i]);
    roleSel = `<select data-role="${i}">${isOurs ? '' : `<option value="">auto (${RL[enemyRoles().idx[i]] || '?'})</option>`}${ROLES.map(x => `<option value="${x}" ${D().roles[i] === x ? 'selected' : ''}>${RL[x]}</option>`).join('')}</select>`;
    if (isOurs) { const p = playerOf(r); roleSel += `<small>${esc(p && p.name ? p.name : '')}</small>`; }
  }
  return `<div class="pslot ${cur ? 'cur' : ''}">${c ? img(c) : '<div class="ph"></div>'}<div class="pinfo"><b>${c ? esc(c.n) : (cur ? 'En cours' : '')}</b>${roleSel}</div></div>`;
}

function sideCol(side) {
  const idx = D().seq.map((st, i) => ({ st, i })).filter(x => x.st.s === side);
  const bans = idx.filter(x => x.st.t === 'ban').map(x => slot(x.i)).join('');
  const picks = idx.filter(x => x.st.t === 'pick').map(x => slot(x.i)).join('');
  return `<div class="col ${side === 'B' ? 'blue' : 'red'}"><h3>${side === 'B' ? 'Bleu' : 'Rouge'}${side === S.side ? ' · nous' : ''}</h3><div class="bans">${bans}</div><div class="picks">${picks}</div></div>`;
}

function controls() {
  const t = tourn();
  return `<div class="ctrl">
    <div class="seg"><span>Mode</span><button data-mode="flex" class="${!t ? 'on' : ''}">Flex</button><button data-mode="tourn" class="${t ? 'on' : ''}">Tournoi</button></div>
    <div class="seg"><span>Nous sommes</span><button data-side="B" class="${S.side === 'B' ? 'on' : ''}">Bleu (1er pick)</button><button data-side="R" class="${S.side === 'R' ? 'on' : ''}">Rouge (dernier pick)</button></div>
    ${t ? `<label class="chk"><input type="checkbox" id="fear" ${S.fearless ? 'checked' : ''}> Fearless</label>` : ''}
    ${t && S.fearless ? `<span class="game">Game ${S.series.game} · ${S.series.locked.length} champions verrouillés</span><button id="nextg">Game suivante</button><button id="resets" class="ghost">Nouvelle série</button>` : ''}
    ${typeof autoControl === 'function' ? autoControl() : ''}
    <span class="grow"></span>
    <button id="undo" class="ghost">Annuler</button><button id="reset" class="ghost">Réinitialiser</button>
  </div>`;
}

function recPanel() {
  const st = curStep();
  if (!st) return summary();
  let h = `<div class="stepbar">Étape ${D().fill.length + 1}/${D().seq.length} · ${st.ph} · <b>${stepLabel(st)}</b></div>`;
  const ideal = bestComps(1, { target: true })[0];
  h += targetBox('draft');
  if (ideal) {
    const order = idealOrder(ideal);
    const canPick = st.t === 'pick' && ours(st);
    const opts = roleOptions(ideal);
    h += `<details class="ideal" open><summary><b>${S.target ? 'Compo vis\u00e9e \u00e0 ce stade' : 'Compo id\u00e9ale \u00e0 ce stade'}</b> \u00b7 ${S.target && S.target.style ? STYLES[S.target.style] : STYLES[styleTags(ideal.cs)[0]]} <span class="note">\u00b7 5 choix par r\u00f4le, class\u00e9s par winrate final simul\u00e9 (aisance comprise), \u2605 = celui de la compo id\u00e9ale${SIM_PENDING ? ' \u00b7 simulations en cours\u2026' : ''}</span></summary><div class="ropt">${ROLES.map((r, i) => {
      const done = ourRoles()[r], p = playerOf(r);
      const head = `<div class="rhead"><b>${RL[r]}</b>${p.name ? ` <small>${esc(p.name)}</small>` : ''}</div>`;
      if (done) return `<div class="rcol done">${head}<div class="ritem picked">${img(done)}<span><b>${esc(done.n)}</b><small>pick\u00e9</small></span></div></div>`;
      return `<div class="rcol">${head}${opts[r].map((o, k) => `<button class="ritem ${o.star ? 'star' : ''}" ${canPick ? `data-pick="${o.c.id}" data-r="${r}"` : 'disabled'} title="${esc(o.why.join(' \u00b7 '))}"><em>${k + 1}</em>${img(o.c)}<span><b>${o.star ? '\u2605 ' : ''}${esc(o.c.n)}</b><small>${o.tag}</small></span></button>`).join('')}</div>`;
    }).join('')}</div>
      ${order.length && st.t === 'pick' && ours(st) ? `<p class="note">Ordre conseill\u00e9 pour la compo id\u00e9ale : ${order.map(o => `${esc(o.c.n)} (${RL[o.r]}${o.dv ? ` ${o.dv.toFixed(2).replace('.', ',').replace('-', '\u2212')}` : ''}${o.ps != null ? ` \u00b7 pros n\u00b0${o.ps.toFixed(1).replace('.', ',')}` : ''})`).join(' \u2192 ')}${order.ready ? ` <span title="Entre parenth\u00e8ses : \u00e9cart de winrate final simul\u00e9 (${SIM_NP} fins de draft) si on le prend maintenant plut\u00f4t que le meilleur, et position moyenne de ce pick chez les pros (1 \u00e0 10). Quand les \u00e9carts sont sous l\u2019erreur de simulation, l\u2019ordre suit celui des pros.">\u00b7 ${order.some(o => o.tie) ? '\u00e9carts trop petits pour trancher : ordre des pros (pick prioritaire, bot t\u00f4t, counters \u00e0 la fin)' : 'ordre mesur\u00e9 par simulation'}</span>` : ' \u00b7 affinage en cours\u2026'}</p>` : ''}</details>`;
  }
  if (ideal && st.t === 'pick' && ours(st)) h += counterBox(roleOptions(ideal));
  h += shapeBox();
  h += readBox();
  if (st.t === 'ban' && ours(st)) {
    h += banBox();
  } else if (st.t === 'pick' && ours(st)) {
    const recs = pickRecs();
    if (ideal) {
      const bn = bestNow(ideal);
      h += `<div class="hl"><h4>\u00c0 prendre maintenant <span class="note">\u00b7 tous r\u00f4les, winrate final simul\u00e9 sur les fins de draft possibles</span></h4><div class="nowg">${bn.map((o, k) => `<button class="ritem now ${k === 0 ? 'star' : ''}" data-pick="${o.c.id}" data-r="${o.r}" title="${esc(o.why.join(' \u00b7 '))}"><em>${k + 1}</em>${img(o.c)}<span><b>${esc(o.c.n)} <small style="display:inline">${RL[o.r]}</small></b><small>${o.tag}${o.star ? ' \u00b7 \u2605 compo id\u00e9ale' : ''}</small><small>${esc((proRef() ? o.why.filter(w => /pros?\b|chez les pros/.test(w)).concat(o.why.filter(w => / contre /.test(w) && !/pros/.test(w))) : o.why).slice(0, 3).join(' \u00b7 '))}</small></span></button>`).join('')}</div></div>`;
    }
    const first = false;
    if (first) {
      const all = recs.flatMap(g => g.poolEv.slice(0, 2)).sort((a, b) => b.score - a.score).slice(0, 3);
      h += `<div class="hl"><h4>Meilleur blind pick</h4>${all.length ? all.map(e => recRow(e.c, e.r, e.why, `${RL[e.r]} · ${scoreTxt(e)}`)).join('') : '<p class="note">Remplis les pools dans l’onglet Équipe.</p>'}</div>`;
    }
    h += `<details class="cplan"><summary><b>D\u00e9tail des alternatives r\u00f4le par r\u00f4le</b> (raisons compl\u00e8tes)</summary><p class="note">R\u00f4les class\u00e9s par la valeur de leur meilleur pick maintenant (simulation des fins de draft).</p>`;
    recs.forEach((g, k) => {
      h += `<div class="rgrp"><h4>${k + 1}. ${RL[g.r]}${g.player.name ? ' · ' + esc(g.player.name) : ''}${g.enemyKnown ? ' <span class="tag">adversaire connu</span>' : ''}</h4>`;
      if (g.empty) h += `<p class="note">Aucun champion du pool disponible.</p>`;
      h += g.poolEv.slice(0, 3).map(e => recRow(e.c, e.r, e.why, scoreTxt(e))).join('');
      const off = g.empty ? g.offAll.slice(0, 3) : g.offShow;
      if (off.length) h += `<div class="off"><span>Hors pool, pour info (non classé : leur winrate est celui de joueurs qui les maîtrisent) :</span>${off.map(e => recRow(e.c, e.r, e.why, scoreTxt(e))).join('')}</div>`;
      h += `</div>`;
    });
    h += `</details>`;
  } else if (st.t === 'ban') {
    const top = CH.filter(available).sort((a, b) => b.b - a.b).slice(0, 8);
    h += `<p class="note">Entre les bans adverses. Les plus bannis en Master+ :</p><div class="minis">${top.map(c => `<button class="mini" data-pick="${c.id}">${img(c)}<span>${esc(c.n)}<small>${pct(banRate(c))}</small></span></button>`).join('')}</div>`;
  } else {
    h += dangerBox('Entre le pick adverse', 'Ce qu’ils peuvent prendre de plus dangereux pour nous :');
  }
  return h;
}
function scoreTxt(e) { return `${e.simReady ? 'WR attendu ' + pct((50 + e.score) / 100) : pct(e.lane)}${e.pk < 0 ? ' · hors pool' : ''}`; }
function banBox() {
  const recs = banSimRecs(8);
  if (recs == null) return `<p class="note"><b>Bans</b> · simulations en cours…</p>`;
  return `<p class="note"><b>Picks les plus dangereux pour notre compo</b> · gain de winrate final si on le bannit (ce qu’ils ne pourront plus prendre, moins ce qu’on perd si on le jouait).</p><ol class="recs">${recs.map(o => recRow(o.c, null, [`surtout ${RL[o.r]}`], `+${o.gain.toFixed(2).replace('.', ',')}`)).join('')}</ol>`;
}
function dangerBox(title, note) {
  const recs = dangerRecs(8);
  if (recs == null) return `<p class="note"><b>${title}</b> · simulations en cours…</p>`;
  return `<p class="note"><b>${title}</b> · ${note}</p><ol class="recs">${recs.map(o => recRow(o.c, null, [`${RL[o.r]} : −${o.drop.toFixed(1).replace('.', ',')} point de winrate pour nous s’ils le prennent`, `joué ${pct(o.p)} du temps à ce rôle`], `−${(o.loss).toFixed(2).replace('.', ',')}`)).join('')}</ol>`;
}
function recRow(c, role, why, right, static_) {
  return `<li class="rec"><button class="rbtn" ${static_ ? 'disabled' : `data-pick="${c.id}"`} ${role ? `data-r="${role}"` : ''}>${img(c)}<span class="rmain"><b>${esc(c.n)}</b><small>${why.map(esc).join(' · ')}</small></span><span class="rright">${esc(right || '')}</span></button></li>`;
}

// Objets conseillés face à leur compo, pour chacun de nos joueurs
function itemsBox(mine, er, open = true) {
  if (typeof ITEMS === 'undefined' || !ITEMS) return '';
  const en = ROLES.map(r => er[r]).filter(Boolean);
  const ico = x => `<img class="ic" src="https://ddragon.leagueoflegends.com/cdn/${ITEMS.v}/img/item/${x.id}.png" alt="" title="${esc(x.n)}" onerror="this.style.display='none'">`;
  const fmt = x => (x >= 0 ? '+' : '−') + Math.abs(x).toFixed(1).replace('.', ',');
  const cell = x => `<span class="itm" title="${esc(x.n)} : ${fmt(x.rel)} pt par rapport à l’objet moyen sur ce champion${Math.abs(x.vs) >= 0.3 ? ` (dont ${fmt(x.vs)} face à leur compo)` : ''} ; fini par ${Math.round(x.use * 100)} % des joueurs">${ico(x)}<small>${esc(x.n)} ${fmt(x.rel)}</small></span>`;
  let h = `<details class="cplan" ${open ? 'open' : ''}><summary><b>Objets conseillés</b> <span class="note">· écart de winrate mesuré à valeur en or des objets finis et durée de partie égales, par rapport à l’objet moyen du champion ; objets finis par au moins 200 joueurs de ce champion à ce rôle ; ordre d’achat pas encore mesuré ; non adaptés à la compo adverse (aucun effet mesurable)</span></summary>`;
  ROLES.forEach(r => {
    const c = mine[r]; if (!c) return;
    const x = itemRecs(c, r, en);
    if (!x) { h += `<p class="note">${RL[r]} · ${esc(c.n)} : pas assez de parties pour conseiller des objets.</p>`; return; }
    const sit = situationalItems(c, r, en);
    const scell = y => `<span class="itm" title="${esc(y.n)} : ${esc(y.why)}${y.rel != null ? ` ; mesuré sur ce champion ${fmt(y.rel)} pt` : ''}">${ico(y)}<small>${esc(y.n)} <em>${esc(y.why)}</em></small></span>`;
    h += `<div class="rgrp"><h4>${RL[r]} · ${esc(c.n)} <span class="note">(${x.n} parties)</span></h4><div class="itms">${x.boots.map(cell).join('')}${x.boots.length ? '<span class="sep">|</span>' : ''}${x.legs.map(cell).join('')}</div>${sit.length ? `<div class="itms sit"><span class="note">Situationnels :</span>${sit.map(scell).join('')}</div>` : ''}</div>`;
  });
  return h + `<p class="note">Ligne du haut : objets mesurés sur le champion (un objet qu’on achète surtout en avance ou en difficulté peut paraître meilleur ou pire qu’il n’est). « Situationnels » : règles de jeu selon leur compo (suppression, gros contrôle, engage, soins, tanks, boucliers, type de dégâts), écrites à la main et non mesurées.</p></details>`;
}
function summary() {
  const mine = ourRoles(), er = enemyRoles().m;
  const n = compBalance();
  let h = `<div class="stepbar"><b>Draft terminée</b></div><table class="sum"><tr><th>Rôle</th><th>Nous</th><th>Eux</th><th>WR de lane estimé</th></tr>`;
  ROLES.forEach(r => {
    const a = mine[r], b = er[r];
    let w = '';
    if (a && b) { const v = wrVs(a, b, r); w = `${pct(v.wr)}${v.g ? ` (${v.g} parties)` : ' (estimé)'}`; }
    h += `<tr><td>${RL[r]}</td><td>${a ? img(a) + esc(a.n) : '-'}</td><td>${b ? img(b) + esc(b.n) : '-'}</td><td>${w}</td></tr>`;
  });
  h += `</table><p class="note">Dégâts de notre compo : ${n.AD} AD, ${n.AP} AP, ${n.T} tank ou utilitaire.${(n.AD >= 4 || n.AP >= 4) ? ' Compo très déséquilibrée : l’adversaire peut stacker armure ou résistance magique.' : ''}</p>`;
  if (Object.keys(mine).length === 5 && Object.keys(er).length === 5) h += scoreBox(mine, er);
  if (Object.keys(mine).length === 5 && Object.keys(er).length === 5) h += itemsBox(mine, er);
  const csArr = ROLES.map(r => mine[r]);
  if (csArr.every(Boolean)) { const plan = gamePlan(csArr, er); h += planHtml(plan, `Plan de jeu \u00b7 ${ARCH[plan.id.main]}`); }
  if (tourn() && S.fearless) h += `<p class="note">Clique sur « Game suivante » pour verrouiller ces 10 champions pour le reste de la série.</p>`;
  return h;
}

function scoreBox(mine, er) {
  const sc = draftScore(mine, er);
  const f = x => fmtp(x).replace('\u2212', '\u2212');
  const ours = sc.scoreA, theirs = sc.scoreB;
  const verdict = sc.total >= 4 ? 'Draft nettement en notre faveur.' : sc.total >= 1.5 ? 'L\u00e9ger avantage de draft pour nous.' : sc.total > -1.5 ? 'Draft \u00e9quilibr\u00e9e : la partie se jouera sur l\u2019ex\u00e9cution.' : sc.total > -4 ? 'L\u00e9ger avantage de draft pour eux : jouer notre plan avec rigueur.' : 'Draft d\u00e9favorable sur le papier : jouer nos points forts et leurs faiblesses.';
  let h = `<div class="score-box"><div class="sb-top"><div class="sb-team us"><small>Nous</small><b>${sc.wr.toFixed(1).replace('.', ',')} %</b><span>score de compo ${f(ours)}</span></div>
    <div class="sb-mid">${esc(verdict)}</div>
    <div class="sb-team them"><small>Eux</small><b>${(100 - sc.wr).toFixed(1).replace('.', ',')} %</b><span>score de compo ${f(theirs)}</span></div></div>
    <table class="sum"><tr><th>Ce qui compte</th><th>Nous</th><th>Eux</th><th>\u00c9cart</th></tr>${sc.parts.map(p => `<tr><td>${p[0]}</td><td>${p[2] == null ? '<span class="note">face \u00e0 face</span>' : f(p[2])}</td><td>${p[3] == null ? '' : f(p[3])}</td><td><b>${f(p[1])}</b></td></tr>`).join('')}
    <tr><td><b>Avantage de draft (points de winrate)</b></td><td></td><td></td><td><b>${f(sc.total)}</b></td></tr></table>
    <p class="note">Score de compo = force des champions + synergies internes : ce que vaut chaque compo seule. Le winrate estim\u00e9 ajoute le face-\u00e0-face (duels de lane et croisements entre les deux compos).</p>`;
  const lanes = sc.lane.filter(x => Math.abs(x[4]) >= 0.3).sort((a, b) => Math.abs(b[4]) - Math.abs(a[4]));
  const det = [];
  lanes.slice(0, 3).forEach(([r, a, b, wr, res, g]) => det.push(`${RL[r]} : ${a.n} contre ${b.n} ${f(res)} (${pct(wr)} sur ${g} parties)`));
  const best = (M, O) => { const it = []; ROLES.forEach(r => { if (M[r]) ctxFit(M[r], r, {}, O).items.forEach(i => it.push([i.x, `${M[r].n} ${i.txt}`])); }); return it.sort((a, b) => Math.abs(b[0]) - Math.abs(a[0])).slice(0, 3); };
  const cx = best(mine, er).filter(x => Math.abs(x[0]) >= 0.4);
  if (sc.shA.items.length) h += `<p class="note"><b>Forme de draft chez les pros :</b> ${sc.shA.items.map(i => esc(`${i.lab} : ${pct(i.wr)} sur ${i.n} compos`)).join(' \u00b7 ')}</p>`;
  if (det.length) h += `<p class="note"><b>Duels qui p\u00e8sent :</b> ${det.map(esc).join(' \u00b7 ')}</p>`;
  if (cx.length) h += `<p class="note"><b>Croisements qui p\u00e8sent (pour nous) :</b> ${cx.map(x => esc(`${f(x[0])} ${x[1]}`)).join(' \u00b7 ')}</p>`;
  h += `<p class="note">Estimation tir\u00e9e des stats Master+ (U.GG pour les champions et les duels, LoLalytics pour les croisements et les synergies), en supposant deux \u00e9quipes de m\u00eame niveau. Elle mesure l\u2019avantage du draft, pas celui des joueurs : un \u00e9cart de 5 points est d\u00e9j\u00e0 un gros avantage de draft.</p></div>`;
  return h;
}

function grid() {
  const roleBtns = ['all', ...ROLES].map(r => `<button data-gr="${r}" class="${GRID_ROLE === r ? 'on' : ''}">${r === 'all' ? 'Tous' : RL[r]}</button>`).join('');
  const lk = locked(), u = used();
  const q = GRID_Q.toLowerCase();
  const list = CH.filter(c => (!q || c.n.toLowerCase().includes(q) || c.k.toLowerCase().includes(q)) && (GRID_ROLE === 'all' || viable(c, GRID_ROLE)))
    .sort((a, b) => GRID_ROLE === 'all' ? a.n.localeCompare(b.n) : games(b, GRID_ROLE) - games(a, GRID_ROLE));
  return `<div class="gbar"><input id="gq" placeholder="Chercher un champion…" value="${esc(GRID_Q)}"><div class="seg">${roleBtns}</div></div>
    <div class="grid">${list.map(c => { const off = u.has(c.id) || lk.has(c.id); return `<button class="gc ${off ? 'off' : ''} ${inAnyPool(c) ? 'pool' : ''}" data-pick="${c.id}" ${off ? 'disabled' : ''} title="${esc(c.n)}${lk.has(c.id) ? ' (fearless)' : ''}">${img(c)}<span>${esc(c.n)}</span></button>`; }).join('')}</div>`;
}

function renderDraft() {
  const gq = document.activeElement && document.activeElement.id === 'gq';
  $('#draft').innerHTML = controls() + `<div class="board">${sideCol('B')}<div class="mid">${recPanel()}</div>${sideCol('R')}</div>` + grid();
  // contrôles
  document.querySelectorAll('[data-mode]').forEach(b => b.onclick = () => { if (S.mode === b.dataset.mode) return; S.mode = b.dataset.mode; newDraft(); renderDraft(); });
  document.querySelectorAll('[data-side]').forEach(b => b.onclick = () => { if (S.side === b.dataset.side) return; S.side = b.dataset.side; newDraft(); renderDraft(); });
  const f = $('#fear'); if (f) f.onchange = () => { S.fearless = f.checked; save(); renderDraft(); };
  const ng = $('#nextg'); if (ng) ng.onclick = () => { D().seq.forEach((st, i) => { if (st.t === 'pick' && D().fill[i] != null && !S.series.locked.includes(D().fill[i])) S.series.locked.push(D().fill[i]); }); S.series.game++; newDraft(); renderDraft(); };
  const rs = $('#resets'); if (rs) rs.onclick = () => { S.series = { game: 1, locked: [] }; newDraft(); renderDraft(); };
  $('#undo').onclick = () => { const i = D().fill.length - 1; if (i < 0) return; D().fill.pop(); delete D().roles[i]; save(); renderDraft(); };
  $('#reset').onclick = () => { newDraft(); renderDraft(); };
  document.querySelectorAll('[data-pick]').forEach(b => b.onclick = () => applyChamp(+b.dataset.pick, b.dataset.r));
  document.querySelectorAll('[data-role]').forEach(s => s.onchange = () => { const i = +s.dataset.role; if (s.value) D().roles[i] = s.value; else delete D().roles[i]; save(); renderDraft(); });
  document.querySelectorAll('[data-gr]').forEach(b => b.onclick = () => { GRID_ROLE = b.dataset.gr; renderDraft(); });
  const g = $('#gq'); g.oninput = () => { GRID_Q = g.value; const pos = g.selectionStart; renderDraft(); const n = $('#gq'); n.focus(); n.setSelectionRange(pos, pos); };
  if (gq) { const n = $('#gq'); n.focus(); }
  if (typeof autoBind === 'function') autoBind();
}

document.querySelectorAll('.tabs button').forEach(b => b.onclick = () => { TAB = b.dataset.tab; render(); });
$('#meta').textContent = `${DATA.rank} · patchs ${DATA.patches} · ${DATA.T.toLocaleString('fr-FR')} parties · pro : ${DATA.proLabel}, ${DATA.proGames} games · données du ${DATA.date.split('-').reverse().join('/')} · contexte de compo : LoLalytics Master+ 30 jours`;
render();

// ===== Sauvegarde des pools sur le compte (db), avec repli dans le navigateur =====
let DBREF = null, lastTeam = JSON.stringify(S.team), dbTimer = null;
const _save = save;
save = function () {
  _save();
  const cur = JSON.stringify(S.team);
  if (cur !== lastTeam) {
    lastTeam = cur;
    if (DBREF) { clearTimeout(dbTimer); dbTimer = setTimeout(async () => { try { await DBREF.set({ team: S.team, updated: new Date().toISOString() }); setSaveMsg('Pools sauvegard\u00e9s sur ton compte.'); } catch (e) { setSaveMsg('Sauvegarde en ligne impossible, pools gard\u00e9s dans ce navigateur.'); } }, 800); }
  }
};
function setSaveMsg(m) { SAVE_MSG = m; const el = document.getElementById('savemsg'); if (el) el.textContent = m; }
setSaveMsg('Pools gard\u00e9s dans ce navigateur.');
(async () => {
  try {
    const db = await getDB();
    if (!db) return;
    DBREF = db.doc('team/main');
    PDBREF = db.doc('profiles/main');
    PDBREF.get().then(ps => {
      const pd = ps.exists ? ps.data() : null;
      if (pd && pd.prof && typeof pd.prof === 'object') { PROF = pd.prof; try { localStorage.setItem('draftTool.prof', JSON.stringify(PROF)); } catch (e) { } applyProf(); render(); }
      else if (window.SEED && window.SEED.prof && !Object.keys(PROF).length) { PROF = JSON.parse(JSON.stringify(window.SEED.prof)); try { localStorage.setItem('draftTool.prof', JSON.stringify(PROF)); } catch (e) { } applyProf(); saveProf(); render(); }
      else if (Object.keys(PROF).length) saveProf();
    }).catch(() => { });
    const timer = setTimeout(() => setSaveMsg('Compte injoignable pour l\u2019instant, pools gard\u00e9s dans ce navigateur.'), 10000);
    const snap = await DBREF.get();
    clearTimeout(timer);
    startLive(db); startIngameSync(db);
    const d = snap.exists ? snap.data() : null;
    if (d && Array.isArray(d.team) && d.team.length === 5) {
      S.team = JSON.parse(JSON.stringify(d.team)); lastTeam = JSON.stringify(S.team); _save(); render();
      setSaveMsg('Pools charg\u00e9s depuis ton compte.');
    } else {
      if (window.SEED && window.SEED.team) { S.team = JSON.parse(JSON.stringify(window.SEED.team)); lastTeam = JSON.stringify(S.team); _save(); render(); }
      await DBREF.set({ team: S.team, updated: new Date().toISOString() });
      setSaveMsg('Pools sauvegard\u00e9s sur ton compte.');
    }
  } catch (e) { setSaveMsg('Pools gard\u00e9s dans ce navigateur.'); }
})();


// ===== Session partagée : tout le monde sur la même draft en direct =====
var CLIENT = Math.random().toString(36).slice(2, 10);
var LIVE_ON = true; try { LIVE_ON = localStorage.getItem('draftTool.live') !== '0'; } catch (e) { }
var ME = ''; try { ME = localStorage.getItem('draftTool.me') || ''; } catch (e) { }
var LREF = null, lastLive = '', liveTimer = null, PEERS = [], ROOM = null, pendingRender = false;
const liveState = () => JSON.stringify({ mode: S.mode, side: S.side, ref: S.ref || 'pro', fearless: S.fearless, series: S.series, target: S.target || null, draft: S.draft });
function safeRender() {
  const a = document.activeElement;
  if (a && (a.tagName === 'TEXTAREA' || (a.tagName === 'INPUT' && a.type !== 'checkbox'))) { pendingRender = true; return; }
  render();
}
document.addEventListener('focusout', () => { if (pendingRender) { pendingRender = false; setTimeout(render, 50); } });
var CAN_WRITE = null;
function pushLive() {
  if (!LREF || !LIVE_ON || CAN_WRITE === false) return;
  const cur = liveState(); if (cur === lastLive) return;
  lastLive = cur;
  clearTimeout(liveTimer);
  liveTimer = setTimeout(() => { LREF.set({ state: cur, by: CLIENT, who: ME || '', at: Date.now() }).catch(() => liveMsg('Synchronisation impossible (droits insuffisants ?)')); }, 250);
}
const _save2 = save;
save = function () { _save2(); pushLive(); };
function liveMsg(m) { const el = document.getElementById('livemsg'); if (el) el.textContent = m; }
async function startLive(db) {
  try {
    // pools et profils : mises à jour des autres en direct
    if (DBREF.onSnapshot) DBREF.onSnapshot(s => {
      const d = s && s.exists ? s.data() : null;
      if (d && Array.isArray(d.team) && d.team.length === 5) { const t = JSON.stringify(d.team); if (t !== JSON.stringify(S.team)) { S.team = JSON.parse(t); lastTeam = t; _save(); IDC = { k: null, v: null }; safeRender(); } }
    });
    if (PDBREF && PDBREF.onSnapshot) PDBREF.onSnapshot(s => {
      const d = s && s.exists ? s.data() : null;
      if (d && d.prof && JSON.stringify(d.prof) !== JSON.stringify(PROF)) { PROF = d.prof; try { localStorage.setItem('draftTool.prof', JSON.stringify(PROF)); } catch (e) { } applyProf(); safeRender(); }
    });
    try { const us = window.claude ? await window.claude.use('user') : null; CAN_WRITE = us && us.can ? us.can('data.write') : null; } catch (e) { CAN_WRITE = null; }
    LREF = db.doc('live/draft');
    const first = await LREF.get();
    const apply = d => {
      if (!d || !d.state || !LIVE_ON) return;
      if (d.state === lastLive || d.state === liveState()) { lastLive = d.state; return; }
      try { const o = JSON.parse(d.state); Object.assign(S, o); lastLive = d.state; _save(); IDC = { k: null, v: null }; safeRender(); liveMsg(d.who ? `Dernière action : ${d.who}` : ''); } catch (e) { }
    };
    if (first.exists && LIVE_ON) apply(first.data()); else pushLive();
    if (LREF.onSnapshot) LREF.onSnapshot(s => { const d = s && s.exists ? s.data() : null; if (d && d.by !== CLIENT) apply(d); });
    render();
  } catch (e) { LREF = null; }
  try {
    ROOM = await getRoom();
    if (ROOM) {
      ROOM.onPeers(ps => { PEERS = ps || []; const el = document.getElementById('peers'); if (el) el.innerHTML = peersHtml(); });
      ROOM.presence({ name: ME || 'Anonyme', tab: TAB });
    }
  } catch (e) { ROOM = null; }
}
function peersHtml() {
  if (!ROOM) return '';
  const TABN = { team: 'Équipe', comps: 'Compos', prof: 'Profils', draft: 'Draft', ingame: 'En jeu' };
  const ps = PEERS.map(p => { const st = (p && (p.state || p.presence || p.data)) || p || {}; return `${esc(st.name || 'Anonyme')}${p && (p.self || p.isSelf || p.you) ? ' (toi)' : ''}${st.tab ? ` <small>${TABN[st.tab] || ''}</small>` : ''}`; });
  return ps.length ? `En ligne : ${ps.join(' · ')}` : '';
}
function liveBar() {
  if (!LREF) return '';
  const names = S.team.map(t => t.name).filter(Boolean);
  return `<div class="livebar"><label class="chk"><input type="checkbox" id="liveon" ${LIVE_ON ? 'checked' : ''}> Draft partagée en direct</label>
    <span class="seg"><span>Je suis</span><select id="mesel"><option value="">—</option>${names.concat(['Coach', 'Spectateur']).map(n => `<option ${n === ME ? 'selected' : ''}>${esc(n)}</option>`).join('')}</select></span>
    <span id="peers" class="note">${peersHtml()}</span>${window.FBSTORE_PROMISE ? `<button class="ghost small" onclick="changeTeamCode()">Code d’équipe</button>` : ''}<span id="livemsg" class="note">${CAN_WRITE === false && LIVE_ON ? 'Mode spectateur : tu suis la draft en direct, seuls les membres invit\u00e9s peuvent la modifier.' : ''}</span></div>`;
}
function bindLive() {
  const cb = document.getElementById('liveon'); if (cb) cb.onchange = () => { LIVE_ON = cb.checked; try { localStorage.setItem('draftTool.live', LIVE_ON ? '1' : '0'); } catch (e) { } if (LIVE_ON && LREF) LREF.get().then(s => { if (s.exists) { lastLive = ''; const d = s.data(); try { Object.assign(S, JSON.parse(d.state)); lastLive = d.state; _save(); render(); } catch (e) { } } }); };
  const ms = document.getElementById('mesel'); if (ms) ms.onchange = () => { ME = ms.value; try { localStorage.setItem('draftTool.me', ME); } catch (e) { } if (ROOM) ROOM.presence({ name: ME || 'Anonyme', tab: TAB }); };
  if (ROOM) try { ROOM.presence({ name: ME || 'Anonyme', tab: TAB }); } catch (e) { }
}
