// ===== Données et index =====
const ROLES = ['top', 'jgl', 'mid', 'adc', 'sup'];
const RL = { top: 'Top', jgl: 'Jungle', mid: 'Mid', adc: 'ADC', sup: 'Support' };
const CH = DATA.champs;
const BY = {};
CH.forEach(c => { BY[c.id] = c; c.tot = Object.values(c.r).reduce((s, a) => s + a[1], 0); });
const MU = {};
CH.forEach(c => {
  MU[c.id] = {};
  for (const r in c.m) { const o = {}; c.m[r].forEach(([e, ow, g]) => { o[e] = [ow, g]; }); MU[c.id][r] = o; }
});
const T = DATA.T;
const icon = c => c.i ? `data:image/webp;base64,${c.i}` : '';
const pct = x => (100 * x).toFixed(1).replace('.', ',') + ' %';
const pts = x => (x >= 0 ? '+' : '') + x.toFixed(1).replace('.', ',');

function share(c, r) { const x = c.r[r]; return x && c.tot ? x[1] / c.tot : 0; }
function games(c, r) { const x = c.r[r]; return x ? x[1] : 0; }
// WR Master+ (u.gg) lissé : c'est le prior, tel que le modèle l'a vu à l'entraînement (sans correction apprise)
function bwr0(c, r) { const x = c.r[r]; return x ? (x[0] + 150) / (x[1] + 300) : 0.47; }
// correction apprise par champion et rôle (MODEL.ch, en points), comptée À PART dans les scores (jamais dans le calcul attendu des duels)
function chPts(c, r) { return typeof MODEL !== 'undefined' ? MODEL.ch[c.id + '|' + r] || 0 : 0; }
// WR affiché : prior + correction
function bwr(c, r) { return bwr0(c, r) + chPts(c, r) / 100; }
function pr(c, r) { return games(c, r) / T; }
function banRate(c) { return c.b / T; }
function proPres(c) { return (c.p[0] + c.p[1]) / DATA.proGames; }
// Présence pro par rôle (EWC + Mondiaux) : picks dans ce rôle, bans répartis selon les rôles où il est joué
function proRole(c, r) {
  const G = DATA.proGames, p = c.p, rp = (p[3] && p[3][r]) || 0;
  const frac = p[0] > 0 ? rp / p[0] : share(c, r);
  return { pick: rp / G, ban: p[1] * frac / G, pres: Math.min(1, (rp + p[1] * frac) / G), wr: (p[2] + 5) / (p[0] + 10), n: rp };
}
// Mode unique : le modèle vise le jeu pro (recalé sur les parties pros 2026) en s'appuyant sur les données Master+.
// Plus de bascule pro / solo queue ; seul le format de la partie (flex ou tournoi) change l'ordre de draft et l'effet de côté.
const proRef = () => true;
const PROW = () => proRef() ? 1.0 : 0.6;
const SQW = () => proRef() ? 0.9 : 1;
// Points de priorité pro : présence (pick + ban) dans ce rôle, plus un peu de winrate pro s'il est assez joué
function proPrio(c, r) { const x = proRole(c, r); return 6 * x.pres + (x.n >= 4 ? (x.wr - 0.5) * 100 * 0.15 : 0); }
function proTxt(c, r) { const x = proRole(c, r); return x.pres >= 0.05 ? `pro ${RL[r]} : ${pct(x.pick)} de pick, ${pct(x.ban)} de ban` : ''; }
function viableP(c, r) { return viable(c, r) || proRole(c, r).pick >= 0.04; }
function viable(c, r) { return games(c, r) >= 400 && share(c, r) >= 0.08; }
function mainRole(c) { let best = null, g = -1; for (const r of ROLES) if (games(c, r) > g) { g = games(c, r); best = r; } return best; }

// Winrate de c contre e dans le rôle r (lissé)
function wrVs(c, e, r) {
  let wins = 0, g = 0, n = 0;
  const a = MU[c.id]?.[r]?.[e.id];
  if (a) { wins += a[1] - a[0]; g += a[1]; n++; }
  const b = MU[e.id]?.[r]?.[c.id];
  if (b) { wins += b[0]; g += b[1]; n++; }
  if (n) { wins /= n; g /= n; }
  const prior = Math.min(0.62, Math.max(0.38, bwr0(c, r) - bwr0(e, r) + 0.5));
  const k = 100;
  return { wr: (wins + k * prior) / (g + k), g: Math.round(g) };
}

// Puissance méta d'un champion dans un rôle, en points de winrate
function power(c, r, tourn) {
  let p = (bwr(c, r) - 0.5) * 100 * (tourn ? 0.6 : 1) + 1.0 * Math.log10(1 + 100 * (pr(c, r) + banRate(c) * share(c, r)));
  p += 0.7 * (tourn ? 1.8 : 0.6) * proPrio(c, r);
  return p;
}

// ===== État =====
const LS = 'draftTool.v1';
let S = {
  team: ROLES.map(r => ({ role: r, name: r === 'mid' ? 'Axel' : '', pool: [] })),
  mode: 'flex', side: 'B', fearless: false, series: { game: 1, locked: [] },
  draft: null
};
(function initPool() {
  const syn = CH.find(c => c.k === 'Syndra'), hw = CH.find(c => c.k === 'Hwei');
  S.team[2].pool = [syn, hw].filter(Boolean).map(c => c.id);
})();
try { const s = JSON.parse(localStorage.getItem(LS)); if (s && s.team) S = Object.assign(S, s); } catch (e) {}
function save() { try { localStorage.setItem(LS, JSON.stringify(S)); } catch (e) {} }

// ===== Séquences de draft =====
function sequence(mode) {
  if (mode === 'flex') {
    const s = [];
    const other = S.side === 'B' ? 'R' : 'B';
    for (let i = 0; i < 5; i++) s.push({ t: 'ban', s: S.side, ph: 'Bans (simultanés)' });
    for (let i = 0; i < 5; i++) s.push({ t: 'ban', s: other, ph: 'Bans (simultanés)' });
    'BRRBBRRBBR'.split('').forEach(x => s.push({ t: 'pick', s: x, ph: 'Picks' }));
    return s;
  }
  const s = [];
  'BRBRBR'.split('').forEach(x => s.push({ t: 'ban', s: x, ph: 'Bans phase 1' }));
  'BRRBBR'.split('').forEach(x => s.push({ t: 'pick', s: x, ph: 'Picks phase 1' }));
  'RBRB'.split('').forEach(x => s.push({ t: 'ban', s: x, ph: 'Bans phase 2' }));
  'RBBR'.split('').forEach(x => s.push({ t: 'pick', s: x, ph: 'Picks phase 2' }));
  return s;
}
function newDraft() { S.draft = { seq: sequence(S.mode), fill: [], roles: {} }; save(); }
if (!S.draft || !S.draft.seq) newDraft();

const D = () => S.draft;
const ours = st => st.s === S.side;
function curStep() { return D().seq[D().fill.length]; }
function used() { return new Set(D().fill.filter(x => x != null)); }
function locked() { return new Set(S.fearless && S.mode === 'tourn' ? S.series.locked : []); }
function available(c) { return !used().has(c.id) && !locked().has(c.id); }
function picksOf(side) {
  const out = [];
  D().seq.forEach((st, i) => { if (st.t === 'pick' && st.s === side && D().fill[i] != null) out.push({ i, c: BY[D().fill[i]] }); });
  return out;
}
function bansAll() { return D().seq.map((st, i) => st.t === 'ban' ? D().fill[i] : null).filter(x => x != null); }

// Rôles de notre équipe : manuels (choisis au pick)
function ourRoles() {
  const m = {};
  picksOf(S.side).forEach(p => { const r = D().roles[p.i]; if (r) m[r] = p.c; });
  return m;
}
// Rôles adverses : déduits (meilleure affectation), surchargeables
function enemyRoles() {
  const side = S.side === 'B' ? 'R' : 'B';
  const ps = picksOf(side);
  const fixed = {}, free = [];
  ps.forEach(p => { const r = D().roles[p.i]; if (r) fixed[r] = p; else free.push(p); });
  const open = ROLES.filter(r => !fixed[r]);
  let best = null, bestV = -1;
  function rec(k, usedR, v, asg) {
    if (k === free.length) { if (v > bestV) { bestV = v; best = asg.slice(); } return; }
    for (const r of open) if (!usedR.has(r)) {
      usedR.add(r); asg.push(r);
      rec(k + 1, usedR, v * (share(free[k].c, r) + 0.002), asg);
      usedR.delete(r); asg.pop();
    }
  }
  rec(0, new Set(), 1, []);
  const m = {}, idx = {};
  for (const r in fixed) { m[r] = fixed[r].c; idx[fixed[r].i] = r; }
  free.forEach((p, k) => { const r = best ? best[k] : mainRole(p.c); m[r] = p.c; idx[p.i] = r; });
  return { m, idx };
}

function playerOf(r) { return S.team.find(p => p.role === r); }
function poolRank(r, c) { const p = playerOf(r); return p ? p.pool.indexOf(c.id) : -1; }
function inAnyPool(c) { return S.team.some(p => p.pool.includes(c.id)); }

// ===== Moteur de recommandation =====
const tourn = () => S.mode === 'tourn';

// Candidats adverses probables dans un rôle
function enemyCands(r, exclude) {
  return CH.filter(c => available(c) && !(exclude && exclude.has(c.id)) && viable(c, r) && pr(c, r) >= 0.004)
    .sort((a, b) => pr(b, r) - pr(a, r)).slice(0, 30);
}
// Sécurité en blind : winrate attendu contre les picks probables et contre les pires counters dispos
function blindRisk(c, r) {
  const ec = enemyCands(r, new Set([c.id]));
  if (!ec.length) return { exp: bwr(c, r), worst: bwr(c, r), counters: [] };
  let sw = 0, sx = 0; const all = [];
  ec.forEach(e => { const w = pr(e, r); const v = wrVs(c, e, r); sw += w; sx += w * v.wr; all.push({ e, ...v }); });
  const common = all.slice(0, 15).sort((a, b) => a.wr - b.wr);
  const w3 = common.slice(0, 3);
  return { exp: sx / sw, worst: w3.reduce((s, x) => s + x.wr, 0) / w3.length, counters: w3 };
}

function compBalance(extra) {
  const cs = Object.values(ourRoles()); if (extra) cs.push(extra);
  const n = { AD: 0, AP: 0, T: 0 }; cs.forEach(c => n[c.d]++); return n;
}

// Score d'un candidat pour notre rôle r : winrate final simulé (sim), gain attendu instantané en attendant (inst)
function evalPick(c, r) {
  const er = enemyRoles().m;
  const opp = er[r];
  let lane, why = [], risk = null;
  if (opp) {
    const v = wrVs(c, opp, r); lane = v.wr;
    why.push(`${pct(v.wr)} contre ${opp.n}${v.g ? ` (${v.g} parties)` : ' (estimé)'}`);
  } else {
    risk = blindRisk(c, r);
    lane = risk.exp;
    why.push(`blind : ${pct(risk.exp)} en moyenne, ${pct(risk.worst)} contre ses pires counters (${risk.counters.map(x => x.e.n).join(', ')})`);
  }
  const pk = poolRank(r, c), cf = comfortOf(r, c);
  if (cf != null && (cf >= 8 || cf <= 3)) why.push(`aisance ${cf}/10`);
  // explications : compo entière (mesuré), ajustements appris, pros
  const fit = ctxFit(c, r, ourRoles(), er);
  why.push(...fit.why);
  if (typeof MODEL !== 'undefined') {
    const mine = ourRoles(); let ml = opp ? mlLane(c, opp, r) : 0;
    for (const rb in mine) if (rb !== r) ml += mlAlly(c, r, mine[rb], rb);
    if (Math.abs(ml) >= 0.5) why.push(`${fmtp(ml)} sur nos parties Master+`);
  }
  if (proTxt(c, r)) why.push(proTxt(c, r));
  { const pdt = pdTxt(c, r); if (pdt) why.push(pdt); }
  const inst = addGain(c, r, ourRoles(), er);
  const sv = simGet({ us: [c, r] });
  return { c, r, score: inst, inst, sim: sv ? sv.v : null, lane, meta: 0, pk, why, risk, opp, fit, shp: { v: 0, items: [] } };
}

function pickRecs() {
  const mine = ourRoles();
  const open = ROLES.filter(r => !mine[r]);
  const er = enemyRoles().m;
  const out = [];
  open.forEach(r => {
    const p = playerOf(r);
    const pool = p.pool.map(id => BY[id]).filter(c => c && available(c));
    const poolEv = pool.map(c => evalPick(c, r));
    // hors pool : les champions les plus joués à ce rôle (l'aisance à 0 est comptée dans leur valeur)
    // (seulement des champions dont c'est le rôle principal : pas de Karthus ADC hors pool)
    const off = simField()[r].slice(0, 8).map(o => o.c).filter(c => available(c) && !p.pool.includes(c.id) && mainRole(c) === r).map(c => evalPick(c, r));
    out.push({ r, player: p, poolEv, offAll: off, enemyKnown: !!er[r], empty: !pool.length });
  });
  const ready = simUse(out.flatMap(g => g.poolEv.concat(g.offAll)));
  out.forEach(g => {
    g.poolEv.sort((a, b) => b.score - a.score); g.offAll.sort((a, b) => b.score - a.score);
    const bestPool = g.poolEv[0];
    g.offShow = g.offAll.slice(0, 3);
    // ordre des rôles : celui dont le meilleur pick vaut le plus maintenant passe d'abord
    g.prio = bestPool ? bestPool.score : (g.offAll[0] ? g.offAll[0].score : -99);
    g.ready = ready;
  });
  out.sort((a, b) => b.prio - a.prio);
  return out;
}

// Bans : menace d'un champion pour notre équipe
function banRecs() {
  const mine = ourRoles();
  const er = enemyRoles().m;
  const st = curStep();
  const redFirst = S.side === 'R'; // l'adversaire a le first pick
  const wMeta = redFirst ? 1.3 : 1.0, wCnt = redFirst ? 0.8 : 1.2;
  const res = [];
  CH.forEach(x => {
    if (!available(x)) return;
    if (inAnyPool(x)) return;
    let best = null;
    ROLES.forEach(r => {
      if (er[r]) return; // rôle déjà pris en face
      if (!viable(x, r)) return;
      const sh = share(x, r);
      const meta = power(x, r, proRef());
      let cnt = 0, cntWhy = '';
      if (mine[r]) {
        const v = wrVs(mine[r], x, r);
        cnt = Math.max(0, (0.5 - v.wr) * 100) * 2;
        if (cnt > 0.5) cntWhy = `counter ${mine[r].n} (${pct(1 - v.wr)} pour lui)`;
      } else {
        const p = playerOf(r);
        const pool = p.pool.map(id => BY[id]).filter(c => c && available(c)).slice(0, 4);
        if (pool.length) {
          const vs = pool.map(c => ({ c, v: wrVs(c, x, r) })).sort((a, b) => b.v.wr - a.v.wr);
          const bestWr = vs[0].v.wr;
          cnt = Math.max(0, (0.5 - bestWr) * 100) * 1.5;
          if (cnt > 0.5) cntWhy = `bat le pool ${RL[r]} (${vs.slice(0, 2).map(o => `${o.c.n} ${pct(o.v.wr)}`).join(', ')})`;
        }
      }
      const lik = Math.pow(Math.min(1, (pr(x, r) + banRate(x) * sh) / 0.06), 0.75);
      const sc = (wMeta * meta + wCnt * cnt) * (0.4 + 0.6 * sh) * lik;
      if (!best || sc > best.sc) best = { sc, r, meta, cnt, cntWhy };
    });
    if (best) res.push({ c: x, ...best });
  });
  res.sort((a, b) => b.sc - a.sc);
  // Diversifier les rôles : chaque ban de plus dans le même rôle compte un peu moins
  const cnt = {}; res.forEach(o => { o.sc *= Math.pow(0.85, cnt[o.r] || 0); cnt[o.r] = (cnt[o.r] || 0) + 1; });
  res.sort((a, b) => b.sc - a.sc);
  return res.slice(0, 10).map(o => {
    const why = [];
    why.push(`${RL[o.r]} : ${pct(bwr(o.c, o.r))} de WR, ${pct(pr(o.c, o.r))} de pick, ${pct(banRate(o.c))} de ban`);
    if (proTxt(o.c, o.r)) why.push(proTxt(o.c, o.r));
    if (o.cntWhy) why.push(o.cntWhy);
    return { ...o, why };
  });
}

function enemyPickRecs() {
  const er = enemyRoles().m; const mine = ourRoles();
  const res = [];
  // position (1-10) du prochain pick adverse dans la draft
  const d = D(); let k = 0, slotNext = 5.5;
  if (d) for (let i = 0; i < d.seq.length; i++) { if (d.seq[i].t !== 'pick') continue; k++; if (i >= d.fill.length && !ours(d.seq[i])) { slotNext = k; break; } }
  ROLES.filter(r => !er[r]).forEach(r => {
    CH.filter(c => available(c) && viableP(c, r)).forEach(c => {
      const pro = proRole(c, r);
      let sc = power(c, r, proRef()) * (0.4 + 0.6 * Math.max(share(c, r), pro.pick > 0 ? 0.8 : 0)) * Math.sqrt(Math.min(1, (pr(c, r) + banRate(c) * share(c, r) + PROW() * 0.5 * pro.pres) / 0.05));
      let why = `${RL[r]} : ${pct(bwr(c, r))} de WR, ${pct(pr(c, r))} de pick`;
      if (pro.pres >= 0.05) why += `, ${proTxt(c, r)}`;
      // un champion que les pros prennent tôt est attendu sur les premiers picks, un champion de counter sur les derniers
      { const p = pdPick(c, r); if (p) sc += (proRef() ? 1 : 0.4) * p.conf * Math.max(0, 3 - Math.abs(proSlot(c, r) - slotNext)) * 0.6; }
      if (mine[r]) { const v = wrVs(c, mine[r], r); sc += Math.max(0, (v.wr - 0.5) * 100) * 1.5; if (v.wr > 0.51) why += `, ${pct(v.wr)} contre ${mine[r].n}`; }
      if (Object.keys(mine).length || Object.keys(er).length) { const f = ctxFit(c, r, er, mine); sc += Math.max(0, f.v); if (f.v > 0.8 && f.items[0].x > 0) why += `, ${fmtp(f.items[0].x)} ${f.items[0].txt}`; }
      res.push({ c, r, sc, why });
    });
  });
  const seen = new Set();
  return res.sort((a, b) => b.sc - a.sc).filter(o => !seen.has(o.c.id) && seen.add(o.c.id)).slice(0, 8);
}
