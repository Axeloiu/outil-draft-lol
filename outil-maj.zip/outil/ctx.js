// ===== Contexte de compo mesuré sur les stats (LoLalytics, Master+, 30 derniers jours) =====
// effet(A contre/avec B) = profil de A x style de B (interactions estimées sur ~985 000 parties) + écart propre à la paire (rétréci vers 0 selon le nombre de parties)
const LLANE = { top: 'top', jgl: 'jungle', mid: 'middle', adc: 'bottom', sup: 'support' };
const LIDX = { top: 0, jungle: 1, middle: 2, bottom: 3, support: 4 };
const isCarry = c => c.d !== 'T' && tv(c, 'f') <= 1;
const FAF = {
  carry_imm: c => isCarry(c) && tv(c, 'm') === 0, carry_mob: c => isCarry(c) && tv(c, 'm') >= 2, dive: c => tv(c, 'd') >= 3,
  pick: c => tv(c, 'k') >= 2, antitank: c => tv(c, 'a') >= 2, front: c => tv(c, 'f') >= 2, engage: c => tv(c, 'e') >= 2,
  peel: c => tv(c, 'p') >= 2, poke: c => tv(c, 'o') >= 2, AD: c => c.d === 'AD', AP: c => c.d === 'AP',
  early: c => tv(c, 'c') === 0, late: c => tv(c, 'c') === 2, melee: c => tv(c, 'g') === 0, hyper: c => tv(c, 'h') >= 1
};
const FBF = {
  dive: c => tv(c, 'd') >= 3, engage: c => tv(c, 'e') >= 2, poke: c => tv(c, 'o') >= 2, front: c => tv(c, 'f') >= 2,
  peel: c => tv(c, 'p') >= 2, AP: c => c.d === 'AP', AD: c => c.d === 'AD', early: c => tv(c, 'c') === 0,
  late: c => tv(c, 'c') === 2, carry_imm: c => isCarry(c) && tv(c, 'm') === 0, melee: c => tv(c, 'g') === 0, antitank: c => tv(c, 'a') >= 2
};
const FAL = { carry_imm: 'carry immobile', carry_mob: 'carry mobile', dive: 'champion de dive', pick: 'champion de pick', antitank: 'anti-tank', front: 'frontline', engage: 'engage', peel: 'peel', poke: 'poke', AD: 'AD', AP: 'AP', early: 'early', late: 'late game', melee: 'mêlée', hyper: 'hypercarry' };
const FBL = { dive: 'dive / burst', engage: 'engage', poke: 'poke', front: 'frontline', peel: 'peel', AP: 'AP', AD: 'AD', early: 'early', late: 'late game', carry_imm: 'carry immobile', melee: 'mêlée', antitank: 'anti-tank' };
const PAIRS = { E: {}, A: {} };
['E', 'A'].forEach(s => { for (const k in CTX[s].pair) CTX[s].pair[k].forEach(([b, li, v]) => { PAIRS[s][`${k}|${b}|${li}`] = v; }); });
const LNAMES = ['top', 'jungle', 'middle', 'bottom', 'support'];
function pairVal(s, a, la, b, lb) {
  const x = PAIRS[s][`${a.id}|${la}|${b.id}|${LIDX[lb]}`], y = PAIRS[s][`${b.id}|${lb}|${a.id}|${LIDX[la]}`];
  const sg = s === 'E' ? -1 : 1;
  if (x != null && y != null) return (x + sg * y) / 2;
  if (x != null) return x / 2;
  if (y != null) return sg * y / 2;
  return 0;
}
// Terme de style : somme des interactions profil(A) x style(B), avec le terme le plus fort pour l'explication
function styleVal(s, a, b) {
  const M = CTX[s], fa = CTX.fa, fb = CTX.fb;
  let v = 0, best = null;
  for (let i = 0; i < fa.length; i++) {
    if (!FAF[fa[i]](a)) continue;
    const row = M.B[i];
    for (let j = 0; j < fb.length; j++) {
      if (!row[j]) continue;
      const x = row[j] * ((FBF[fb[j]](b) ? 1 : 0) - M.p[j]);
      v += x;
      if (FBF[fb[j]](b) && (!best || Math.abs(x) > Math.abs(best[0]))) best = [x, fa[i], fb[j]];
    }
  }
  return { v, best };
}
const fmtp = x => (x >= 0 ? '+' : '−') + Math.abs(x).toFixed(1).replace('.', ',');
// Effet de toute la compo sur un champion c joué au rôle r. allyM / enemyM : { rôle: champion }
function ctxFit(c, r, allyM, enemyM) {
  const la = LLANE[r];
  const items = [];
  let v = 0;
  for (const rb in (enemyM || {})) {
    const b = enemyM[rb]; if (!b || rb === r) continue; // le duel de lane est compté à part
    const st = styleVal('E', c, b), pv = pairVal('E', c, la, b, LLANE[rb]);
    const x = st.v + pv; v += x;
    let why = '';
    if (Math.abs(pv) >= Math.abs(st.v) && Math.abs(pv) >= 0.3) why = 'mesuré sur leurs parties';
    else if (st.best && Math.abs(st.best[0]) >= 0.1) why = `${FAL[st.best[1]]} contre ${FBL[st.best[2]]}`;
    items.push({ x, txt: `contre ${b.n}${why ? ' (' + why + ')' : ''}` });
  }
  for (const rb in (allyM || {})) {
    const b = allyM[rb]; if (!b || rb === r || b.id === c.id) continue;
    const st = styleVal('A', c, b), pv = pairVal('A', c, la, b, LLANE[rb]);
    const x = st.v + pv; v += x;
    let why = '';
    if (Math.abs(pv) >= Math.abs(st.v) && Math.abs(pv) >= 0.3) why = ({ adc: 1, sup: 1 }[r] && { adc: 1, sup: 1 }[rb]) ? 'duo bot mesuré' : 'mesuré sur leurs parties';
    else if (st.best && Math.abs(st.best[0]) >= 0.1) why = st.best[1] === st.best[2] ? `encore un ${FAL[st.best[1]]}` : `${FAL[st.best[1]]} avec ${FBL[st.best[2]]}`;
    items.push({ x, txt: `avec ${b.n}${why ? ' (' + why + ')' : ''}` });
  }
  items.sort((a, b) => Math.abs(b.x) - Math.abs(a.x));
  return { v, items, why: items.filter(i => Math.abs(i.x) >= 0.25).slice(0, 3).map(i => `${fmtp(i.x)} ${i.txt}`) };
}
// Synergie interne d'une compo (5 rôles), moyenne des deux points de vue de chaque paire
function synergyData(cs) {
  const m = {}; ROLES.forEach((r, i) => { if (cs[i]) m[r] = cs[i]; });
  let v = 0;
  ROLES.forEach((r, i) => { if (cs[i]) v += ctxFit(cs[i], r, m, {}).v; });
  return v / 2;
}

// ===== Modèle appris sur nos parties (Master+ EUW et KR, collecteur Riot) =====
// Corrections en points de winrate, par-dessus les chiffres u.gg / LoLalytics : duels, paires d'alliés, profil de compo.
const ML_LET = 'epkodfswchmguaxyt';
function mlTr(c) { const t = {}; (c.tr || []).forEach((v, i) => t[ML_LET[i]] = v); return t; }
function mlProf(c) {
  const t = mlTr(c), d = c.d, carry = d !== 'T' && t.f <= 1;
  const P = { AD: d === 'AD', AP: d === 'AP', tank: d === 'T', engage: t.e >= 2, peel: t.p >= 2, poke: t.o >= 2, dive: t.d >= 3, front: t.f >= 2, pick: t.k >= 2, antitank: t.a >= 2, early: t.c === 0, late: t.c === 2, melee: t.g === 0, carry_imm: carry && t.m === 0, hyper: t.h >= 1, mobile: t.m >= 2 };
  return MODEL.pk.map(k => P[k] ? 1 : 0);
}
function mlVec(M) { const v = MODEL.pk.map(() => 0); ROLES.forEach(r => { if (M[r]) mlProf(M[r]).forEach((x, i) => v[i] += x); }); return v; }
// duel de lane : points pour c (rôle r) face à e
// tables apprises souvent vides : test rapide avant de construire les clés
function mlHas(t) { const k = '_n_' + t; if (MODEL[k] == null) MODEL[k] = Object.keys(MODEL[t] || {}).length; return MODEL[k] > 0; }
function mlLane(c, e, r) { if (!c || !e || !mlHas('du')) return 0; return c.id < e.id ? (MODEL.du[`${c.id}|${e.id}|${r}`] || 0) : -(MODEL.du[`${e.id}|${c.id}|${r}`] || 0); }
// paire d'alliés (rôles dans l'ordre top, jgl, mid, adc, sup)
function mlAlly(a, ra, b, rb) { if (!a || !b || !mlHas('al')) return 0; return ROLES.indexOf(ra) < ROLES.indexOf(rb) ? (MODEL.al[`${a.id}|${ra}|${b.id}|${rb}`] || 0) : (MODEL.al[`${b.id}|${rb}|${a.id}|${ra}`] || 0); }
function mlAllies(M) { let v = 0; for (let i = 0; i < 5; i++) for (let j = i + 1; j < 5; j++) v += mlAlly(M[ROLES[i]], ROLES[i], M[ROLES[j]], ROLES[j]); return v; }
// profil de compo : écarts, combinaisons internes, face à face (mêmes termes que le modèle)
function mlComp(A, B) {
  if (MODEL._cz == null) MODEL._cz = !(MODEL.comp || []).some(x => x); if (MODEL._cz) return 0;
  const a = mlVec(A), b = mlVec(B), n = a.length, f = [];
  for (let i = 0; i < n; i++) f.push(a[i] - b[i]);
  for (let i = 0; i < n; i++) for (let j = i; j < n; j++) f.push(a[i] * a[j] - b[i] * b[j]);
  for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) if (i !== j) f.push(a[i] * b[j] - b[i] * a[j]);
  return f.reduce((s, x, k) => s + x * MODEL.comp[k], 0);
}

// ===== Score de fin de draft : winrate estimé à partir des stats =====
// Modèle Master+ (priors u.gg / LoLalytics recalés sur des parties postérieures aux priors) en points de winrate :
// force des champions + duels au-delà des forces + synergies internes + compo contre compo.
// Ce modèle compte × wMt(), plus le WR pro des champions × wMp() : calage mesuré sur les parties Master+ (voir wMt).
// parties pros 2026, niveau des équipes contrôlé par un Elo). Le côté dépend du format de la partie.
// Côté bleu, en points : en tournoi, mesuré sur les pros ; en flex, mesuré sur nos parties Master+ flex.
// WR pro 2026 d'un champion, lissé vers 50 % (K parties fictives, choisi par validation chronologique), en points
// Règles choisies par Axel (écrites à la main, non mesurées) : le WR pro d'Aurelion Sol ne compte pas, et un WR pro lissé sous
// 50 % compte comme 50 % (un pick ne perd rien à être moins gagnant chez les pros ; seul l'écart au-dessus de 50 % compte).
const PRO_WR_SKIP = new Set([136]);
const PWC = new Map();
function proWrPts(c) { let v = PWC.get(c.id); if (v == null) { v = proWrRaw(c); PWC.set(c.id, v); } return v; }
function proWrRaw(c) { if (PRO_WR_SKIP.has(c.id)) return 0; const x = PRO26.wr[c.id]; const n = x ? x[0] : 0, w = x ? x[1] : 0; return Math.max(0, ((w + PRO26.K / 2) / (n + PRO26.K) - 0.5) * 100); }
// Présence pro d'un pick, en points : mesurée sur nos 21 695 parties flex Master+ (analyses/modele/test_hors_meta_flex.py),
// à composantes solo queue égales, +0,15 point par unité de log(1 + parties pros 2026 à ce rôle), IC95 +0,06 à +0,24
// (en solo/duo +0,03, IC95 −0,02 à +0,07 : rien). Appliquée en flex et en tournoi (équipes de 5). Centrée par rôle sur le
// pick moyen des parties Master+, pour que les compos partielles ne gagnent rien au simple nombre de picks.
const PRES_X = 1, PRES_K = 0.15, PRES_C = {};
function presRaw(c, r) { return Math.log1p((PRO26.freq[r] || {})[c.id] || 0); }
const PRESC = new Map();
function presPts(c, r) {
  const k = c.id * 5 + ROLES.indexOf(r); const cv = PRESC.get(k); if (cv != null) return cv;
  if (PRES_C[r] == null) { let s = 0, w = 0; CH.forEach(x => { const g = x.r[r] ? x.r[r][1] : 0; if (g) { s += g * presRaw(x, r); w += g; } }); PRES_C[r] = w ? s / w : 0; }
  const v = PRES_X * PRES_K * (presRaw(c, r) - PRES_C[r]); PRESC.set(k, v); return v;
}
// Côté : retiré du score à la demande d'Axel (en flex le côté est imposé, et l'effet ne change aucun classement de picks).
// Mesures pour mémoire : +2,85 points pour le bleu chez les pros (PRO26.side), MODEL.side + MODEL.flex en flex Master+.
function sideBlue() { return 0; }
// Poids du modèle, en flex comme en tournoi : calage sur les parties pros 2026 (PRO26.mt ≈ 0,43 pour les composantes solo
// queue, PRO26.mp ≈ 0,56 pour le WR pro des champions), choix d'Axel. Mesure pour mémoire (analyses/modele/test_wr_pro_flex.py,
// 132 860 parties Master+ dont 21 695 en flex) : sur nos parties, le WR pro ne prédit rien (+0,03 point par point, IC95 −0,00
// à +0,07 ; −0,11 en flex) et le calage Master+ seul (× 1 et × 0) prédit mieux. Les données pros servent aussi à l'ordre de
// draft, au filtre « joué en pro », au comportement de pick et de ban de l'adversaire et à l'effet de côté en tournoi.
const FLEX_W = { mt: PRO26.mt, mp: PRO26.mp };
function wMt() { return FLEX_W.mt; }
function wMp() { return FLEX_W.mp; }
function sideLabel() { return S.mode === 'tourn' ? 'mesuré sur les parties pros 2026' : 'mesuré sur les parties flex Master+'; }
// écart de duel au-delà des forces (prior seul), rétréci selon le nombre de parties : variance réelle des duels ≈ 3 points²
function laneRes(a, b, r) {
  const v = wrVs(a, b, r), exp = 0.5 + (bwr0(a, r) - selBias(a, r) - 0.5) - (bwr0(b, r) - selBias(b, r) - 0.5);
  const prior = Math.min(0.62, Math.max(0.38, exp)), raw = v.g ? (v.wr * (v.g + 100) - 100 * prior) / v.g : exp;
  return { res: v.g ? (raw - exp) * 100 * 3 / (3 + 2500 / v.g) : 0, wr: v.wr, g: v.g };
}
function draftScore(ourM, enM) {
  const side = (M, O) => {
    let champs = 0, ch = 0; const det = [];
    ROLES.forEach(r => { const c = M[r]; if (!c) return; const d = (bwr0(c, r) - selBias(c, r) - 0.5) * 100; champs += d; ch += chPts(c, r); det.push([r, c, d]); });
    let ctx = 0; ROLES.forEach(r => { if (M[r]) ctx += ctxFit(M[r], r, {}, O).v; });
    const syn = synergyData(ROLES.map(r => M[r]));
    return { champs, ch, det, ctx, syn };
  };
  const A = side(ourM, enM), B = side(enM, ourM);
  let lanes = 0; const lane = [];
  ROLES.forEach(r => {
    const a = ourM[r], b = enM[r]; if (!a || !b) return;
    const x = laneRes(a, b, r);
    lanes += x.res; lane.push([r, a, b, x.wr, x.res, x.g]);
  });
  // [libellé, écart, nous, eux] : nous/eux seulement pour ce qui appartient à une compo seule
  const K = MODEL.mult, mt = wMt();
  const parts = [
    ['Force des champions (WR Master+ à leur rôle)', (A.champs - B.champs) * K[0], A.champs * K[0], B.champs * K[0]],
    ['Synergies internes (mesurées)', (A.syn - B.syn) * K[1], A.syn * K[1], B.syn * K[1]],
    ['Duels de lane (au-delà de la force des champions)', lanes * K[2], null, null],
    ['Compo contre compo (paires hors lane, mesurées)', (A.ctx - B.ctx) / 2 * K[3], null, null]
  ];
  // corrections apprises (vides tant qu'elles n'apportent rien de mesurable sur des parties propres)
  let ml = A.ch - B.ch; ROLES.forEach(r => ml += mlLane(ourM[r], enM[r], r));
  ml += mlAllies(ourM) - mlAllies(enM) + mlComp(ourM, enM);
  if (Math.abs(ml) > 1e-9) parts.push([`Ajustements appris (${Math.round(MODEL.n / 1000)} k parties Master+)`, ml, null, null]);
  parts.forEach(p => { p[1] *= mt; if (p[2] != null) p[2] *= mt; if (p[3] != null) p[3] *= mt; });
  let pa = 0, pb = 0; ROLES.forEach(r => { if (ourM[r]) pa += proWrPts(ourM[r]); if (enM[r]) pb += proWrPts(enM[r]); });
  let qa = 0, qb = 0; ROLES.forEach(r => { if (ourM[r]) qa += presPts(ourM[r], r); if (enM[r]) qb += presPts(enM[r], r); });
  parts.push(['Présence pro des picks à leur rôle (mesurée en flex)', qa - qb, qa, qb]);
  if (wMp()) parts.push([`WR pro 2026 des champions (lissé, ${Math.round(PRO26.n / 100) / 10} k parties ; sous 50 % compté 50 %, Aurelion Sol exclu : choix d’Axel)`, (pa - pb) * wMp(), pa * wMp(), pb * wMp()]);
  const shA = draftShape(ROLES.map(r => ourM[r]), ROLES.map(r => enM[r])), shB = draftShape(ROLES.map(r => enM[r]), ROLES.map(r => ourM[r]));
  const total = parts.reduce((s, p) => s + p[1], 0);
  const wr = Math.max(20, Math.min(80, 50 + total));
  const scoreA = A.champs + A.syn, scoreB = B.champs + B.syn;
  return { wr, total, parts, lane, A, B, scoreA, scoreB, shA, shB };
}

// ===== Valeur en blind, valeur en counter-pick, fiabilité =====
// Biais de sélection mesuré sur LoLalytics : écart entre le WR observé et le WR qu'aurait le champion
// si ses adversaires (hors lane) et ses alliés étaient tirés comme dans la population.
function selBias(c, r) { const b = BIAS[c.id + '|' + r]; return b ? (b[1] + b[2]) / 100 : 0; }
const BV = {};
// Pick en aveugle : moyenne contre les adversaires de lane de la population, tirée vers ses pires counters courants
function blindVal(c, r) { const k = c.id + '|' + r; if (BV[k] == null) { const x = blindRisk(c, r); BV[k] = 0.6 * x.exp + 0.4 * x.worst - selBias(c, r); } return BV[k]; }
// Pick en counter : le champion est choisi quand le duel lui convient, comme dans ses parties habituelles
function counterVal(c, r) { return bwr(c, r) - selBias(c, r); }
// Hors pool : un champion peu joué a un winrate porté par ses spécialistes
function reliab(c, r) { const p = pr(c, r); return p / (p + 0.015); }
function powerBlind(c, r) { return (blindVal(c, r) - 0.5) * 100 * SQW() * reliab(c, r) + Math.log10(1 + 100 * (pr(c, r) + banRate(c) * share(c, r))) + 0.7 * PROW() * proPrio(c, r); }

// ===== Ordre de draft chez les pros (Leaguepedia 2026, ligues majeures et internationaux, réorienté bleu / rouge) =====
// c["Champion|rôle"] = [picks, victoires, somme des positions (1-10), first picks, picks en phase 1, picks 9-10, picks en counter (laner adverse déjà connu), victoires en counter]
// b["Champion"] = [bans, bans phase 1, bans phase 2, bans en tout premier (1 ou 2), bans par l'équipe qui drafte en premier]
function pdPick(c, r) {
  const x = PRODRAFT.c[c.n + '|' + r]; if (!x) return null;
  const [n, w, ss, fp, p1, last, cn, cw] = x;
  return { n, w, slot: ss / n, fp, p1: p1 / n, last: last / n, cnt: cn / n, cwr: cn ? cw / cn : null, conf: Math.min(1, n / 8) };
}
function pdBan(c) { const x = PRODRAFT.b[c.n]; if (!x) return null; const [n, b1, b2, s1] = x; return { n, b1, b2, s1, p1: b1 / n }; }
function roleSlot(r) { const x = PRODRAFT.rs[r]; return x[1] / x[0]; }
// Position de pick attendue chez les pros (rétrécie vers la moyenne du rôle s'il est peu joué)
function proSlot(c, r) { const p = pdPick(c, r), rs = roleSlot(r); return p ? (p.slot * p.n + rs * 4) / (p.n + 4) : rs; }
function pdTxt(c, r) {
  const p = pdPick(c, r); if (!p || p.n < 5) return '';
  const bits = [`pros : pick n\u00b0${proSlot(c, r).toFixed(1).replace('.', ',')} en moyenne`];
  if (p.fp >= 3) bits.push(`${p.fp} first picks`);
  if (p.last >= 0.3) bits.push(`gard\u00e9 pour la fin ${pct(p.last)}`);
  return bits.join(', ');
}
// Phase de bans en cours (tournoi) : 1 avant les premiers picks, 2 après
function banPhase() { const d = D(); if (!d || S.mode !== 'tourn') return 1; const i = d.fill.length; return i >= 12 ? 2 : 1; }

// ===== Forme des drafts pros (Leaguepedia 2026, ligues majeures et internationaux, réorienté bleu / rouge) : affichage seulement =====
// Chaque forme : [compos, victoires]. Effet = écart au 50 %, rétréci selon l’échantillon (k = 300) : en pro, les meilleures équipes tirent aussi ces chiffres.
function shapeEff(tab, key) { const v = PROSHAPE[tab][key]; if (!v || v[0] < 8) return null; const wr = v[1] / v[0]; return { n: v[0], wr, eff: (wr - 0.5) * 100 * v[0] / (v[0] + 300) }; }
const curveLab = c => c < 0.9 ? 'early' : c > 1.25 ? 'late' : 'mid';
const engB = e => e <= 3 ? '0-3' : e <= 5 ? '4-5' : e <= 7 ? '6-7' : '8+';
const CURVE_FR = { early: 'early', mid: 'mid game', late: 'late game' };
function draftShape(cs, ens) {
  cs = cs.filter(Boolean); ens = (ens || []).filter(Boolean);
  const items = [];
  if (cs.length < 5) return { v: 0, items };
  const t = traitsSum(cs), id = identity(t);
  const add = (tab, key, lab) => { const s = shapeEff(tab, key); if (s) items.push({ lab, ...s }); };
  add('dmg', `${t.AD}-${t.AP}`, `${t.AD} AD, ${t.AP} AP, ${t.T} tank${t.T > 1 ? 's' : ''}`);
  if (ens.length >= 3) {
    // compo adverse partielle : engage ramené à 5 champions
    const et = traitsSum(ens), eid = identity(et); et.e = et.e * 5 / ens.length;
    add('engdiff', et.e > t.e + 1 ? '-' : t.e > et.e + 1 ? '+' : '=', t.e > et.e + 1 ? 'plus d\u2019engage qu\u2019eux' : et.e > t.e + 1 ? 'moins d\u2019engage qu\u2019eux' : 'autant d\u2019engage qu\u2019eux');
    add('stylevs', `${id.main}|${eid.main}`, `${ARCH[id.main]} contre ${ARCH[eid.main]}`);
    add('curvevs', `${curveLab(t.c)}|${curveLab(et.c)}`, `compo ${CURVE_FR[curveLab(t.c)]} contre compo ${CURVE_FR[curveLab(et.c)]}`);
  } else {
    add('eng', engB(t.e), `engage total ${engB(t.e)}`);
    add('style', id.main, ARCH[id.main]);
  }
  const v = Math.max(-5, Math.min(5, items.reduce((s, i) => s + i.eff, 0)));
  return { v, items };
}
// Rôles pickés dans l'ordre par une équipe (pour comparer à la forme des drafts pros)
function roleOrder(mineSide) {
  const d = D(); if (!d) return [];
  const RL1 = { top: 'T', jgl: 'J', mid: 'M', adc: 'B', sup: 'S' };
  const out = [];
  const er = enemyRoles();
  d.fill.forEach((id, i) => { const st = d.seq[i]; if (st.t !== 'pick' || ours(st) !== mineSide) return;
    const r = mineSide ? d.roles[i] || (Object.entries(ourRoles()).find(([, c]) => c.id === id) || [])[0] : (Object.entries(er.m).find(([, c]) => c.id === id) || [])[0];
    if (r) out.push(RL1[r]); });
  return out;
}
const ROLE_FR1 = { T: 'top', J: 'jungle', M: 'mid', B: 'ADC', S: 'support' };

// ===== Forme de la draft au moment du pick =====
let IDC = { k: null, v: null };
function idealNow() {
  const d = D(); if (!d) return null;
  const k = [d.fill.join(','), JSON.stringify(d.roles), [...locked(), ...lockedUs()].join('.'), S.side, S.mode, S.target ? S.target.ids.join(',') : '', S.team.map(t => t.pool.join('.') + ':' + JSON.stringify(t.comf || {}) + ':' + (t.want || []).join('.')).join('|'), OPT.offPool, OPT.proOnly, S.target ? S.target.style : ''].join('#');
  if (IDC.k !== k) IDC = { k, v: bestComps(1, { target: true })[0] || null };
  return IDC.v;
}
// Ce que les pros gagnent avec ce pick, à ce moment de la draft : forme de la compo complétée (le reste = compo idéale),
// face aux picks adverses déjà connus, et forme de l'ordre de pick (rôle en blind ou en counter, first pick, phase 1, top en phase 2)
function pickShape(c, r) {
  const items = [], W = proRef() ? 0.6 : 0.3;
  const mine = ourRoles(), er = enemyRoles().m, ideal = idealNow();
  const proj = ROLES.map((x, i) => x === r ? c : (mine[x] || (ideal && ideal.cs[i] && ideal.cs[i].id !== c.id ? ideal.cs[i] : null)));
  const ens = ROLES.map(x => er[x]).filter(Boolean);
  if (proj.every(Boolean)) draftShape(proj, ens).items.forEach(i => items.push({ eff: i.eff, txt: `${i.lab} : ${pct(i.wr)} chez les pros (${i.n} compos)` }));
  const L = { top: 'T', jgl: 'J', mid: 'M', adc: 'B', sup: 'S' }[r];
  const mp = roleOrder(true), idx = mp.length, fd = S.side === 'B';
  const tab = { top: 'topc', jgl: 'jglc', mid: 'midc', adc: 'adcc', sup: 'supc' }[r];
  const bc = er[r] ? 'c' : 'b', s1 = shapeEff(tab, bc);
  if (s1) items.push({ eff: s1.eff, txt: `${ROLE_FR1[L]} pick\u00e9 en ${bc === 'c' ? 'counter' : 'blind'} : ${pct(s1.wr)} chez les pros` });
  if (fd === true && idx === 0) { const s = shapeEff('first', L); if (s) items.push({ eff: s.eff, txt: `first pick ${ROLE_FR1[L]} : ${pct(s.wr)} chez les pros (${s.n} games)` }); }
  if (fd === false && idx === 1) { const k = [mp[0], L].sort().join(''); const s = shapeEff('first2', k); if (s) items.push({ eff: s.eff, txt: `ouverture ${ROLE_FR1[mp[0]]} + ${ROLE_FR1[L]} : ${pct(s.wr)} chez les pros (${s.n})` }); }
  if (fd != null && idx === 2) { const k = [...mp, L].sort().join(''); const s = shapeEff('p1', k); if (s) items.push({ eff: s.eff, txt: `phase 1 ${[...mp, L].map(z => ROLE_FR1[z]).join(' + ')} : ${pct(s.wr)} chez les pros (${s.n})` }); }
  if (r === 'top' && fd != null) { const s = shapeEff('topp', idx < 3 ? 'p1' : 'p2'); if (s) items.push({ eff: s.eff, txt: `top pick\u00e9 en phase ${idx < 3 ? 1 : 2} : ${pct(s.wr)} chez les pros` }); }
  items.forEach(i => i.eff *= W);
  items.sort((a, b) => Math.abs(b.eff) - Math.abs(a.eff));
  return { v: items.reduce((s, i) => s + i.eff, 0), items };
}

// ===== Meilleurs picks maintenant : tous rôles ouverts confondus =====
// Ordre conseillé pour finir la compo idéale : chaque pick classé par le winrate final simulé s'il est pris maintenant
// (la simulation tient déjà compte des counters adverses mesurés et de ce qui reste à picker)
function idealOrder(ideal) {
  const mine = ourRoles();
  const l = ROLES.map((r, i) => ({ r, c: ideal.cs[i] })).filter(o => !mine[o.r] && o.c && available(o.c))
    .map(o => ({ ...o, now: evalPick(o.c, o.r).score })).sort((a, b) => b.now - a.now);
  // départage sur les simulations longues (le pick qu'on peut garder pour le counter passe naturellement en dernier)
  const st = curStep(); if (!st || st.t !== 'pick' || !ours(st) || l.length < 2) return l;
  const rf = refineOrder(l); rf.list.ready = rf.ready; return rf.list;
}
// note du pick dans le contexte (duel, compo adverse, méta pro, forme de draft) + urgence (risque de vol ou de ban, rôle que les pros prennent tôt)
function bestNow(ideal) {
  const mine = ourRoles(), er = enemyRoles().m, opts = roleOptions(ideal), out = [];
  ROLES.forEach(r => (opts[r] || []).forEach((o, k) => {
    out.push({ c: o.c, r, star: o.star, tag: o.tag, why: o.why, now: o.score, rank: k });
  }));
  const seen = new Set();
  const top = out.sort((a, b) => b.now - a.now).filter(o => !seen.has(o.c.id) && seen.add(o.c.id)).slice(0, 8);
  // les écarts entre ces picks sont souvent sous l'erreur des 200 tirages : on les départage sur les simulations longues
  return refineOrder(top).list;
}
