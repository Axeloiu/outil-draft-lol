import re, os
sh=open('shell.html').read()
sh=re.sub(r'\\u([0-9a-fA-F]{4})',lambda m:chr(int(m.group(1),16)),sh)
out=sh.replace('/*DATA*/',open('data.js').read()).replace('/*APP*/',open('app.js').read()).replace('/*COMP*/',open('comp.js').read()).replace('/*FIT*/',open('fit.js').read()).replace('/*CTX*/','const CTX='+open('data/ctx.json').read()+';\nconst PRODRAFT='+open('data/prodraft.json').read().strip()+';\nconst PROSHAPE='+open('data/proshape.json').read().strip()+';\nconst BIAS='+open('data/bias.json').read()+';\nconst MODEL='+open('data/model.json').read()+';\nconst PRO26='+open('data/pro2026.json').read()+';\nconst ITEMS='+(open('data/items.json').read() if os.path.exists('data/items.json') else 'null')+';\n'+open('ctx.js').read()+'\n'+open('sim.js').read()).replace('/*IG*/',open('ingame.js').read()+'\n'+open('postgame.js').read()).replace('/*UI*/',open('ui.js').read()+'\n'+open('auto.js').read())
open('index.html','w').write(out); print(len(out))
