// ===== Onglet « En jeu » : chronos des sorts d'invocateur adverses, à la voix ou au clavier =====
// Rien ne touche au jeu : micro (Web Speech API de Chrome) et saisie manuelle uniquement.

// --- Stockage partagé : Firebase (version GitHub) ou stockage de l'artefact Claude ---
async function getDB() {
  if (window.FBSTORE_PROMISE) { try { const s = await window.FBSTORE_PROMISE; if (s) return s; } catch (e) { } return null; }
  if (window.claude && window.claude.use) { try { return await window.claude.use('db'); } catch (e) { return null; } }
  return null;
}
async function getRoom() {
  if (window.FBSTORE_PROMISE) { try { const s = await window.FBSTORE_PROMISE; return s ? s.room : null; } catch (e) { return null; } }
  if (window.claude && window.claude.use) { try { return await window.claude.use('room'); } catch (e) { return null; } }
  return null;
}
// heure commune (Firebase corrige le décalage d'horloge entre ordinateurs)
const nowS = () => Date.now() + (window.SERVER_OFFSET || 0);

// --- Sorts : temps de recharge de base (patch 26.21-26.22) ---
const SPELLS = {
  flash: { n: 'Flash', cd: 300, w: ['flash', 'flache', 'flash', 'flesh', 'flech', 'flashe', 'flasch', 'flach', 'flashs'] },
  tp: { n: 'TP', cd: 300, w: ['tp', 'tepe', 'tep', 'teleport', 'teleporte', 'teleportation', 'tele', 'tpe', 'thp', 'tps', 'tepee', 'tipi', 'teper'] },
  ignite: { n: 'Ignite', cd: 180, w: ['ignite', 'ignit', 'ignait', 'ignaite', 'igni', 'ignites', 'embrasement', 'ign', 'ignaitte', 'ignaites', 'embraze', 'embrazement', 'embrase', 'embrasse', 'embras', 'embrazer', 'embraser', 'embrasements'] },
  heal: { n: 'Heal', cd: 240, w: ['heal', 'hil', 'hill', 'heel', 'heals', 'soin', 'soins', 'hills', 'hile', 'eal'] },
  barrier: { n: 'Barrière', cd: 180, w: ['barriere', 'barrier', 'bariere', 'barrieres'] },
  exhaust: { n: 'Exhaust', cd: 240, w: ['exhaust', 'exaust', 'exost', 'exhost', 'egzost', 'exhausted', 'epuisement', 'fatigue', 'exo', 'exau', 'exhausse', 'exhaus', 'exaus'] },
  cleanse: { n: 'Cleanse', cd: 240, w: ['cleanse', 'clean', 'cleans', 'clinse', 'clins', 'clince', 'purge', 'purification', 'klins', 'clinz', 'cleanz'] },
  ghost: { n: 'Ghost', cd: 240, w: ['ghost', 'gost', 'goste', 'ghosts', 'fantome', 'gosts', 'gaust'] },
  // Smite : 2 charges, une charge revient toutes les 90 s (réduit par le haste des sorts) ; « no smite » = plus aucune charge
  smite: { n: 'Smite', cd: 90, w: ['smite', 'smites', 'smait', 'smaite', 'smaites', 'smit', 'smiite', 'chatiment', 'chatiments', 'smaitte', 'smaille'] }
};
const SPELL_ORDER = ['flash', 'tp', 'smite', 'ignite', 'heal', 'barrier', 'exhaust', 'cleanse', 'ghost'];
// Haste : Cosmic Insight 18, Bottes de Lucidité ioniennes 10, Lucidité pourpre 20 ; CD = base × 100 / (100 + haste)
const HASTE = { cosmic: 18, boots: { 0: 0, 10: 10, 20: 20 } };
const IG_ROLE_WORDS = {
  top: ['top', 'toppeur', 'topeur', 'toplaner', 'toplane', 'haut', 'tope', 'toppe', 'tops', 'topp'],
  jgl: ['jungle', 'jungler', 'jungleur', 'jgl', 'jungl', 'jung', 'jongle', 'jungel', 'djungle', 'jungles', 'jangle', 'jingle', 'djoungle', 'joungle', 'jungla', 'jun'],
  mid: ['mid', 'midlaner', 'midlane', 'milieu', 'mide', 'midd', 'mi', 'mids', 'mite', 'midde', 'mitt'],
  adc: ['adc', 'adece', 'ad', 'bot', 'botlane', 'bottom', 'carry', 'adcarry', 'tireur', 'botte', 'bots', 'boat', 'adecé', 'adesse'],
  sup: ['support', 'supp', 'sup', 'supporte', 'soutien', 'supports', 'suppe', 'supe', 'sape', 'soupe']
};
// surnoms par défaut (complétables dans l'onglet)
const NICK_DEFAULT = {
  'Jarvan IV': 'j4, jarvan', 'Twisted Fate': 'tf, twisted', 'Miss Fortune': 'mf, miss', 'Aurelion Sol': 'asol, aurelion', 'Dr. Mundo': 'mundo',
  'Lee Sin': 'lee, lisin, lissine', "Kai'Sa": 'kaisa, kaissa', "Kog'Maw": 'kog, kogmaw', 'Master Yi': 'yi, master', 'Xin Zhao': 'xin, xinzhao',
  'Tahm Kench': 'tahm, kench', 'Nunu & Willump': 'nunu', 'Renata Glasc': 'renata', "Cho'Gath": 'cho, chogath', "K'Sante": 'ksante, sante, kasante',
  "Bel'Veth": 'belveth', "Vel'Koz": 'velkoz', "Kha'Zix": 'khazix, kha, kazix', "Rek'Sai": 'reksai', 'LeBlanc': 'leblanc, lb', 'Wukong': 'wukong, singe',
  'Aurora': 'aurora', 'Ambessa': 'ambessa', 'Mel': 'mel', 'Yunara': 'yunara', 'Zaahen': 'zaahen', 'Locke': 'locke, lock',
  'Ezreal': 'ez, israel, ezrael, esreal', 'Thresh': 'tresh, treche, trech', 'Gnar': 'gnare, niar, gnard', 'Rell': 'rel, rail, raille',
  'Syndra': 'sandra, cindra, sindra', 'Ahri': 'ari, harry, arie', 'Nautilus': 'naut, nautile, notilus, nauti', "Kog'Maw": 'kog, kogmaw, kogmo',
  'Vladimir': 'vlad', 'Fiddlesticks': 'fiddle, fid', 'Heimerdinger': 'heimer, donger', 'Blitzcrank': 'blitz', 'Mordekaiser': 'morde, mordo',
  'Tryndamere': 'trynda, trinda', 'Caitlyn': 'cait, kate, caitlin', 'Lucian': 'lucien', 'Leona': 'leona, leonard', 'Senna': 'sena, scena',
  'Seraphine': 'sera, seraphin', 'Kassadin': 'kassa, kass', 'Katarina': 'kata, katarina', 'Cassiopeia': 'cassio, cassiopee', 'Malphite': 'malph, malfite',
  'Orianna': 'ori, oriana', 'Nidalee': 'nida, nidali', 'Evelynn': 'eve, evelyne', 'Volibear': 'voli, volibeer', 'Sejuani': 'sej, seju',
  'Gragas': 'grag, gragasse', 'Pantheon': 'panth, pantheon', 'Hecarim': 'heca, hecarime', 'Rengar': 'reng, rengar', 'Alistar': 'ali, alistair',
  'Galio': 'galio, galileo', 'Taliyah': 'talia, taliya', 'Xerath': 'xerath, zerath', 'Ziggs': 'zigs, ziggs', 'Smolder': 'smolder, smoldeur',
  'Jinx': 'jinx, jinks', 'Kayn': 'kane, cain, kaine, kaynn', 'Pyke': 'pike, paik, paike', 'Jhin': 'jin, gin, djin', 'Yasuo': 'yasou, yasuo',
  'Bard': 'barde', 'Lux': 'luxe', 'Sion': 'scion', 'Zed': 'zede, zedd', 'Yone': 'yone, yonne', 'Karthus': 'karthus, kartus', 'Lillia': 'lilia', 'Briar': 'briard, brayar', 'Varus': 'varus, varusse', 'Zeri': 'zeri, zerry', 'Draven': 'drave, draven', 'Samira': 'sami, samira', 'Aphelios': 'aphe, aphelio'
};

const norm = s => String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9 ]+/g, ' ').replace(/\s+/g, ' ').trim();
function lev(a, b) {
  if (a === b) return 0; const m = a.length, n = b.length; if (!m) return n; if (!n) return m;
  let p = Array.from({ length: n + 1 }, (_, j) => j);
  for (let i = 1; i <= m; i++) { const c = [i]; for (let j = 1; j <= n; j++) c[j] = Math.min(p[j] + 1, c[j - 1] + 1, p[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)); p = c; }
  return p[n];
}

// clé phonétique (français / noms anglais) : rapproche « lissine » de « lee sin », « kaïssa » de « kai'sa », « trèche » de « thresh »
function phon(w) {
  w = norm(w).replace(/ /g, '');
  w = w.replace(/sch|sh/g, '§').replace(/ch/g, '§').replace(/ph/g, 'f').replace(/th/g, 't').replace(/ck|qu|q/g, 'k').replace(/c(?=[eiy])/g, 's').replace(/c/g, 'k')
    .replace(/gu(?=[eiy])/g, 'g').replace(/(^|[^n])g(?=[eiy])/g, '$1j').replace(/x/g, 'ks').replace(/z/g, 's').replace(/w/g, 'v').replace(/y/g, 'i').replace(/h/g, '')
    .replace(/ee|ea|ie/g, 'i').replace(/eau|au/g, 'o').replace(/oo|ou/g, 'u').replace(/ai|ei|ay|ey/g, 'e')
    .replace(/(.)\1+/g, '$1');
  if (w.length > 3) w = w.replace(/[ed]$/, '');
  if (w.length > 3) w = w.replace(/s$/, '');
  return w;
}
const NUMW = { un: '1', deux: '2', trois: '3', quatre: '4', cinq: '5', one: '1', two: '2', three: '3', four: '4', for: '4' };
// --- État : partagé (adversaires, chronos, horloge, haste) et local (réglages) ---
var IG = { enemies: {}, allies: {}, timers: {}, clock: null, haste: {}, rev: 0 };
// sections dépliées de l'onglet (gardées d'un rendu à l'autre : l'onglet se redessine à chaque sort annoncé)
var IG_OPEN = { items: true, champs: false, nick: false, frise: true };
var IGL = { delay: 3, voice: true, vol: 0.9, nick: '', mic: false };
try { Object.assign(IGL, JSON.parse(localStorage.getItem('draftTool.ig') || '{}')); } catch (e) { }
IGL.mic = false;
const saveIGL = () => { try { localStorage.setItem('draftTool.ig', JSON.stringify(IGL)); } catch (e) { } };
try { const s = JSON.parse(localStorage.getItem('draftTool.igs') || 'null'); if (s && s.timers) IG = s; } catch (e) { }
var IG_MISS = [];
var IGREF = null, IG_LAST = '', IG_TICK = null, IG_SPOKEN = {}, IG_SEEN = {}, IG_MENU = null, IG_HEARD = '', IG_FEED = '';

function igAllies() {
  // nos champions : corrections manuelles d'abord, sinon la dernière draft
  const out = {}, mine = (typeof ourRoles === 'function' && S.draft) ? ourRoles() : {};
  ROLES.forEach(r => { const id = IG.allies && IG.allies[r]; const c = id ? BY[id] : (mine[r] || null); if (c) out[r] = c; });
  return out;
}
function igEnemies() {
  // adversaires : corrections manuelles d'abord, sinon la dernière draft
  const out = {}, er = (typeof enemyRoles === 'function' && S.draft) ? enemyRoles().m : {};
  ROLES.forEach(r => { const id = IG.enemies && IG.enemies[r]; out[r] = id ? BY[id] : (er[r] || null); });
  return out;
}
function igPush() {
  IG.rev = nowS();
  try { localStorage.setItem('draftTool.igs', JSON.stringify(IG)); } catch (e) { }
  const s = JSON.stringify(IG); if (s === IG_LAST) return; IG_LAST = s;
  if (IGREF) IGREF.set({ state: s, by: CLIENT, at: Date.now() }).catch(() => { });
}
function igMutate(fn) { fn(IG); igPush(); renderIngameSoft(); }

function hasteOf(r) { const h = IG.haste[r] || {}; return (h.c ? HASTE.cosmic : 0) + (+h.b || 0); }
function estLevel(gameSec) { return Math.max(1, Math.min(18, Math.round(3 + 0.55 * gameSec / 60))); }
function gameSec(t) { return IG.clock ? (t - IG.clock) / 1000 : null; }
// durée effective d'un sort pour ce rôle : base, TP déchaîné après 10:00 (330 à 240 s selon le niveau), haste, délai d'annonce
function spellDur(r, sp, at) {
  let base = SPELLS[sp].cd, unl = false;
  const g = gameSec(at);
  if (sp === 'tp' && g != null && g >= 600) { const lvl = estLevel(g); base = 330 - 90 * (lvl - 1) / 17; unl = true; }
  const cd = base * 100 / (100 + hasteOf(r));
  return { cd, eff: Math.max(5, cd - IGL.delay), unl };
}
const mmss = s => { s = Math.max(0, Math.round(s)); return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`; };
const spellName = (sp, unl) => SPELLS[sp].n + (unl ? ' (déchaîné)' : '');

function igStart(r, sp, who) {
  const at = nowS(), d = spellDur(r, sp, at);
  igMutate(g => { g.timers[r + '|' + sp] = { r, sp, end: at + d.eff * 1000, dur: d.eff, at, unl: d.unl, by: who || ME || '' }; });
  const c = igEnemies()[r];
  igSay(`${c ? c.n : RL[r]} ${SPELLS[sp].n}, ${spokenDur(d.eff)}`);
  return d;
}
function igCancel(r, sp) { igMutate(g => { Object.keys(g.timers).forEach(k => { const t = g.timers[k]; if (t.r === r && (!sp || t.sp === sp)) delete g.timers[k]; }); }); }
function igShift(k, sec) { igMutate(g => { const t = g.timers[k]; if (t) { t.end += sec * 1000; } }); }
function igGo() { igMutate(g => { g.clock = nowS(); }); igSay('Horloge lancée'); }
function igNewGame() { igMutate(g => { g.timers = {}; g.clock = null; g.haste = {}; g.enemies = {}; g.allies = {}; }); IG_SPOKEN = {}; }
const spokenDur = s => { s = Math.round(s); const m = Math.floor(s / 60), r = s % 60; return m ? `${m} minute${m > 1 ? 's' : ''}${r ? ' ' + r : ''}` : `${r} secondes`; };

// --- Voix (synthèse de Chrome, pas de micro nécessaire) ---
function igSay(text) {
  if (!IGL.voice || !window.speechSynthesis) return;
  try { const u = new SpeechSynthesisUtterance(text); u.lang = 'fr-FR'; u.volume = +IGL.vol; u.rate = 1.1; const v = speechSynthesis.getVoices().find(x => /^fr/i.test(x.lang)); if (v) u.voice = v; speechSynthesis.speak(u); } catch (e) { }
}

// --- Analyse d'une phrase ---
function igAliases() {
  const en = igEnemies(), list = [];
  const nickMap = {}; Object.entries(NICK_DEFAULT).forEach(([k, v]) => nickMap[k] = v);
  (IGL.nick || '').split('\n').forEach(l => { const m = l.split(/[:=]/); if (m.length >= 2) { const c = CH.find(x => norm(x.n) === norm(m[0])); if (c) nickMap[c.n] = (nickMap[c.n] ? nickMap[c.n] + ',' : '') + m.slice(1).join(':'); } });
  ROLES.forEach(r => {
    const c = en[r]; if (!c) return;
    const al = new Set([norm(c.n).replace(/ /g, ''), norm(c.n).split(' ')[0], norm(c.k)]);
    (nickMap[c.n] || '').split(',').map(norm).filter(Boolean).forEach(a => al.add(a.replace(/ /g, '')));
    (IGL.learn || {})[c.n] && IGL.learn[c.n].forEach(a => al.add(a));
    al.forEach(a => { if (a.length >= 2) list.push({ a, p: phon(a), r, c }); });
  });
  return list;
}
function matchChamp(word, als) {
  let best = null; const pw = phon(word);
  als.forEach(x => {
    let d = lev(word, x.a);
    if (word.length >= 4 && x.a.startsWith(word)) d = Math.min(d, 1);
    const tol = x.a.length <= 3 ? 0 : x.a.length <= 5 ? 1 : 2;
    let ok = d <= tol;
    // même son, orthographe différente
    if (!ok && pw.length >= 2) { const dp = lev(pw, x.p), tp = x.p.length <= 3 ? 0 : x.p.length <= 6 ? 1 : 2; if (dp <= tp) { ok = true; d = Math.min(d, dp + 0.5); } }
    if (ok && (!best || d < best.d)) best = { d, r: x.r, c: x.c };
  });
  return best;
}
const roleOf = w => { for (const r of ROLES) if (IG_ROLE_WORDS[r].includes(w)) return r; const pw = phon(w); if (pw.length >= 3) for (const r of ROLES) if (IG_ROLE_WORDS[r].some(x => x.length >= 3 && phon(x) === pw)) return r; return null; };
const spellOf = w => { if (SPELL_OF[w]) return SPELL_OF[w]; if (w.length < 4) return null; const pw = phon(w); for (const sp of SPELL_ORDER) if (SPELLS[sp].w.some(x => x.length >= 4 && (lev(w, x) <= 1 || phon(x) === pw))) return sp; return null; };
var PARSE_UNK = [];
const igScore = p => p.kind === 'start' ? 10 * p.list.length : (p.kind === 'cancel' || p.kind === 'go') ? 8 : p.kind === 'err' && p.msg !== 'rien de reconnu' ? 1 : 0;
function igParse(raw) {
  PARSE_UNK = [];
  const t = norm(raw); if (!t) return { kind: 'none' };
  let toks = t.split(' ');
  // « t p » → tp ; « a d c » → adc
  toks = toks.map(w => NUMW[w] || w);
  // lettres épelées ou lettre + chiffre : « t p » → tp, « a d c » → adc, « j 4 » → j4, « aime f » → mf
  const j = []; for (let i = 0; i < toks.length; i++) {
    if (toks[i] === 'aime' && toks[i + 1] === 'f') { j.push('mf'); i++; continue; }
    if (toks[i].length === 1 && toks[i + 1] && toks[i + 1].length === 1) { let w = toks[i]; while (toks[i + 1] && toks[i + 1].length === 1) w += toks[++i]; j.push(w); continue; }
    j.push(toks[i]);
  }
  toks = j;
  if (toks.includes('go') && toks.length <= 3 && !toks.some(w => SPELL_OF[w])) return { kind: 'go' };
  const cancel = toks.some(w => /^(annule|annuler|annulle|annul|cancel|efface|supprime|anule)$/.test(w));
  const als = igAliases();
  const items = [];
  const STOP = /^(no|non|pas|plus|de|du|le|la|les|et|a|il|elle|annule|annuler|cancel|sur|son|sa|un|une|en|y|est|ont|ya|na|n|l|d)$/;
  const skip = new Set();
  toks.forEach((w, i) => {
    if (skip.has(i)) return;
    // nom en deux ou trois morceaux : « li sine », « kha zix », « miss fortune »
    for (const n of [3, 2]) {
      if (i + n > toks.length) continue;
      const ws = toks.slice(i, i + n); if (ws.some(x => SPELL_OF[x] || /^(no|non|pas|plus|et|annule|annuler|cancel|puis)$/.test(x))) continue;
      const m = matchChamp(ws.join(''), als);
      if (m && m.d <= 1) { items.push({ i, r: m.r, how: m.c.n, d: m.d }); for (let k = 1; k < n; k++) skip.add(i + k); return; }
    }
    const sp = SPELL_OF[w]; if (sp) { items.push({ i, sp }); return; }
    const r = roleOf(w); if (r) { items.push({ i, r, how: 'rôle' }); return; }
    if (w.length >= 2 && !STOP.test(w)) {
      const m = matchChamp(w, als);
      if (m) { items.push({ i, r: m.r, how: m.c.n, d: m.d }); return; }
      const s2 = spellOf(w); if (s2) { items.push({ i, sp: s2, fuzzy: true }); return; }
    }
    if ((w === 'il' || w === 'hil') && /^(no|non|pas|plus|de)$/.test(toks[i - 1] || '')) items.push({ i, sp: 'heal', weak: true });
  });
  PARSE_UNK = toks.filter((w, i) => !skip.has(i) && !items.some(x => x.i === i) && w.length >= 2 && !STOP.test(w) && !/^(annule|annuler|annulle|annul|cancel|efface|supprime|anule|go|puis|aussi|ensuite|flashe|ok)$/.test(w));
  // « il » ne vaut « heal » que si aucun autre sort n'est dit (« diana il a flash »)
  if (items.some(x => x.sp && !x.weak)) for (let k = items.length - 1; k >= 0; k--) if (items[k].weak) items.splice(k, 1);
  const sps = items.filter(x => x.sp), tgs = items.filter(x => x.r);
  if (cancel) { if (!tgs.length) return { kind: 'err', msg: 'annulation : cible non reconnue' }; return { kind: 'cancel', list: tgs.map(t => ({ r: t.r, sp: sps.length ? sps[0].sp : null })) }; }
  if (!sps.length) return { kind: 'err', msg: tgs.length ? 'sort non reconnu' : 'rien de reconnu' };
  if (!tgs.length && sps.length && sps.every(x => x.sp === 'smite') && toks.some(w => /^(no|non|pas|plus|sans|na)$/.test(w))) return { kind: 'start', list: [{ r: 'jgl', sp: 'smite' }] };
  if (!tgs.length) return { kind: 'err', msg: 'cible non reconnue' };
  // découpe en propositions (« et », « puis », « aussi ») ; dans chacune, chaque sort va à la cible de la proposition
  const cuts = toks.map((w, i) => /^(et|puis|aussi|ensuite)$/.test(w) ? i : -1).filter(i => i >= 0);
  const clauseOf = i => cuts.filter(c => c < i).length;
  const out = [], seen = new Set();
  const add = (r, sp) => { const k = r + '|' + sp; if (!seen.has(k)) { seen.add(k); out.push({ r, sp }); } };
  const nCl = cuts.length + 1;
  for (let c = 0; c < nCl; c++) {
    const cs = sps.filter(x => clauseOf(x.i) === c), ct = tgs.filter(x => clauseOf(x.i) === c);
    if (!cs.length) { // « no flash mid et top » : même sort que la proposition d'avant
      const prev = sps.filter(x => clauseOf(x.i) < c); if (prev.length && c > 0) tgs.filter(x => clauseOf(x.i) === c).forEach(t => add(t.r, prev[prev.length - 1].sp)); continue;
    }
    if (ct.length === 1) { cs.forEach(s => add(ct[0].r, s.sp)); continue; }
    if (!ct.length) { // « no flash mid et top » : la cible vient de la proposition voisine
      const nb = tgs.filter(x => clauseOf(x.i) === c + 1).concat(tgs.filter(x => clauseOf(x.i) === c - 1));
      if (nb.length) cs.forEach(s => add(nb[0].r, s.sp)); continue;
    }
    // plusieurs cibles dans la même proposition : chaque sort prend la plus proche (après lui de préférence)
    const used = new Set();
    cs.forEach(s => {
      const after = ct.filter(t => t.i > s.i && !used.has(t)), before = ct.filter(t => t.i < s.i && !used.has(t));
      const t = after.length ? after[0] : before.length ? before[before.length - 1] : ct[0];
      used.add(t); add(t.r, s.sp);
    });
    // cibles restantes sans sort : « no flash mid top » → même sort
    ct.filter(t => !used.has(t)).forEach(t => add(t.r, cs[cs.length - 1].sp));
  }
  if (!out.length) return { kind: 'err', msg: 'cible non reconnue' };
  return { kind: 'start', list: out };
}
var SPELL_OF = {}; SPELL_ORDER.forEach(sp => SPELLS[sp].w.forEach(w => { SPELL_OF[w] = sp; }));
Object.entries(IGL.learnSp || {}).forEach(([w, sp]) => { if (SPELLS[sp]) SPELL_OF[w] = sp; });
function igCommand(raw, source) {
  const p = igParse(raw), en = igEnemies(), nm = r => en[r] ? en[r].n : RL[r];
  let fb = '';
  if (p.kind === 'go') { igGo(); fb = 'Horloge calée à 0:00'; }
  else if (p.kind === 'cancel') { p.list.forEach(x => igCancel(x.r, x.sp)); fb = 'Annulé : ' + p.list.map(x => nm(x.r) + (x.sp ? ' ' + SPELLS[x.sp].n : '')).join(', '); igSay(fb); }
  else if (p.kind === 'start') {
    fb = p.list.map(x => {
      // même annonce répétée dans les 4 secondes (doublon de la reconnaissance ou deux coéquipiers) : on garde le premier chrono
      const t = IG.timers[x.r + '|' + x.sp]; if (t && nowS() - t.at < 4000) return `${nm(x.r)} ${SPELLS[x.sp].n} déjà noté`;
      const d = igStart(x.r, x.sp, ME); return `${nm(x.r)} ${spellName(x.sp, d.unl)} ${mmss(d.eff)}`;
    }).join(' · ');
    IG_MISS = IG_MISS.filter(m => m.raw !== raw);
  }
  else if (p.kind === 'err') {
    fb = `« ${raw} » : ${p.msg}`;
    if (source === 'voix' && p.msg !== 'rien de reconnu' && PARSE_UNK.length) { IG_MISS = [{ raw, msg: p.msg, unk: PARSE_UNK.slice(0, 3) }].concat(IG_MISS.filter(m => m.raw !== raw)).slice(0, 3); renderIngameSoft(); }
  }
  IG_FEED = fb; const el = document.getElementById('igfeed'); if (el) el.textContent = fb;
  return p;
}

// apprentissage : un mot mal compris est rattaché au champion (ou au sort) choisi, puis la commande est rejouée
function igLearn(k, kind, val) {
  const m = IG_MISS[k]; if (!m) return;
  if (kind === 'champ') { const c = BY[val]; if (!c) return; IGL.learn = IGL.learn || {}; const L = IGL.learn[c.n] = IGL.learn[c.n] || []; m.unk.forEach(w => { if (!L.includes(w)) L.push(w); }); }
  else { IGL.learnSp = IGL.learnSp || {}; m.unk.forEach(w => { IGL.learnSp[w] = val; SPELL_OF[w] = val; }); }
  saveIGL(); IG_MISS.splice(k, 1); igCommand(m.raw, 'appris');
  IG_FEED = `Appris : « ${m.unk.join(' ')} » = ${kind === 'champ' ? BY[val].n : SPELLS[val].n}. ` + IG_FEED; renderIngame();
}
function igUnlearn() { IGL.learn = {}; IGL.learnSp = {}; saveIGL(); location.reload(); }
// --- Reconnaissance vocale : écoute continue, redémarrage automatique ---
var REC = null, REC_WANT = false;
function micSupported() { return !!(window.SpeechRecognition || window.webkitSpeechRecognition); }
var REC_NET = 0, REC_FAST = 0, REC_T0 = 0, REC_BRAVE_OK = false;
// mode « sur l'ordinateur » (Chrome) : reconnaissance locale, orientée vers les noms des 5 adversaires
var REC_LOCAL_AV = null;
async function recLocalCheck() {
  const R = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!R || !R.available || navigator.brave) { REC_LOCAL_AV = 'unavailable'; return; }
  try { REC_LOCAL_AV = await R.available({ langs: ['fr-FR'], processLocally: true }); } catch (e) { REC_LOCAL_AV = 'unavailable'; }
  if (REC_LOCAL_AV !== 'available' && IGL.local) { IGL.local = false; saveIGL(); }
  renderIngameSoft();
}
function recPhrases() {
  if (!window.SpeechRecognitionPhrase) return [];
  const en = igEnemies(), out = [], add = (p, b) => { try { out.push(new SpeechRecognitionPhrase(p, b)); } catch (e) { } };
  ROLES.forEach(r => { const c = en[r]; if (c) { add(c.n, 4); add(c.n + ' no flash', 3); } });
  ['flash', 'TP', 'smite', 'ignite', 'heal', 'exhaust', 'cleanse', 'ghost', 'barrière', 'embrasement'].forEach(w => add(w, 2.5));
  ['top', 'jungle', 'mid', 'ADC', 'bot', 'support', 'annule', 'go'].forEach(w => add(w, 2));
  return out;
}
var REC_PHR_OFF = false;
function newRec() {
  const R = window.SpeechRecognition || window.webkitSpeechRecognition;
  const rec = new R(); rec.lang = 'fr-FR'; rec.continuous = true; rec.interimResults = true; rec.maxAlternatives = 5;
  if (IGL.local && REC_LOCAL_AV === 'available') { try { rec.processLocally = true; if (!REC_PHR_OFF) rec.phrases = recPhrases(); } catch (e) { } }
  rec.onstart = () => { setMicState('listening'); };
  rec.onresult = e => {
    REC_NET = 0;
    for (let i = e.resultIndex; i < e.results.length; i++) {
      const r = e.results[i];
      if (r.isFinal) {
        // parmi les transcriptions proposées, garde celle qui donne la commande la plus complète
        let best = r[0].transcript, bs = -1;
        for (let a = 0; a < r.length; a++) { const sc = igScore(igParse(r[a].transcript)) - a * 0.01; if (sc > bs) { bs = sc; best = r[a].transcript; } }
        IG_HEARD = best.trim(); setHeard(IG_HEARD, false); igCommand(best, 'voix');
      } else setHeard(r[0].transcript, true);
    }
  };
  rec.onerror = e => {
    if (e.error === 'phrases-not-supported') { REC_PHR_OFF = true; recRebuild(); return; }
    if (e.error === 'language-not-supported' && IGL.local) { IGL.local = false; saveIGL(); IG_FEED = 'Reconnaissance sur l’ordinateur indisponible en français : retour au mode en ligne.'; recRebuild(); return; }
    if (e.error === 'not-allowed' || e.error === 'service-not-allowed') { REC_WANT = false; IGL.mic = false; IG_FEED = 'Micro refusé : autorise le micro pour cette page dans Chrome.'; renderIngameSoft(); return; }
    if (e.error === 'network') {
      REC_NET = (REC_NET || 0) + 1;
      if (REC_NET >= 3) { REC_WANT = false; IGL.mic = false; IG_FEED = navigator.brave ? 'Brave bloque la reconnaissance vocale de Google : ouvre cette page dans Google Chrome ou Microsoft Edge.' : 'Service de reconnaissance vocale injoignable (connexion, VPN ou bloqueur ?). Réessaie, ou active la reconnaissance sur l’ordinateur.'; renderIngameSoft(); }
      return;
    }
    if (e.error !== 'no-speech' && e.error !== 'aborted') setMicState('error ' + e.error);
  };
  rec.onend = () => {
    if (rec !== REC) return;
    if (!REC_WANT) { setMicState('idle'); return; }
    REC_FAST = (Date.now() - (REC_T0 || 0) < 1500) ? (REC_FAST || 0) + 1 : 0;
    setTimeout(() => { if (rec !== REC || !REC_WANT) return; REC_T0 = Date.now(); if (IGL.local && REC_PHR_DIRTY) { REC_PHR_DIRTY = false; recRebuild(); return; } try { rec.start(); } catch (e) { } }, REC_FAST > 2 ? 1500 : 250);
  };
  return rec;
}
// les adversaires ont changé : la liste de noms sera mise à jour au prochain redémarrage
var REC_PHR_DIRTY = false;
function recRebuild() { const old = REC; REC = null; if (old) { try { old.abort(); } catch (e) { } } if (REC_WANT) { REC = newRec(); REC_T0 = Date.now(); try { REC.start(); } catch (e) { } } }
function micStart() {
  if (!micSupported()) { IG_FEED = 'Reconnaissance vocale indisponible dans ce navigateur (utiliser Chrome)'; renderIngameSoft(); return; }
  if (navigator.brave && !REC_BRAVE_OK) { IG_FEED = 'Brave bloque la reconnaissance vocale de Google : ouvre cette page dans Google Chrome ou Microsoft Edge (les commandes au clavier marchent ici).'; renderIngameSoft(); REC_BRAVE_OK = true; return; }
  REC_WANT = true; IGL.mic = true; REC_NET = 0; REC_T0 = Date.now();
  if (!REC) REC = newRec();
  try { REC.start(); } catch (e) { }
}
function micStop() { REC_WANT = false; IGL.mic = false; if (REC) try { REC.stop(); } catch (e) { } setMicState('idle'); renderIngameSoft(); }
function setMicState(s) { const el = document.getElementById('igmic'); if (el) { if (s === 'idle' && REC_WANT) return; el.dataset.state = s; el.querySelector('.lbl').textContent = s === 'listening' ? 'Écoute…' : REC_WANT ? 'Relance…' : 'Micro coupé'; } }
function setHeard(t, partial) { const el = document.getElementById('igheard'); if (el) { el.textContent = t; el.classList.toggle('partial', !!partial); } }

// --- Affichage ---
var REC_SIG = '';
function renderIngame() {
  const en = igEnemies(), now = nowS(), g = gameSec(now);
  const sig = ROLES.map(r => en[r] ? en[r].id : '').join(','); if (sig !== REC_SIG) { REC_SIG = sig; REC_PHR_DIRTY = true; }
  if (REC_LOCAL_AV === null) { REC_LOCAL_AV = 'pending'; recLocalCheck(); }
  let h = `<div class="igtop">
    <button id="igmic" class="igmic" data-state="idle" ${micSupported() ? '' : 'disabled'}><span class="dot"></span><span class="lbl">${micSupported() ? 'Micro coupé' : 'Micro indisponible ici'}</span></button>
    <div class="igheard"><small>Dernière phrase</small><span id="igheard">${esc(IG_HEARD || '—')}</span></div>
    <div class="igclock"><small>Temps de jeu</small><b id="igclk">${g == null ? '--:--' : mmss(g)}</b><button id="iggo">Go (0:00)</button></div>
    <div class="igset"><label>Délai d’annonce <input id="igdelay" type="number" min="0" max="15" value="${IGL.delay}"> s</label>
      <label class="chk"><input type="checkbox" id="igvoice" ${IGL.voice ? 'checked' : ''}> Annonces vocales</label>
      <input id="igvol" type="range" min="0" max="1" step="0.1" value="${IGL.vol}" title="Volume">
      ${REC_LOCAL_AV && REC_LOCAL_AV !== 'unavailable' ? `<label title="Sur l’ordinateur : marche sans connexion et privilégie les noms des 5 adversaires">Reconnaissance <select id="igrec"><option value="0">en ligne (Google)</option><option value="1" ${IGL.local ? 'selected' : ''}>sur l’ordinateur${REC_LOCAL_AV === 'available' ? '' : ' (à installer)'}</option></select></label>` : ''}
      <button id="ignew" class="ghost">Nouvelle partie</button></div>
  </div>
  <div class="igcmd"><input id="igtxt" placeholder="Commande au clavier (secours) : no flash mid, diana no flash, jungle no tp, annule diana, go…" autocomplete="off"><button id="igsend">Envoyer</button><span id="igfeed" class="note">${esc(IG_FEED)}</span></div>
  ${IG_MISS.length ? `<div class="igmiss">${IG_MISS.map((m, k) => `<div><span class="note">Pas compris « ${esc(m.raw)} » : « ${esc(m.unk.join(' '))} », c’était</span> ${m.msg === 'sort non reconnu' ? SPELL_ORDER.map(sp => `<button class="ghost small" data-lsp="${k}|${sp}">${SPELLS[sp].n}</button>`).join('') : ROLES.filter(r => en[r]).map(r => `<button class="ghost small" data-lch="${k}|${en[r].id}">${esc(en[r].n)}</button>`).join('')} <button class="ghost small" data-lx="${k}">✕</button></div>`).join('')}</div>` : ''}
  <div class="igcopy"><span id="igline">${esc(igLine())}</span><button id="igcp" class="ghost">Copier pour le chat</button></div>
  <div class="iggrid">`;
  ROLES.forEach(r => {
    const c = en[r], hs = IG.haste[r] || {};
    const tms = Object.entries(IG.timers).filter(([, t]) => t.r === r).sort((a, b) => SPELL_ORDER.indexOf(a[1].sp) - SPELL_ORDER.indexOf(b[1].sp));
    h += `<div class="igtile"><div class="ighead">${c ? img(c, 'big') : '<span class="ic big"></span>'}<div><small>${RL[r]}</small><b>${c ? esc(c.n) : '—'}</b></div></div>
      <div class="igtimers">${tms.length ? tms.map(([k, t]) => {
        const rem = (t.end - now) / 1000, ready = rem <= 0, ret = t.end && IG.clock ? mmss((t.end - IG.clock) / 1000) : null;
        return `<button class="igt ${ready ? 'ready' : rem <= 30 ? 'soon' : ''}" data-k="${esc(k)}"><span class="sp">${esc(spellName(t.sp, t.unl))}</span><span class="cd">${ready ? 'DISPO' : mmss(rem)}</span>${ret ? `<span class="ret">${esc((c ? c.n : RL[r]) + ' ' + SPELLS[t.sp].n)} → ${ret}</span>` : ''}${IG_MENU === k ? `<span class="igmenu"><span data-a="-5">−5 s</span><span data-a="+5">+5 s</span><span data-a="x">Annuler</span></span>` : ''}</button>`;
      }).join('') : '<span class="note">Aucun sort tombé</span>'}</div>
      <div class="igbtns">${(r === 'jgl' ? ['flash', 'smite'] : ['flash', 'tp']).map(sp => `<button data-st="${r}|${sp}">${SPELLS[sp].n}</button>`).join('')}<select data-st2="${r}"><option value="">Autre…</option>${SPELL_ORDER.filter(sp => sp !== 'flash' && sp !== (r === 'jgl' ? 'smite' : 'tp')).map(sp => `<option value="${sp}">${SPELLS[sp].n}</option>`).join('')}</select></div>
      <div class="ighaste"><label class="chk"><input type="checkbox" data-hc="${r}" ${hs.c ? 'checked' : ''}> Cosmic Insight</label>
        <select data-hb="${r}"><option value="0">Bottes : autres</option><option value="10" ${+hs.b === 10 ? 'selected' : ''}>Lucidité (10)</option><option value="20" ${+hs.b === 20 ? 'selected' : ''}>Lucidité pourpre (20)</option></select>
        <small>${hasteOf(r) ? `haste ${hasteOf(r)} · Flash ${mmss(300 * 100 / (100 + hasteOf(r)))}` : ''}</small></div></div>`;
  });
  h += `</div>
  ${(() => { const al = igAllies(); if (Object.keys(al).length < 5) return ''; const plan = gamePlan(ROLES.map(r => al[r]), en);
    return `<details class="cplan" id="igfrd" ${IG_OPEN.frise ? 'open' : ''}><summary><b>Frise de la partie</b> <span class="note">· ${esc(STYLES[plan.sty] || '')} · ${plan.strong === 'bot' ? 'côté fort bot : dragons' : plan.strong === 'top' ? 'côté fort top : larves et héraut' : 'pas de côté fort net'}</span></summary>${friseHtml(plan.tl, g == null ? 0 : g, 'igfr')}</details>`; })()}
  ${(() => { const al = igAllies(); return Object.keys(al).length ? itemsBox(al, en, IG_OPEN.items, 'igitems') : `<details class="cplan" id="igitems" ${IG_OPEN.items ? 'open' : ''}><summary><b>Objets conseillés</b></summary><p class="note">Indique vos champions dans « Champions de la partie » ci-dessous (ou fais la draft dans l’onglet Draft) pour voir les objets de chacun, avec les situationnels contre leur compo.</p></details>`; })()}
  ${(() => { const al = igAllies(), sorted = CH.slice().sort((a, b) => a.n.localeCompare(b.n));
    const row = (kind, cur, man, lab) => `<div class="igen"><b style="min-width:90px">${lab}</b>${ROLES.map(r => `<label>${RL[r]} <select data-${kind}="${r}"><option value="">${cur[r] && !man[r] ? esc(cur[r].n) + ' (draft)' : '— draft —'}</option>${sorted.map(c => `<option value="${c.id}" ${man[r] === c.id ? 'selected' : ''}>${esc(c.n)}</option>`).join('')}</select></label>`).join('')}</div>`;
    return `<details class="cplan" id="igchamps" ${IG_OPEN.champs ? 'open' : ''}><summary><b>Champions de la partie</b> (repris de la dernière draft, corrigeables)</summary>${row('al', al, IG.allies || {}, 'Nous')}${row('en', en, IG.enemies || {}, 'Adversaires')}<div class="igen"><button id="igfromdraft" class="ghost">Reprendre la draft</button></div></details>`; })()}
  <details class="cplan" id="ignickd" ${IG_OPEN.nick ? 'open' : ''}><summary><b>Surnoms</b> (une ligne par champion : <code>Kha'Zix: kaz, kha</code>)</summary><textarea id="ignick" rows="4" style="width:100%">${esc(IGL.nick || '')}</textarea>${(() => { const L = Object.entries(IGL.learn || {}).map(([c, ws]) => `${c} : ${ws.join(', ')}`).concat(Object.entries(IGL.learnSp || {}).map(([w, sp]) => `${w} = ${SPELLS[sp] ? SPELLS[sp].n : sp}`)); return L.length ? `<p class="note">Mots appris : ${esc(L.join(' · '))} <button class="ghost small" id="igunlearn">Oublier</button></p>` : ''; })()}<p class="note">Quand une phrase dite au micro n’est pas comprise, clique sur le bon champion (ou le bon sort) sous la barre de commande : l’outil retient le mot pour la suite. Commandes reconnues : sort puis cible ou l’inverse (« no flash mid », « mid no flash », « no tp Diana »), « annule Diana », « annule flash mid », « go » à 0:00. Sorts : flash, tp, smite (« no smite » seul vise le jungler), ignite (ou embrasement), heal, barrière, exhaust, cleanse, ghost. Temps de recharge (patch 26.21) : Flash et TP 300 s, TP déchaîné après 10:00 de 330 à 240 s selon le niveau (estimé depuis l’horloge), Heal, Exhaust, Cleanse, Ghost 240 s, Ignite et Barrière 180 s, Smite : 2 charges, une charge revient toutes les 90 s (le chrono part quand il n’en a plus) ; haste : Cosmic Insight 18, Lucidité 10, Lucidité pourpre 20.</p></details>`;
  $('#ingame').innerHTML = h;
  bindIngame();
}
// mise à jour légère (sans reconstruire les menus ouverts ni perdre la saisie)
function renderIngameSoft() {
  if (TAB !== 'ingame') return;
  const a = document.activeElement;
  if (a && (a.id === 'igtxt' || a.id === 'ignick' || a.id === 'igdelay' || (a.tagName === 'SELECT' && a.closest('#ingame')))) { tickIngame(); return; }
  renderIngame();
}
function tickIngame() {
  const now = nowS(), g = gameSec(now);
  const ck = document.getElementById('igclk'); if (ck) ck.textContent = g == null ? '--:--' : mmss(g);
  // frise : curseur du temps de jeu, prochain moment surligné
  const cur = document.getElementById('igfr-cur');
  if (cur) { const x = frX(Math.max(0, Math.min(FR_MAX, g || 0))); cur.setAttribute('x1', x); cur.setAttribute('x2', x);
    let next = null; document.querySelectorAll('#igfr .frl li').forEach(li => { const t = +li.dataset.t; const past = g != null && t < g; li.classList.toggle('past', past); li.classList.remove('next'); if (!past && !next) next = li; });
    if (next && g != null) next.classList.add('next'); }
  document.querySelectorAll('.igt[data-k]').forEach(b => { const t = IG.timers[b.dataset.k]; if (!t) return; const rem = (t.end - now) / 1000; b.classList.toggle('ready', rem <= 0); b.classList.toggle('soon', rem > 0 && rem <= 30); const cd = b.querySelector('.cd'); if (cd) cd.textContent = rem <= 0 ? 'DISPO' : mmss(rem); });
}
function igLine() {
  const en = igEnemies(), now = nowS();
  const xs = Object.values(IG.timers).filter(t => t.end > now).sort((a, b) => a.end - b.end);
  if (!xs.length) return 'Aucun sort adverse en recharge';
  return xs.map(t => { const c = en[t.r]; const ret = IG.clock ? mmss((t.end - IG.clock) / 1000) : '+' + mmss((t.end - now) / 1000); return `${c ? c.n : RL[t.r]} ${SPELLS[t.sp].n} ${ret}`; }).join(' | ');
}
function bindIngame() {
  const mic = $('#igmic'); if (mic) { mic.onclick = () => { REC_WANT ? micStop() : micStart(); }; setMicState(REC_WANT ? 'listening' : 'idle'); }
  $('#iggo').onclick = () => igGo();
  $('#ignew').onclick = () => { igNewGame(); IG_FEED = 'Nouvelle partie'; renderIngame(); };
  $('#igdelay').onchange = e => { IGL.delay = Math.max(0, Math.min(15, +e.target.value || 0)); saveIGL(); };
  $('#igvoice').onchange = e => { IGL.voice = e.target.checked; saveIGL(); };
  $('#igvol').oninput = e => { IGL.vol = +e.target.value; saveIGL(); };
  const send = () => { const v = $('#igtxt').value; if (v.trim()) { igCommand(v, 'clavier'); $('#igtxt').value = ''; } };
  $('#igsend').onclick = send; $('#igtxt').onkeydown = e => { if (e.key === 'Enter') send(); };
  $('#igcp').onclick = async () => { try { await navigator.clipboard.writeText(igLine()); IG_FEED = 'Copié'; } catch (e) { IG_FEED = 'Copie impossible'; } const f = $('#igfeed'); if (f) f.textContent = IG_FEED; };
  document.querySelectorAll('[data-st]').forEach(b => b.onclick = () => { const [r, sp] = b.dataset.st.split('|'); igStart(r, sp, ME); });
  document.querySelectorAll('[data-st2]').forEach(s => s.onchange = () => { if (s.value) igStart(s.dataset.st2, s.value, ME); });
  document.querySelectorAll('[data-hc]').forEach(cb => cb.onchange = () => igMutate(g => { const r = cb.dataset.hc; g.haste[r] = Object.assign({}, g.haste[r], { c: cb.checked }); }));
  document.querySelectorAll('[data-hb]').forEach(s => s.onchange = () => igMutate(g => { const r = s.dataset.hb; g.haste[r] = Object.assign({}, g.haste[r], { b: +s.value }); }));
  document.querySelectorAll('[data-en]').forEach(s => s.onchange = () => igMutate(g => { g.enemies = Object.assign({}, g.enemies); if (s.value) g.enemies[s.dataset.en] = +s.value; else delete g.enemies[s.dataset.en]; }));
  document.querySelectorAll('[data-al]').forEach(s => s.onchange = () => igMutate(g => { g.allies = Object.assign({}, g.allies); if (s.value) g.allies[s.dataset.al] = +s.value; else delete g.allies[s.dataset.al]; }));
  const fd = $('#igfromdraft'); if (fd) fd.onclick = () => igMutate(g => { g.enemies = {}; g.allies = {}; });
  [['igitems', 'items'], ['igchamps', 'champs'], ['ignickd', 'nick'], ['igfrd', 'frise']].forEach(([id, k]) => { const d = document.getElementById(id); if (d) d.ontoggle = () => { IG_OPEN[k] = d.open; }; });
  const nk = $('#ignick'); if (nk) nk.onchange = () => { IGL.nick = nk.value; saveIGL(); };
  document.querySelectorAll('[data-lch]').forEach(b => b.onclick = () => { const [k, id] = b.dataset.lch.split('|'); igLearn(+k, 'champ', +id); });
  document.querySelectorAll('[data-lsp]').forEach(b => b.onclick = () => { const [k, sp] = b.dataset.lsp.split('|'); igLearn(+k, 'spell', sp); });
  document.querySelectorAll('[data-lx]').forEach(b => b.onclick = () => { IG_MISS.splice(+b.dataset.lx, 1); renderIngame(); });
  const ul = $('#igunlearn'); if (ul) ul.onclick = () => igUnlearn();
  const rs = $('#igrec'); if (rs) rs.onchange = async () => {
    const want = rs.value === '1';
    if (want && REC_LOCAL_AV !== 'available') {
      IG_FEED = 'Installation de la reconnaissance française sur l’ordinateur…'; const f = $('#igfeed'); if (f) f.textContent = IG_FEED;
      const R = window.SpeechRecognition || window.webkitSpeechRecognition;
      let ok = false; try { ok = await R.install({ langs: ['fr-FR'], processLocally: true }); } catch (e) { ok = false; }
      await recLocalCheck();
      if (!ok || REC_LOCAL_AV !== 'available') { IGL.local = false; saveIGL(); IG_FEED = 'Installation impossible ou encore en cours : réessaie dans un moment (le mode en ligne reste actif).'; renderIngame(); return; }
    }
    IGL.local = want; saveIGL(); REC_PHR_OFF = false; IG_FEED = want ? 'Reconnaissance sur l’ordinateur, orientée vers les noms des adversaires.' : 'Reconnaissance en ligne (Google).'; recRebuild(); renderIngame();
  };
  document.querySelectorAll('.igt[data-k]').forEach(b => b.onclick = e => {
    const a = e.target.closest('[data-a]');
    if (a) { const k = b.dataset.k; if (a.dataset.a === 'x') { const t = IG.timers[k]; if (t) igCancel(t.r, t.sp); } else igShift(k, +a.dataset.a); IG_MENU = null; renderIngame(); return; }
    IG_MENU = IG_MENU === b.dataset.k ? null : b.dataset.k; renderIngame();
  });
}
// boucle : compte à rebours, alertes à 30 s et au retour
function igLoop() {
  const now = nowS(), en = igEnemies();
  Object.entries(IG.timers).forEach(([k, t]) => {
    const rem = (t.end - now) / 1000, id = k + '@' + t.end, nm = (en[t.r] ? en[t.r].n : RL[t.r]) + ' ' + SPELLS[t.sp].n;
    if (rem <= 30 && rem > 25 && t.dur > 40 && !IG_SPOKEN[id + 'a']) { IG_SPOKEN[id + 'a'] = 1; igSay(`${nm} dans 30 secondes`); }
    if (rem <= 0 && rem > -5 && !IG_SPOKEN[id + 'b']) { IG_SPOKEN[id + 'b'] = 1; igSay(`${nm} disponible`); }
  });
  if (TAB === 'ingame') { tickIngame(); const l = document.getElementById('igline'); if (l) l.textContent = igLine(); }
}
setInterval(igLoop, 250);

// synchronisation : chaque changement d'un coéquipier arrive en direct ; ses nouvelles annonces sont confirmées à voix haute
async function startIngameSync(db) {
  try {
    IGREF = db.doc('live/ingame');
    const apply = d => {
      if (!d || !d.state || d.state === IG_LAST) return;
      try {
        const o = JSON.parse(d.state); if (o.rev && IG.rev && o.rev < IG.rev && d.by === CLIENT) return;
        const old = IG.timers || {};
        IG = Object.assign({ enemies: {}, allies: {}, timers: {}, clock: null, haste: {} }, o); IG_LAST = d.state;
        try { localStorage.setItem('draftTool.igs', d.state); } catch (e) { }
        const en = igEnemies();
        Object.entries(IG.timers).forEach(([k, t]) => { if (!old[k] || old[k].at !== t.at) { if (d.by !== CLIENT && nowS() - t.at < 8000) igSay(`${en[t.r] ? en[t.r].n : RL[t.r]} ${SPELLS[t.sp].n}, ${spokenDur((t.end - nowS()) / 1000)}`); } });
        renderIngameSoft();
      } catch (e) { }
    };
    const first = await IGREF.get(); if (first.exists) apply(first.data()); else igPush();
    if (IGREF.onSnapshot) IGREF.onSnapshot(s => { const d = s && s.exists ? s.data() : null; if (d && d.by !== CLIENT) apply(d); });
  } catch (e) { IGREF = null; }
}
