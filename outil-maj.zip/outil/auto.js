
// ===== Draft auto : la sélection des champions du client LoL, lue par le relais local (Draft-auto.bat) =====
// Le relais tourne sur l'ordinateur d'un joueur et répond sur http://127.0.0.1:27999 ; la page le lit chaque seconde,
// reconstruit la draft (côté, bans, picks, postes de notre équipe) et la synchro la montre à toute l'équipe.
var RELAIS = 'http://127.0.0.1:27999/';
var AUTO_OK_HERE = !!window.FBSTORE_PROMISE; // version GitHub seulement (la version Claude ne peut pas joindre l'ordinateur)
var AUTO_ON = false; try { AUTO_ON = AUTO_OK_HERE && localStorage.getItem('draftTool.auto') === '1'; } catch (e) { }
var AUTO_ST = { ok: false, status: '', side: null }, AUTO_LAST = '', AUTO_BUSY = false;
var LCU_POS = { top: 'top', jungle: 'jgl', middle: 'mid', bottom: 'adc', utility: 'sup' };
var larr = x => Array.isArray(x) ? x : (x && Array.isArray(x.value) ? x.value : (x == null ? [] : [x]));

function autoBuild(x) {
  const side = x.side === 'R' ? 'R' : 'B', other = side === 'B' ? 'R' : 'B';
  const groups = larr(x.actions).map(larr), flat = [].concat(...groups);
  const bans = flat.filter(a => a.type === 'ban');
  if (!bans.length) return null; // partie sans bans (blind pick) : rien à faire
  const simult = groups.length && groups[0].filter(a => a.type === 'ban').length > 1;
  const mode = simult ? 'flex' : 'tourn';
  const revealed = !simult || flat.some(a => a.type === 'ten_bans_reveal' && a.done) || flat.some(a => a.type === 'pick' && a.done);
  const champOf = {}, posOf = {};
  larr(x.myTeam).forEach(p => { champOf[p.cell] = p.champ; posOf[p.cell] = LCU_POS[String(p.pos || '').toLowerCase()] || null; });
  larr(x.theirTeam).forEach(p => { champOf[p.cell] = p.champ; });
  const q = {
    ['ban' + side]: bans.filter(a => a.ally && a.done).map(a => ({ id: a.champ || null })),
    ['ban' + other]: bans.filter(a => !a.ally && a.done).map(a => ({ id: a.champ || null })),
    ['pick' + side]: flat.filter(a => a.type === 'pick' && a.ally && a.done).map(a => ({ id: champOf[a.cell] || a.champ || null, cell: a.cell })),
    ['pick' + other]: flat.filter(a => a.type === 'pick' && !a.ally && a.done).map(a => ({ id: champOf[a.cell] || a.champ || null, cell: a.cell }))
  };
  const s0 = S.side; S.side = side; const seq = sequence(mode); S.side = s0;
  const fill = [], roles = {}, k = {};
  for (let i = 0; i < seq.length; i++) {
    const st = seq[i], key = st.t + st.s, n = k[key] || 0, list = q[key] || [];
    if (n >= list.length) break;                       // pas encore joué
    if (st.t === 'ban' && st.s !== side && !revealed) break; // bans adverses encore cachés
    const v = list[n]; k[key] = n + 1;
    const id = v.id && BY[v.id] ? v.id : null;
    if (st.t === 'pick' && !id) break;
    fill.push(id);
    if (st.t === 'pick' && st.s === side && posOf[v.cell]) roles[i] = posOf[v.cell];
  }
  return { mode, side, seq, fill, roles };
}

function autoApply(x) {
  const b = autoBuild(x); if (!b) return;
  const sig = JSON.stringify([b.mode, b.side, b.fill, b.roles]);
  if (sig === AUTO_LAST) return;
  AUTO_LAST = sig;
  const old = S.draft || { fill: [], roles: {} };
  // garde les rôles corrigés à la main tant que le champion n'a pas changé
  b.fill.forEach((id, i) => { if (b.roles[i] == null && old.fill[i] === id && old.roles && old.roles[i]) b.roles[i] = old.roles[i]; });
  S.mode = b.mode; S.side = b.side;
  S.draft = { seq: b.seq, fill: b.fill, roles: b.roles };
  // nos picks sans poste connu (partie personnalisée) : même règle qu'à la main
  b.seq.forEach((st, i) => {
    if (st.t !== 'pick' || st.s !== S.side || b.fill[i] == null || b.roles[i]) return;
    const mine = ourRoles(), c = BY[b.fill[i]], open = ROLES.filter(r => !mine[r]);
    b.roles[i] = open.find(r => playerOf(r).pool.includes(c.id)) || open.sort((p, q2) => share(c, q2) - share(c, p))[0];
  });
  IDC = { k: null, v: null };
  save();
  if (TAB === 'draft') safeRender();
}

async function autoPoll() {
  if (!AUTO_ON || AUTO_BUSY) return;
  AUTO_BUSY = true;
  try {
    const r = await fetch(RELAIS, { cache: 'no-store' });
    const x = await r.json();
    AUTO_ST = { ok: true, status: x.status || '', side: x.side || null };
    if (x.inCS) autoApply(x);
  } catch (e) { AUTO_ST = { ok: false, status: 'norelay', side: null }; }
  AUTO_BUSY = false;
  autoBadge();
}
function autoTxt() {
  if (!AUTO_ON) return '';
  if (!AUTO_ST.ok) return AUTO_ST.status === 'norelay' ? 'Relais introuvable : lance Draft-auto.bat sur ce PC (et autorise l’accès au réseau local si le navigateur le demande).' : 'Connexion au relais…';
  return { noclient: 'Relais OK, client LoL introuvable.', idle: 'Relais OK, en attente de la sélection des champions.', error: 'Relais OK, client injoignable pour l’instant.', start: 'Relais OK.', cs: `En direct depuis le client · côté ${AUTO_ST.side === 'R' ? 'rouge' : 'bleu'}` }[AUTO_ST.status] || 'Relais OK.';
}
function autoBadge() { const el = document.getElementById('autost'); if (el) { el.textContent = autoTxt(); el.className = 'autost ' + (AUTO_ST.ok && AUTO_ST.status === 'cs' ? 'live' : AUTO_ST.ok ? 'ok' : 'off'); } }
function autoControl() {
  if (!AUTO_OK_HERE) return '';
  return `<label class="chk" title="Remplit la draft toute seule depuis le client LoL (relais Draft-auto.bat lancé sur ce PC)"><input type="checkbox" id="autoon" ${AUTO_ON ? 'checked' : ''}> Draft auto (client LoL)</label><span id="autost" class="autost">${esc(autoTxt())}</span>`;
}
function autoBind() {
  const cb = document.getElementById('autoon'); if (!cb) return;
  cb.onchange = () => { AUTO_ON = cb.checked; AUTO_LAST = ''; try { localStorage.setItem('draftTool.auto', AUTO_ON ? '1' : '0'); } catch (e) { } AUTO_ST = { ok: false, status: '', side: null }; autoBadge(); if (AUTO_ON) autoPoll(); };
  autoBadge();
}
setInterval(autoPoll, 1000);
