# Version GitHub Pages : même outil + Firebase (synchro) + code d'équipe
import json, os, subprocess
subprocess.run(['python3','build.py'],check=True,capture_output=True)
html=open('index.html').read()
cfg=json.load(open('gh/firebase_config.json'))
head=open('gh/firebase_head.html').read().replace('__CONFIG__',json.dumps(cfg)).replace('window.FBSTORE_PROMISE =','window.SEED = '+open('gh/seed.json').read()+';\nwindow.FBSTORE_PROMISE =',1)
tail=open('gh/firebase_tail.html').read()
css=open('gh/extra.css').read()
i=html.index('<script>\n')
html=html[:i]+head+html[i:]
html=html.replace('</style>',css+'</style>',1)
j=html.rindex('</body>')
html=html[:j]+tail+html[j:]
os.makedirs('site',exist_ok=True)
open('site/index.html','w').write(html)
open('site/.nojekyll','w').write('')
print(len(html))
