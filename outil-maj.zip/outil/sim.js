// ===== Simulation des fins de draft =====
// Un pick vaut le winrate final moyen des drafts qu'il produit, notées par le modèle (mêmes termes que draftScore)
// + l'aisance déclarée de nos joueurs (choix de l'équipe : (note − 5) × 0,12 point).
// Adversaires : champions tirés selon les fréquences pros 2026 lissées vers les fréquences Master+ (α mesuré),
// counter-pick mesuré sur les parties pros réorientées (κ par rôle, sur l'écart de duel au-delà des forces).
// Rôle du pick adverse : en tournoi, selon la position du pick chez les pros ; en flex, l'ordre de pick n'est pas choisi.

// --- Score rapide : valeurs par champion et par paire, mises en cache ---
const FS = { f: new Map(), res: new Map(), lane: new Map(), A: new Map(), E: new Map(), fl: new Map(), fe: new Map() };
// force a priori (u.gg lissé, biais de sélection retiré), en points ; la correction apprise chPts est ajoutée à part
// clés numériques (plus rapides que des chaînes) : rôle = indice 0 à 4, champion = id < 4096
const RIX = { top: 0, jgl: 1, mid: 2, adc: 3, sup: 4 };
function fsF(c, r) { const k = c.id * 5 + RIX[r]; let v = FS.f.get(k); if (v == null) { v = (bwr0(c, r) - selBias(c, r) - 0.5) * 100; FS.f.set(k, v); } return v; }
// écart de duel au-delà des forces, prior seul (c'est aussi la mesure sur laquelle κ a été estimé)
function fsRes(a, b, r) { const k = (a.id * 4096 + b.id) * 5 + RIX[r]; let v = FS.res.get(k); if (v == null) { v = laneRes(a, b, r).res; FS.res.set(k, v); } return v; }
// duel de lane vu de a (même calcul que draftScore, poids recalé + correction apprise)
function fsLane(a, b, r) {
  const k = (a.id * 4096 + b.id) * 5 + RIX[r]; let v = FS.lane.get(k);
  if (v == null) { v = fsRes(a, b, r) * MODEL.mult[2] + mlLane(a, b, r); FS.lane.set(k, v); }
  return v;
}
function fsPair(s, a, ra, b, rb) {
  const M = FS[s], k = ((a.id * 5 + RIX[ra]) * 4096 + b.id) * 5 + RIX[rb]; let v = M.get(k);
  if (v == null) { v = styleVal(s, a, b).v + pairVal(s, a, LLANE[ra], b, LLANE[rb]); M.set(k, v); }
  return v;
}
// winrate final (points au-dessus de 50) de la compo M contre O, M et O complets ou partiels { rôle: champion }
function fastScore(M, O, sideOf) {
  const K = MODEL.mult; let v = 0;
  for (const r of ROLES) {
    const a = M[r], b = O[r];
    if (a) v += K[0] * fsF(a, r) + chPts(a, r) + presPts(a, r);
    if (b) v -= K[0] * fsF(b, r) + chPts(b, r) + presPts(b, r);
    if (a && b) v += fsLane(a, b, r);
  }
  const syn = X => { let s = 0; for (let i = 0; i < 5; i++) { const a = X[ROLES[i]]; if (!a) continue; for (let j = i + 1; j < 5; j++) { const b = X[ROLES[j]]; if (b && b.id !== a.id) s += (fsPair('A', a, ROLES[i], b, ROLES[j]) + fsPair('A', b, ROLES[j], a, ROLES[i])) / 2; } } return s; };
  const ctx = (X, Y) => { let s = 0; for (const ra of ROLES) { const a = X[ra]; if (!a) continue; for (const rb of ROLES) { const b = Y[rb]; if (b && rb !== ra) s += fsPair('E', a, ra, b, rb); } } return s; };
  v += K[1] * (syn(M) - syn(O)) + K[3] * (ctx(M, O) - ctx(O, M)) / 2;
  v += mlAllies(M) - mlAllies(O) + mlComp(M, O);
  const side = sideOf || S.side;
  // mode unique : modèle Master+ × mt + WR pro × mp (recalage sur les parties pros 2026), côté selon le format
  let pw = 0; for (const r of ROLES) { if (M[r]) pw += proWrPts(M[r]); if (O[r]) pw -= proWrPts(O[r]); }
  const sb = sideBlue();
  return wMt() * v + wMp() * pw + (side === 'R' ? -sb : sb);
}

// --- Aisance de nos joueurs : (note − 5) × 0,12 ; hors pool = note 0 ; dans le pool sans note = 5 ---
function comfortPts(c, r) {
  const p = playerOf(r); if (!p) return 0;
  if (!p.pool.includes(c.id)) return -0.6;
  const cf = comfortOf(r, c); return cf == null ? 0 : (cf - 5) * 0.12;
}

// --- Champions joués par rôle : picks pros 2026 + α × part Master+ (α choisi par vraisemblance des picks pros suivants) ---
const SIM_FIELD = {};
function simField() {
  const ref = 'mix';
  if (SIM_FIELD[ref]) return SIM_FIELD[ref];
  const F = SIM_FIELD[ref] = {};
  ROLES.forEach(r => {
    const totM = CH.reduce((s, c) => s + games(c, r), 0) || 1;
    const L = CH.map(c => ({ c, w: ((PRO26.freq[r] || {})[c.id] || 0) + PRO26.alpha * games(c, r) / totM })).filter(x => x.w > 0).sort((a, b) => b.w - a.w).slice(0, 40);
    const tot = L.reduce((s, x) => s + x.w, 0); L.forEach(x => x.p = x.w / tot);
    F[r] = L;
  });
  return F;
}
// valeur attendue d'un duel / d'une interaction contre un adversaire inconnu à ce rôle
function fieldLane(x, r) {
  const k = x.id * 5 + RIX[r]; let v = FS.fl.get(k);
  if (v == null) { v = 0; let sw = 0; simField()[r].forEach(o => { if (o.c.id === x.id) return; v += o.p * fsLane(x, o.c, r); sw += o.p; }); v /= sw || 1; FS.fl.set(k, v); }
  return v;
}
function fieldE(x, r, rb) {
  const k = (x.id * 5 + RIX[r]) * 5 + RIX[rb]; let v = FS.fe.get(k);
  if (v == null) { v = 0; let sw = 0; simField()[rb].forEach(o => { if (o.c.id === x.id) return; v += o.p * (fsPair('E', x, r, o.c, rb) - fsPair('E', o.c, rb, x, r)); sw += o.p; }); v /= sw || 1; FS.fe.set(k, v); }
  return v;
}
// gain attendu d'ajouter x au rôle r, pour la politique de nos picks futurs (adversaires inconnus = moyenne du terrain)
function addGain(x, r, M, O) { return gainCore(x, r, M, O) + comfortPts(x, r); }
// même gain sans l'aisance de nos joueurs : c'est aussi ce que l'adversaire cherche à maximiser, de son point de vue
function gainCore(x, r, M, O) { return wMt() * soloGain(x, r, M, O) + wMp() * proWrPts(x) + presPts(x, r); }
// gain selon le modèle Master+ seul (sans recalage pro ni WR pro) : validé sur nos parties solo et flex Master+
function soloGain(x, r, M, O) {
  const K = MODEL.mult; let v = K[0] * fsF(x, r) + chPts(x, r);
  for (const rb of ROLES) {
    const b = M[rb];
    if (b && rb !== r) v += K[1] * (fsPair('A', x, r, b, rb) + fsPair('A', b, rb, x, r)) / 2 + mlAlly(x, r, b, rb);
    if (rb === r) v += O[r] ? fsLane(x, O[r], r) : fieldLane(x, r);
    else if (O[rb]) v += K[3] * (fsPair('E', x, r, O[rb], rb) - fsPair('E', O[rb], rb, x, r)) / 2;
    else v += K[3] * fieldE(x, r, rb) / 2;
  }
  return v;
}

// --- Counters (solo queue) : quand l'adversaire de lane est connu, les champions classés par le modèle Master+ seul ---
// Affichés à côté du classement méta pro, seulement s'ils proposent autre chose que son top 3.
// metaTop : ids des 3 premiers du classement méta pour ce rôle. Renvoie null s'il n'y a rien à montrer.
// seuil d'affichage choisi par l'équipe : un counter n'est montré que si son duel repose sur au moins 50 parties
const COUNTER_MIN_G = 50;
function counterRecs(r, metaTop) {
  const mine = ourRoles(), en = enemyRoles().m, opp = en[r];
  if (!opp || mine[r]) return null;
  const p = playerOf(r), pool = new Set(p ? p.pool : []);
  const ev = c => { const w = wrVs(c, opp, r); return { c, pool: pool.has(c.id), solo: soloGain(c, r, mine, en), meta: gainCore(c, r, mine, en) + (pool.has(c.id) ? comfortPts(c, r) : 0), wr: w.wr, g: w.g }; };
  const inPool = CH.filter(c => pool.has(c.id) && available(c)).map(ev).filter(x => x.g >= COUNTER_MIN_G).sort((a, b) => b.solo - a.solo);
  const off = CH.filter(c => !pool.has(c.id) && available(c) && viable(c, r)).map(ev).filter(x => x.g >= COUNTER_MIN_G).sort((a, b) => b.solo - a.solo);
  const best = [...inPool.slice(0, 1), ...off.slice(0, 1)].sort((a, b) => b.solo - a.solo)[0];
  if (!best || (metaTop || []).includes(best.c.id)) return null;
  const keep = x => !(metaTop || []).includes(x.c.id);
  return { r, opp, pool: inPool.filter(keep).slice(0, 3), off: off.filter(keep).slice(0, 2) };
}

// --- Valeur d'un champion pour les compos : mêmes termes que addGain, décomposés pour l'affichage ---
// mine : nos champions déjà pickés (rôle → champion) ; en : champions adverses connus (rôle → champion)
function champParts(x, r, mine, en) {
  const K = MODEL.mult, mt = wMt(), p = { force: mt * (K[0] * fsF(x, r) + chPts(x, r)), lane: 0, syn: 0, vs: 0, pro: wMp() * proWrPts(x) + presPts(x, r), comf: comfortPts(x, r) };
  p.lane = mt * (en[r] ? fsLane(x, en[r], r) : fieldLane(x, r));
  for (const rb of ROLES) {
    if (rb === r) continue;
    const b = mine[rb];
    if (b) p.syn += mt * (K[1] * (fsPair('A', x, r, b, rb) + fsPair('A', b, rb, x, r)) / 2 + mlAlly(x, r, b, rb));
    p.vs += mt * (en[rb] ? K[3] * (fsPair('E', x, r, en[rb], rb) - fsPair('E', en[rb], rb, x, r)) / 2 : K[3] * fieldE(x, r, rb) / 2);
  }
  return p;
}
// valeur d'un champion seul (force + WR pro), pour trier les candidats hors pool
function champVal(c, r) { return wMt() * (MODEL.mult[0] * fsF(c, r) + chPts(c, r)) + wMp() * proWrPts(c) + presPts(c, r); }

// --- Tirage ---
function rng(seed) { let a = seed >>> 0; return () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
// counter-pick adverse : poids × exp(κ_rôle × écart de duel résiduel + κ'_rôle × force solo), mesurés sur les pros
// Tirage par « course exponentielle » : chaque option reçoit un nombre aléatoire fixé par (tirage, étape, option),
// la plus petite clé −ln(u)/poids gagne. Même loi qu'un tirage pondéré, mais retirer ou forcer un champion ne change
// les autres tirages que là où il aurait gagné : les comparaisons entre picks sont bien moins bruitées.
function hu(a, b, c) {
  let h = Math.imul(a ^ 0x9E3779B9, 0x85EBCA6B) ^ Math.imul(b + 0x632BE5AB, 0xC2B2AE35) ^ Math.imul(c + 0x27D4EB2F, 0x165667B1);
  h ^= h >>> 15; h = Math.imul(h, 0x2C1B3C6D); h ^= h >>> 12; h = Math.imul(h, 0x297A2D39); h ^= h >>> 15;
  return ((h >>> 0) + 0.5) / 4294967296;
}
function drawField(r, taken, key, vsLaner) {
  const L = simField()[r]; let best = null, bk = Infinity;
  const kr = (PRO26.kres || {})[r] || 0, ks = (PRO26.kstr || {})[r] || 0;
  for (const o of L) {
    if (taken.has(o.c.id)) continue;
    let w = o.p; if (vsLaner) w *= Math.exp(kr * fsRes(o.c, vsLaner, r) + ks * fsF(o.c, r));
    const k = -Math.log(hu(key[0], key[1], o.c.id)) / w;
    if (k < bk) { bk = k; best = o.c; }
  }
  return best;
}
function drawRole(open, pos, key) {
  let best = open[0], bk = Infinity;
  for (const r of open) {
    const w = S.mode === 'tourn' && pos ? (PRO26.posRole[pos - 1][ROLES.indexOf(r)] || 1) : 1;
    const k = -Math.log(hu(key[0], key[1] + 7919, ROLES.indexOf(r) + 1)) / w;
    if (k < bk) { bk = k; best = r; }
  }
  return best;
}
function ourOptions(r, taken) {
  const p = playerOf(r), pool = p ? p.pool.map(id => BY[id]).filter(c => c && !taken.has(c.id)) : [];
  return pool.length ? pool : simField()[r].slice(0, 6).map(o => o.c).filter(c => !taken.has(c.id));
}

// État de départ : nos picks et leurs picks connus, étapes de pick restantes
function simStart() {
  const M = Object.assign({}, ourRoles()), O = Object.assign({}, enemyRoles().m);
  const taken = new Set([...used(), ...locked()]);
  const steps = [];
  let np = 0;
  D().seq.forEach((st, i) => { if (st.t !== 'pick') return; np++; if (i >= D().fill.length) steps.push({ who: st.s === S.side ? 'us' : 'them', pos: np }); });
  // picks déjà faits sans rôle choisi : on les ignore dans la simulation
  return { M, O, taken, steps };
}
// Une fin de draft. force : { us: [champ, rôle] } pour notre prochain pick, { them: [champ, rôle] } pour leur prochain
function simOnce(st0, force, sample) {
  const M = Object.assign({}, st0.M), O = Object.assign({}, st0.O), taken = new Set(st0.taken);
  if (force && force.ban) taken.add(force.ban.id);
  let fUs = force && force.us, fThem = force && force.them;
  for (const step of st0.steps) {
    const who = step.who;
    if (who === 'us') {
      const open = ROLES.filter(r => !M[r]); if (!open.length) continue;
      if (fUs && !M[fUs[1]]) { M[fUs[1]] = fUs[0]; taken.add(fUs[0].id); fUs = null; continue; }
      if (SIM_OPT.us === 'terrain') { // test uniquement : notre équipe joue comme le terrain (pas comme l'outil le conseille)
        const key = [sample + 7777, step.pos], r = drawRole(open, step.pos, key), c = drawField(r, taken, key, O[r]);
        if (c) { M[r] = c; taken.add(c.id); } continue;
      }
      let best = null, bv = -1e9;
      for (const r of open) for (const c of ourOptions(r, taken)) { const g = addGain(c, r, M, O); if (g > bv) { bv = g; best = [c, r]; } }
      if (best) { M[best[1]] = best[0]; taken.add(best[0].id); }
    } else {
      const open = ROLES.filter(r => !O[r]); if (!open.length) continue;
      if (fThem && !O[fThem[1]]) { O[fThem[1]] = fThem[0]; taken.add(fThem[0].id); fThem = null; continue; }
      const key = [sample, step.pos];
      const r = drawRole(open, step.pos, key);
      const c = drawField(r, taken, key, M[r]); if (c) { O[r] = c; taken.add(c.id); }
    }
  }
  let v = fastScore(M, O);
  for (const r of ROLES) if (M[r]) v += comfortPts(M[r], r);
  return { v, M, O };
}
// 100 tirages (au lieu de 200) : la draft flex laisse 30 s pour deux picks ; l'ordre final est départagé par SIM_NP
const SIM_N = 100;
// option de test : 'terrain' fait jouer notre équipe comme le terrain adverse (sert à vérifier le modèle du monde de la simulation)
const SIM_OPT = { us: 'outil' };
let SIM_SEED = 1000;
const SIM_CACHE = new Map();
function simSig() { return JSON.stringify([S.side, S.mode, D().fill, D().roles, S.team.map(p => [p.pool, p.comf || null])]); }
function simKey(force) { return simSig() + JSON.stringify(force ? [force.us && [force.us[0].id, force.us[1]], force.them && [force.them[0].id, force.them[1]], force.ban && force.ban.id] : 0); }
function simValue(force) {
  const sig = simKey(force);
  if (SIM_CACHE.has(sig)) return SIM_CACHE.get(sig);
  const st0 = simStart(); let s = 0, s2 = 0;
  for (let i = 0; i < SIM_N; i++) {
    const o = simOnce(st0, force, SIM_SEED + i);
    s += o.v; s2 += o.v * o.v;
  }
  const m = s / SIM_N, out = { v: m, sd: Math.sqrt(Math.max(0, s2 / SIM_N - m * m)) };
  if (SIM_CACHE.size > 3000) SIM_CACHE.clear();
  SIM_CACHE.set(sig, out); return out;
}
// Calcul en arrière-plan : renvoie la valeur si elle est prête, sinon la met en file et renvoie null
const SIM_Q = []; let SIM_T = null; let SIM_PENDING = false;
function simGet(force) {
  const k = simKey(force); if (SIM_CACHE.has(k)) return SIM_CACHE.get(k);
  if (!SIM_Q.some(q => q.k === k)) SIM_Q.push({ k, force, sig: simSig() });
  SIM_PENDING = true;
  if (!SIM_T) SIM_T = setTimeout(simPump, 0);
  return null;
}
function simPump() {
  SIM_T = null; const t0 = Date.now(), sig = simSig();
  while (SIM_Q.length && Date.now() - t0 < 40) { const q = SIM_Q.shift(); if (q.sig !== sig) continue; simValue(q.force); }
  // puis les simulations longues qui départagent l'ordre des picks, par tranches de 40 ms
  while (!SIM_Q.length && SIMP_Q.length && Date.now() - t0 < 40) {
    const q = SIMP_Q[0]; if (q.sig !== sig) { SIMP_Q.shift(); continue; }
    if (!q.st0) { q.st0 = simStart(); q.a = new Float64Array(SIM_NP); q.i = 0; }
    while (q.i < SIM_NP && Date.now() - t0 < 40) { q.a[q.i] = simOnce(q.st0, q.force, SIM_SEED + q.i).v; q.i++; }
    if (q.i >= SIM_NP) { SIMP_Q.shift(); let m = 0; for (const x of q.a) m += x; if (SIMP.size > 500) SIMP.clear(); SIMP.set(q.k, { v: m / SIM_NP, a: q.a }); }
  }
  if (SIM_Q.length || SIMP_Q.length) SIM_T = setTimeout(simPump, 0);
  else { SIM_PENDING = false; if (typeof safeRender === 'function' && typeof TAB !== 'undefined' && TAB === 'draft') safeRender(); }
}
// Ordre des picks : avec 200 tirages, l'écart entre deux picks pris maintenant a une erreur d'environ 0,08 point de winrate,
// autant que les écarts eux-mêmes (garder Aurelion Sol ou Vayne pour le counter-pick vaut ~0,1 point). Pour départager,
// SIM_NP tirages (mêmes nombres aléatoires pour tous les picks, donc écarts appariés : erreur ≈ 0,05 point avec 400).
const SIM_NP = 400, SIMP = new Map(), SIMP_Q = [];
function simPrecise(force) {
  const k = simKey(force); if (SIMP.has(k)) return SIMP.get(k);
  if (!SIMP_Q.some(q => q.k === k)) SIMP_Q.push({ k, force, sig: simSig() });
  SIM_PENDING = true; if (!SIM_T) SIM_T = setTimeout(simPump, 0);
  return null;
}
// écart apparié a − b (moyenne et erreur type)
function simDiff(a, b) {
  const n = a.a.length; let m = 0, m2 = 0;
  for (let i = 0; i < n; i++) { const d = a.a[i] - b.a[i]; m += d; m2 += d * d; }
  m /= n; return { d: m, se: Math.sqrt(Math.max(0, m2 / n - m * m) / n) };
}
// Affine le classement d'une liste de picks {c, r, now} sur les simulations longues (si elles sont prêtes).
// Quand plusieurs picks ne se distinguent pas (écart apparié < 2 erreurs types avec le meilleur restant), on suit la forme
// de draft des pros : d'abord celui que les pros prennent le plus tôt (position moyenne de pick, ligues majeures 2026 :
// jungle et ADC tôt, mid et support ensuite, top et picks de counter à la fin).
function refineOrder(list) {
  const P = list.map(o => simPrecise({ us: [o.c, o.r] }));
  if (P.some(x => !x)) return { list, ready: false };
  const R = list.map((o, k) => ({ ...o, prec: P[k], ps: typeof proSlot === 'function' ? proSlot(o.c, o.r) : 5.5 }));
  const top = R.reduce((a, b) => b.prec.v > a.prec.v ? b : a), L = [];
  while (R.length) {
    const best = R.reduce((a, b) => b.prec.v > a.prec.v ? b : a);
    const same = R.filter(o => o === best || (() => { const x = simDiff(best.prec, o.prec); return x.d < 2 * x.se; })());
    const pick = same.reduce((a, b) => b.ps < a.ps ? b : a);
    pick.tie = same.length > 1; pick.byPro = pick !== best;
    L.push(pick); R.splice(R.indexOf(pick), 1);
  }
  L.forEach(o => { o.dv = o === top ? 0 : simDiff(o.prec, top.prec).d; });
  return { list: L, ready: true };
}
// Liste d'évaluations : valeur simulée pour toutes si elles sont prêtes, sinon gain attendu instantané pour toutes
function simUse(list) {
  const ready = list.length > 0 && list.every(e => e.sim != null);
  list.forEach(e => { e.score = ready ? e.sim : e.inst; e.simReady = ready; });
  return ready;
}
// Valeur d'un pick pour nous : winrate final attendu (en %)
function pickValue(c, r) { return 50 + simValue({ us: [c, r] }).v; }
// Picks adverses les plus dangereux pour notre compo : perte attendue = probabilité qu'ils le prennent × baisse de notre winrate
function dangerRecs(n) {
  const st0 = simStart(); if (!st0.steps.some(x => x.who === 'them')) return [];
  const base = simGet(null), res = [], avail = {};
  ROLES.forEach(r => avail[r] = simField()[r].reduce((s, o) => s + (st0.taken.has(o.c.id) ? 0 : o.p), 0) || 1);
  let ready = !!base;
  ROLES.filter(r => !st0.O[r]).forEach(r => {
    simField()[r].slice(0, 12).forEach(o => {
      if (st0.taken.has(o.c.id)) return;
      // probabilité qu'il soit joué à ce rôle : sa fréquence parmi les champions encore disponibles
      const p = o.p / avail[r];
      const sv = simGet({ them: [o.c, r] }); if (!sv || !base) { ready = false; return; }
      const drop = base.v - sv.v;
      if (drop > 0) res.push({ c: o.c, r, drop, p, loss: drop * p });
    });
  });
  if (!ready) return null;
  res.sort((a, b) => b.loss - a.loss);
  const seenC = new Set();
  return res.filter(x => !seenC.has(x.c.id) && seenC.add(x.c.id)).slice(0, n || 8);
}
// Bans : gain de notre winrate final si le champion est retiré de la draft (pour eux comme pour nous)
function banSimRecs(n) {
  const st0 = simStart(); if (!st0.steps.some(x => x.who === 'them')) return [];
  const base = simGet(null); let ready = !!base; const res = [], seen = new Set();
  ROLES.filter(r => !st0.O[r]).forEach(r => simField()[r].slice(0, 12).forEach(o => {
    if (st0.taken.has(o.c.id) || seen.has(o.c.id)) return; seen.add(o.c.id);
    const sv = simGet({ ban: o.c }); if (!sv || !base) { ready = false; return; }
    res.push({ c: o.c, r, gain: sv.v - base.v });
  }));
  if (!ready) return null;
  return res.filter(x => x.gain > 0).sort((a, b) => b.gain - a.gain).slice(0, n || 8);
}
function simReset() { FS.f.clear(); FS.res.clear(); FS.lane.clear(); FS.A.clear(); FS.E.clear(); FS.fl.clear(); FS.fe.clear(); delete SIM_FIELD.mix; SIM_CACHE.clear(); if (typeof SIMP !== "undefined") { SIMP.clear(); SIMP_Q.length = 0; } }

// ===== Objets conseillés une fois la draft terminée =====
// Effet de chaque objet sur la victoire, mesuré à nombre d'objets finis et durée de partie égaux (data/items.json) :
// effet de base selon la classe du champion (AD / AP / tank) + écart propre au champion à ce rôle
// + effet selon le profil de la compo adverse (seulement si la mesure l'a retenu). Pas d'ordre d'achat : il n'est pas mesuré.
function itemCls(c) { return ({ AD: 0, AP: 1, T: 2 })[c.d] ?? 0; }
function enemyCounts(en) {
  const v = [0, 0, 0, 0, 0, 0, 0, 0, 0];
  en.forEach(e => { const t = ITEMS.traits && ITEMS.traits[e.id]; if (!t) return; const d = t.slice(0, -6); v[0] += d === 'AP'; v[1] += d === 'AD'; v[2] += d === 'T'; for (let i = 0; i < 6; i++) v[3 + i] += +t[t.length - 6 + i]; });
  return v;
}
// seuil d'affichage : un objet n'est conseillé que si au moins 200 joueurs de ce champion à ce rôle l'ont fini
const ITEM_MIN_N = 200;
function itemRecs(c, r, enemies) {
  if (typeof ITEMS === 'undefined' || !ITEMS) return null;
  const k = c.id + '|' + r, use = ITEMS.use[k]; if (!use) return null;
  const cl = itemCls(c), base = ITEMS.base[cl + '|' + r] || {}, ch = ITEMS.ch[k] || {};
  const ec = ITEMS.inter ? enemyCounts(enemies || []) : null;
  const nk = ITEMS.n[k] || 0;
  const list = Object.keys(use).filter(id => use[id] * nk >= ITEM_MIN_N).map(id => {
    const cat = ITEMS.cat[id]; if (!cat) return null;
    let v = (base[id] || 0) + (ch[id] || 0), vs = 0;
    const g = ec && ITEMS.inter[cl] && ITEMS.inter[cl][id]; if (g) g.forEach((x, j) => vs += x * (ec[j] - ITEMS.mu[j]));
    return { id: +id, n: cat[0], gold: cat[1], c: cat[2], use: use[id], v: v + vs, vs };
  }).filter(Boolean);
  // écart à l'objet moyen de ce champion (pondéré par l'usage), à part pour les bottes et les objets finis
  for (const kind of ['B', 'L']) {
    const L = list.filter(x => x.c === kind), sw = L.reduce((s, x) => s + x.use, 0) || 1, m = L.reduce((s, x) => s + x.use * x.v, 0) / sw;
    L.forEach(x => x.rel = x.v - m);
  }
  return { boots: list.filter(x => x.c === 'B').sort((a, b) => b.rel - a.rel).slice(0, 2), legs: list.filter(x => x.c === 'L').sort((a, b) => b.rel - a.rel).slice(0, 6), n: ITEMS.n[k] || 0 };
}

// ===== Objets situationnels selon la compo adverse =====
// Règles de jeu écrites à la main (ce ne sont PAS des mesures : nos données ne montrent pas d'effet mesurable de la compo
// adverse sur la valeur des objets). Chaque règle dit pour quel type de champion elle vaut et dans quelle situation.
const SUPPRESSION = new Set(['Malzahar', 'Warwick', 'Skarner', 'Urgot']);
function itemArch(c, r) {
  const p = (c.t || '').split('/')[0], a = new Set();
  if (r === 'sup') { if (p === 'Tank') a.add('SUP_TANK'); else if (p === 'Support' || p === 'Mage') a.add('ENCHANTER'); }
  if (p === 'Marksman' || r === 'adc') a.add('MARKSMAN');
  if ((p === 'Mage' || (c.d === 'AP' && r === 'mid')) && r !== 'sup') a.add('MAGE');
  if (p === 'Assassin' && c.d === 'AP') a.add('AP_ASSA');
  if ((p === 'Fighter' || p === 'Assassin') && c.d === 'AD' && r !== 'adc') a.add('AD_MELEE');
  if ((p === 'Tank' || c.d === 'T') && r !== 'sup' && !a.has('MAGE')) a.add('TANK');
  return a;
}
function enemyProfile(en) {
  const T = (typeof ITEMS !== 'undefined' && ITEMS && ITEMS.traits) || {}, f = k => en.reduce((s, e) => { const t = T[e.id]; return s + (t ? +t[t.length - 6 + k] : 0); }, 0);
  return {
    supp: en.filter(e => SUPPRESSION.has(e.n)).map(e => e.n), nAP: en.filter(e => e.d === 'AP').length, nAD: en.filter(e => e.d === 'AD').length, nT: en.filter(e => e.d === 'T').length,
    cc: f(0), tank: f(1), burst: f(2), heal: f(3), shield: f(4), auto: f(5),
    engage: en.filter(e => tv(e, 'e') >= 2 || tv(e, 'd') >= 3).length, pick: en.filter(e => tv(e, 'k') >= 2).length
  };
}
// [objet, types de champions concernés, condition (renvoie la raison affichée, ou rien)]
const SITU = [
  [3139, ['MARKSMAN', 'AD_MELEE'], (P, A) => (P.supp.length && `contre ${P.supp.join(', ')} (suppression)`) || (A.has('MARKSMAN') && P.nAP >= 3 && 'beaucoup de dégâts magiques')],
  // type de dégâts : résistance magique contre une compo surtout AP, armure contre une compo (presque) full AD
  [3111, ['MAGE', 'AP_ASSA', 'AD_MELEE', 'TANK', 'SUP_TANK', 'ENCHANTER'], P => (P.nAP >= 3 && 'beaucoup de dégâts magiques') || (P.cc >= 3 && 'beaucoup de contrôle en face')],
  [3047, ['TANK', 'AD_MELEE', 'SUP_TANK', 'MARKSMAN', 'ENCHANTER'], P => (P.nAD >= 4 && 'beaucoup de dégâts physiques') || (P.auto >= 3 && 'beaucoup d’attaques de base')],
  [3102, ['MAGE', 'AP_ASSA'], P => (P.nAP >= 3 && 'beaucoup de dégâts magiques') || ((P.pick >= 2 || P.burst >= 2) && 'contre les picks et le burst')],
  [3157, ['MAGE', 'AP_ASSA'], P => (P.nAD >= 4 && 'beaucoup de dégâts physiques') || (P.engage >= 2 && 'contre l’engage et le dive')],
  [3026, ['MARKSMAN'], P => P.nAD >= 4 && 'beaucoup de dégâts physiques'],
  [3156, ['AD_MELEE'], P => P.nAP >= 3 && 'beaucoup de dégâts magiques'],
  [3091, ['MARKSMAN', 'AD_MELEE'], P => P.nAP >= 3 && 'beaucoup de dégâts magiques'],
  [6333, ['AD_MELEE'], P => (P.nAD >= 4 && 'beaucoup de dégâts physiques') || (P.burst >= 2 && 'contre le burst physique')],
  [4401, ['TANK'], P => P.nAP >= 3 && 'beaucoup de dégâts magiques'],
  [2504, ['TANK', 'AD_MELEE'], P => P.nAP >= 3 && 'beaucoup de dégâts magiques'],
  [3190, ['SUP_TANK'], P => P.nAP >= 3 && 'beaucoup de dégâts magiques'],
  [8020, ['TANK', 'SUP_TANK'], P => P.nAP >= 3 && 'beaucoup de dégâts magiques'],
  [3143, ['TANK', 'SUP_TANK'], P => (P.nAD >= 4 && 'beaucoup de dégâts physiques') || (P.auto >= 3 && 'beaucoup d’attaques de base')],
  [3110, ['TANK', 'SUP_TANK'], P => (P.nAD >= 4 && 'beaucoup de dégâts physiques') || (P.auto >= 3 && 'beaucoup d’attaques de base')],
  // contrôle, engage, picks, soins, tanks, boucliers
  [3222, ['ENCHANTER'], P => (P.supp.length || P.cc >= 3) && 'beaucoup de contrôle en face'],
  [3814, ['AD_MELEE'], P => (P.pick >= 2 || P.burst >= 2) && 'contre les picks et le burst'],
  [6673, ['MARKSMAN'], P => (P.burst >= 2 || P.engage >= 2) && 'contre le burst et le dive'],
  [3033, ['MARKSMAN'], P => P.heal >= 2 && 'beaucoup de soins en face'],
  [6609, ['AD_MELEE'], P => P.heal >= 2 && 'beaucoup de soins en face'],
  [3165, ['MAGE', 'AP_ASSA'], P => P.heal >= 2 && 'beaucoup de soins en face'],
  [3075, ['TANK', 'SUP_TANK'], P => (P.heal >= 2 && 'beaucoup de soins en face') || (P.auto >= 3 && 'beaucoup d’attaques de base')],
  [3036, ['MARKSMAN'], P => (P.nT >= 2 || P.tank >= 2) && 'plusieurs tanks en face'],
  [3135, ['MAGE', 'AP_ASSA'], P => (P.nT >= 2 || P.tank >= 2) && 'plusieurs tanks en face'],
  [3071, ['AD_MELEE'], P => (P.nT >= 2 || P.tank >= 2) && 'plusieurs tanks en face'],
  [6695, ['MARKSMAN', 'AD_MELEE'], P => P.shield >= 2 && 'beaucoup de boucliers en face']
];
function situationalItems(c, r, enemies, max = 5) {
  if (typeof ITEMS === 'undefined' || !ITEMS || !enemies || !enemies.length) return [];
  const A = itemArch(c, r), P = enemyProfile(enemies), rec = itemRecs(c, r, enemies), meas = {};
  if (rec) [...rec.boots, ...rec.legs].forEach(x => meas[x.id] = x.rel);
  const out = [];
  for (const [id, who, cond] of SITU) {
    if (!who.some(w => A.has(w))) continue;
    const why = cond(P, A); if (!why) continue;
    const cat = ITEMS.cat[id]; if (!cat) continue;
    out.push({ id, n: cat[0], why, rel: meas[id] });
    if (out.length >= max) break;
  }
  return out;
}
