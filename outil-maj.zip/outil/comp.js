// ===== Compositions : archétypes, compo idéale, bans dérivés, plan de jeu =====
// tr = [engage, peel, pick, poke, dive, frontline, split, waveclear, courbe, hypercarry, mobilité, portée, push, anti-tank, armure, RM, zone]
const TI = { e: 0, p: 1, k: 2, o: 3, d: 4, f: 5, s: 6, w: 7, c: 8, h: 9, m: 10, g: 11, u: 12, a: 13, x: 14, y: 15, t: 16 };
const ARCH = {
  engage: 'Engage / teamfight', pick: 'Pick', poke: 'Poke / siège', protect: 'Protéger le carry', dive: 'Dive', split: 'Split push (1-3-1)'
};
let OPT = { offPool: false };

// ===== Styles de jeu proposés dans l'onglet Compos =====
// note de style calculée sur les profils (0 à 3) des 5 champions
const STYLES = {
  teamfight: 'Teamfight', poke: 'Poke', s131: '1-3-1', split: 'Split push (1-4)', early: 'Early game',
  scaling: 'Scaling', f2b: 'Front to back', solo: 'Solo carry'
};
const STYLE_TXT = {
  teamfight: 'Forcer des combats à 5 : engage, dégâts de zone, frontline.',
  poke: 'Affaiblir de loin avant l’objectif ou la tour, puis prendre sans combat.',
  s131: 'Deux side lanes qui gagnent leur duel, trois au milieu qui tiennent.',
  split: 'Un joueur qui pousse seul pendant que quatre tiennent ou menacent de l’autre côté.',
  early: 'Gagner tôt : lanes fortes, dive et objectifs avant que l’adversaire ne scale.',
  scaling: 'Tenir l’early, gagner après deux ou trois objets.',
  f2b: 'Frontline devant, carry derrière qui frappe ce qui arrive.',
  solo: 'Tout autour d’un carry : les quatre autres le protègent ou lui créent l’espace.'
};
const carryPow = c => 2 * tv(c, 'h') + tv(c, 'd') + 0.5 * tv(c, 'm') + (c.d !== 'T' ? 1 : 0) + (tv(c, 'c') === 2 ? 0.5 : 0);
function styleScore(st, cs) {
  const t = traitsSum(cs);
  const side = cs.slice(0, 4).filter(Boolean).map(c => tv(c, 's')).sort((a, b) => b - a);
  switch (st) {
    case 'teamfight': return Math.min(t.e, 8) + 0.8 * t.t + 0.4 * t.f + 0.2 * t.p;
    case 'poke': return t.o + 0.4 * t.w + 0.3 * t.p + 0.2 * t.g - 0.3 * t.d;
    case 's131': return t.sMin2 >= 2 ? 1.6 * t.s2 + 0.3 * t.w + 1 : 0.4 * t.s2;
    case 'split': return (side[0] || 0) >= 3 ? 2 * side[0] + 0.4 * t.w + 0.3 * t.p + 0.2 * t.u : 0.6 * (side[0] || 0);
    case 'early': return (1.1 - t.c) * 7 + 0.4 * (t.d + t.k) + 0.3 * t.u + 0.2 * t.e;
    case 'scaling': return (t.c - 0.8) * 7 + 2.5 * t.h + 0.2 * t.w + 0.2 * t.p;
    case 'f2b': { const ranged = cs.filter(c => c && c.d !== 'T' && tv(c, 'g') >= 2).length; return 0.5 * t.f + 0.8 * t.p + 1.2 * Math.min(ranged, 2) + 1.5 * (t.h ? 1 : 0) + 0.3 * t.t - 0.4 * t.d; }
    case 'solo': { const cp = cs.filter(Boolean).map(carryPow).sort((a, b) => b - a); return 1.6 * (cp[0] || 0) - 0.5 * Math.max(0, (cp[1] || 0) - 4) + 0.5 * t.p + 0.3 * t.f; }
  }
  return 0;
}
// champions qui portent chaque style (proposés en plus du pool si besoin)
const STYLE_T = {
  teamfight: c => tv(c, 'e') >= 2 || tv(c, 't') >= 2, poke: c => tv(c, 'o') >= 2, s131: (c, r) => r !== 'sup' && tv(c, 's') >= 2,
  split: (c, r) => (r !== 'sup' && tv(c, 's') >= 3) || tv(c, 'w') >= 2 || tv(c, 'p') >= 2, early: c => tv(c, 'c') === 0 || tv(c, 'd') >= 2,
  scaling: c => tv(c, 'c') === 2 || tv(c, 'h') >= 1, f2b: c => tv(c, 'f') >= 2 || tv(c, 'p') >= 2 || tv(c, 'h') >= 1, solo: c => tv(c, 'h') >= 1 || tv(c, 'd') >= 3 || tv(c, 'p') >= 2
};
// aisance du joueur sur un champion : note sur 10 si donnée, sinon ordre du pool
function comfortOf(r, c) {
  const p = playerOf(r); if (!p) return null;
  const k = p.pool.indexOf(c.id); if (k < 0) return null;
  const v = p.comf && p.comf[c.id];
  return v == null || v === '' ? null : +v;
}
function comfortBonus(r, c, scale) {
  const pk = poolRank(r, c); if (pk < 0) return -3;
  const cf = comfortOf(r, c);
  if (cf != null) return (cf - 5) * (scale || 0.7);
  return pk === 0 ? 2.5 : pk === 1 ? 2 : pk === 2 ? 1.5 : 1;
}
const wantOf = (r, c) => { const p = playerOf(r); return !!(p && p.want && p.want.includes(c.id)); };

function traitsSum(cs) {
  const s = { e: 0, p: 0, k: 0, o: 0, d: 0, f: 0, s: 0, w: 0, c: 0, h: 0, m: 0, g: 0, u: 0, a: 0, x: 0, y: 0, t: 0, n: 0, AD: 0, AP: 0, T: 0, ass: 0 };
  cs.forEach(c => {
    if (!c) return;
    for (const k in TI) s[k] += c.tr[TI[k]];
    s.n++; s[c.d]++;
    if (c.tr[TI.d] >= 3) s.ass++;
  });
  // 1-3-1 : ce qui compte, ce sont les deux meilleurs side laners, pas la somme sur 5
  // (pour une compo rangée par rôle, le support ne compte pas comme side laner)
  const sv = (cs.length === 5 ? cs.slice(0, 4) : cs).filter(Boolean).map(c => c.tr[TI.s]).sort((a, b) => b - a);
  s.s2 = (sv[0] || 0) + (sv[1] || 0); s.sMin2 = sv[1] || 0;
  if (s.n) s.c /= s.n;
  return s;
}
function archScores(t) {
  return {
    engage: Math.min(t.e, 8) + 0.5 * t.f + 0.2 * t.w,
    pick: t.k + 0.5 * t.d,
    poke: t.o + 0.4 * t.w + 0.3 * t.p,
    protect: t.p + (t.h ? 2.5 : 0) + 0.3 * t.f,
    dive: t.d + 0.5 * t.e,
    split: t.sMin2 >= 2 ? 1.6 * t.s2 + 0.3 * t.w + 1 : 0.5 * (t.s2 || 0)
  };
}
function identity(t) {
  const a = archScores(t);
  const ks = Object.keys(a).sort((x, y) => a[y] - a[x]);
  return { main: ks[0], second: ks[1], a };
}
const BEATS = {
  engage: { poke: 2, split: 1, protect: -1.5 },
  poke: { protect: 1.5, split: 1, engage: -2, dive: -2 },
  protect: { dive: 2, engage: 1.5, pick: 1, poke: -1.5 },
  dive: { poke: 2, pick: 0.5, protect: -2 },
  pick: { poke: 1, split: 1, protect: -1 },
  split: { protect: 1, pick: -1, engage: -1 }
};
// Cohérence d'une compo de 5 (ou partielle) : identité claire, frontline, engage ou peel, dégâts mixtes, waveclear
function coherence(cs, enemyCs) {
  const t = traitsSum(cs), id = identity(t);
  const full = t.n === 5;
  let sc = 0.6 * id.a[id.main] + 0.2 * id.a[id.second];
  const pen = [];
  if (full || t.n >= 4) {
    if (t.f < 3) { sc -= 1.5; pen.push('peu de frontline'); }
    if (t.e < 2 && t.p < 3) { sc -= 1; pen.push('ni engage ni peel'); }
    const dmg = t.AD + t.AP;
    if (t.AD >= 4 || t.AP >= 4) { sc -= 1.5; pen.push(`dégâts presque tous ${t.AD >= 4 ? 'AD' : 'AP'}`); }
    else if (dmg >= 3 && (t.AD === 0 || t.AP === 0)) { sc -= 0.5; pen.push(`aucun dégât ${t.AD === 0 ? 'AD' : 'AP'}`); }
    if (t.w < 2) { sc -= 0.5; pen.push('peu de waveclear'); }
    if (t.h && t.p < 2) { sc -= 1; pen.push('hypercarry sans protection'); }
  }
  let vs = 0, eid = null;
  const es = (enemyCs || []).filter(Boolean);
  if (es.length >= 2) {
    const et = traitsSum(es); eid = identity(et);
    vs += 0.5 * (BEATS[id.main][eid.main] || 0);
  }
  return { sc: sc + vs, id, t, pen, vs, eid };
}

// Valeur individuelle d'un champion à un rôle (méta solo queue, pro, confort, lane si l'adversaire est connu)
function indiv(c, r, enemyM) {
  // Force : en blind, valeur contre la population (et ses pires counters) ; adversaire connu, le duel lui-même.
  // Hors pool, le winrate est pondéré par la popularité du champion (un winrate porté par quelques spécialistes ne se transfère pas).
  const known = enemyM && enemyM[r];
  const pk = poolRank(r, c);
  let v = (known ? wrVs(c, enemyM[r], r).wr - 0.5 : blindVal(c, r) - 0.5) * 100 * 0.8 * SQW() * (pk < 0 ? reliab(c, r) : 1);
  v += PROW() * proPrio(c, r);
  v += comfortBonus(r, c);
  if (enemyM && Object.keys(enemyM).length) v += ctxFit(c, r, {}, enemyM).v;
  return v;
}

// Candidats par rôle : pick déjà fait, sinon pool disponible (+ hors pool si option ou pool vide)
// Champions qui portent chaque style (pour proposer une compo d'un style même si les pools n'y poussent pas)
const ARCH_T = { engage: c => tv(c, 'e') >= 2, pick: c => tv(c, 'k') >= 2, poke: c => tv(c, 'o') >= 2, protect: c => tv(c, 'p') >= 2 || tv(c, 'h') >= 1, dive: c => tv(c, 'd') >= 2, split: (c, r) => r !== 'sup' && tv(c, 's') >= 2 };
// Le score d'une compo est la somme des valeurs individuelles (mêmes parts que la simulation, aisance comprise)
// plus des synergies de paires, petites : on garde donc par rôle les meilleurs champions selon leur valeur seule,
// quel que soit leur rang dans le pool (avant, seuls les 9 premiers du pool comptaient et les hors pool passaient à la trappe).
const CAND_POOL = 7, CAND_OFF = 3, CAND_MAX = 10;
function candidates(r, mine, arch, o) {
  o = o || {};
  if (mine[r]) return [mine[r]];
  if (o.lock && o.lock[r]) return available(o.lock[r]) ? [o.lock[r]] : [];
  const p = playerOf(r);
  // envies du jour : si le joueur en a donné, on ne part que de celles-là (option « seulement les envies »)
  if (o.onlyWant && p && p.want && p.want.length) { const wl = p.want.map(id => BY[id]).filter(c => c && available(c)); if (wl.length) return wl; }
  const em = enemyRoles().m;
  const VC = new Map();
  const val = c => { let v = VC.get(c.id); if (v == null) { const q = champParts(c, r, mine, em); v = q.force + q.lane + q.syn + q.vs + q.pro + q.comf; VC.set(c.id, v); } return v; };
  const best = (l, n) => l.slice().sort((a, b) => val(b) - val(a)).slice(0, n);
  const inPool = c => p.pool.includes(c.id);
  // toujours candidats : la direction choisie dans l'onglet Compos (même hors pool) et les envies du jour
  const pin = [];
  const tg = S.target && BY[S.target.ids[ROLES.indexOf(r)]];
  if (tg && available(tg)) pin.push(tg);
  (p.want || []).forEach(id => { const c = BY[id]; if (c && available(c) && !pin.includes(c)) pin.push(c); });
  const pool = p.pool.map(id => BY[id]).filter(c => c && available(c) && !pin.includes(c));
  let list = pin.concat(best(pool, Math.max(CAND_POOL - pin.length, 3)));
  // hors pool : champions joués à ce rôle (Master+ ou pros), présélectionnés sur leur force puis classés comme les autres
  const metaOK = (c, minPr) => (viable(c, r) && share(c, r) >= 0.2 && pr(c, r) >= minPr) || proRole(c, r).pick >= 0.04;
  if (OPT.offPool || !pool.length) {
    const extra = CH.filter(c => available(c) && !inPool(c) && !list.includes(c) && metaOK(c, 0.015))
      .sort((a, b) => champVal(b, r) - champVal(a, r)).slice(0, 12);
    list = list.concat(best(extra, pool.length ? CAND_OFF : CAND_OFF + 2));
  }
  // style ou archétype demandé : on ajoute les meilleurs champions qui le portent (pool d'abord)
  // (hors pool seulement si l'option est cochée ou si le pool est vide)
  let fits = [];
  const addFit = (ok, n) => {
    const fp = pool.filter(c => !list.includes(c) && !fits.includes(c) && ok(c, r));
    const fo = OPT.offPool || !pool.length ? CH.filter(c => available(c) && !inPool(c) && !list.includes(c) && !fits.includes(c) && ok(c, r) && metaOK(c, 0.01))
      .sort((a, b) => champVal(b, r) - champVal(a, r)).slice(0, 8) : [];
    fits = fits.concat(best(fp, n), best(fo, n));
  };
  if (o.style && STYLE_T[o.style]) addFit(STYLE_T[o.style], 2);
  if (arch && ARCH_T[arch]) addFit(ARCH_T[arch], 2);
  // plafond (temps de calcul) : les épinglés, puis les meilleurs, puis les champions du style demandé
  const base = pin.concat(best(list.filter(c => !pin.includes(c)), Math.max(3, CAND_MAX - fits.length - pin.length)));
  return base.concat(fits.filter(c => !base.includes(c)));
}

// Toutes les compos possibles, classées par le même modèle que la simulation :
// gain attendu de chaque champion (force, duel contre l'adversaire connu ou le terrain, compo contre compo, WR pro, aisance)
// + synergies entre les champions de la compo. Les préférences de l'équipe (compo visée, envies du jour, style demandé)
// s'ajoutent à part, dans la colonne « Choix ».
function bestComps(limit = 5, o = {}) {
  const TG = o.target && S.target ? S.target : null;
  const mine = ourRoles();
  const em = enemyRoles().m;
  const ens = Object.values(em);
  const STY = o.style || (TG && TG.style) || null;
  const K = MODEL.mult, mt = PRO26.mt;
  const cand = ROLES.map(r => candidates(r, mine, o.arch, o).map(c => ({ c, p: mine[r] ? null : champParts(c, r, mine, em), want: !mine[r] && wantOf(r, c) ? 3 : 0 })));
  if (cand.some(l => !l.length)) return [];
  // synergie d'une paire de nouveaux champions (rôles i < j), mise en cache
  const PC = new Map();
  const pairV = (i, a, j, b) => { const k = i + '|' + a.id + '|' + j + '|' + b.id; let v = PC.get(k); if (v == null) { const ri = ROLES[i], rj = ROLES[j]; v = mt * (K[1] * (fsPair('A', a, ri, b, rj) + fsPair('A', b, rj, a, ri)) / 2 + mlAlly(a, ri, b, rj)); PC.set(k, v); } return v; };
  const res = [];
  const cur = [];
  (function rec(i, used) {
    if (i === 5) {
      const cs = cur.map(x => x.c);
      // cohérence (identité, plan) : calculée seulement quand elle sert, c'est l'étape la plus coûteuse
      const co = o.arch || (TG && !TG.style) ? coherence(cs, ens) : null;
      if (o.arch && co.id.main !== o.arch) return;
      const parts = { force: 0, lane: 0, syn: 0, vs: 0, pro: 0, comf: 0, choix: 0 };
      cur.forEach((x, k) => {
        if (x.p) { for (const f of ['force', 'lane', 'syn', 'vs', 'pro', 'comf']) parts[f] += x.p[f]; }
        parts.choix += x.want;
        for (let j = k + 1; j < 5; j++) if (x.p && cur[j].p) parts.syn += pairV(k, x.c, j, cur[j].c);
      });
      if (TG) { cs.forEach((x, k) => { if (x.id === TG.ids[k]) parts.choix += 2.5; }); if (!TG.style && co.id.main === TG.arch) parts.choix += 3; }
      const ss = STY ? styleScore(STY, cs) : 0;
      const model = parts.force + parts.lane + parts.syn + parts.vs + parts.pro + parts.comf;
      res.push({ cs: cs.slice(), parts, model, co, score: model + parts.choix, cslot: -1, ss });
      return;
    }
    for (const x of cand[i]) {
      if (used.has(x.c.id)) continue;
      used.add(x.c.id); cur.push(x);
      rec(i + 1, used);
      used.delete(x.c.id); cur.pop();
    }
  })(0, new Set());
  // Style demandé : on garde les compos qui l'incarnent le mieux (tiers supérieur) et le style compte dans le choix
  if (STY && res.length) {
    const v = res.map(x => x.ss), m = v.reduce((a, b) => a + b, 0) / v.length, sd = Math.sqrt(v.reduce((a, b) => a + (b - m) * (b - m), 0) / v.length) || 1;
    res.forEach(x => { x.sz = (x.ss - m) / sd; x.stb = (o.style ? 2.5 : 1.5) * x.sz; x.parts.choix += x.stb; x.score += x.stb; });
    if (o.style) { const keep = res.filter(x => x.sz >= 0.5); if (keep.length) { res.length = 0; res.push(...keep); } }
  }
  res.sort((a, b) => b.score - a.score);
  const coOf = x => x.co || (x.co = coherence(x.cs, ens));
  // Diversité : on garde des compos qui diffèrent d'au moins 2 champions ou d'identité
  const out = [];
  for (const r of res) {
    if (out.every(x => (!o.style && coOf(x).id.main !== coOf(r).id.main) || r.cs.filter((c, i) => c !== x.cs[i]).length >= 2)) out.push(r);
    if (out.length >= limit) break;
  }
  out.forEach(coOf);
  return out;
}

// Bans dérivés de la compo idéale : counters des pièces encore à picker + menaces méta
function compBans(ideal, phase) {
  const mine = ourRoles(), em = enemyRoles().m;
  const redFirst = S.side === 'R';
  phase = phase || 1;
  // phase 2 : bans ciblés (counters de notre compo, ce qui manque à la leur) plutôt que méta
  const wMeta = (redFirst ? 1.2 : 0.9) * (phase === 2 ? 0.7 : 1), wCnt = (redFirst ? 0.9 : 1.3) * (phase === 2 ? 1.4 : 1);
  const res = [];
  const ourM = {}; ROLES.forEach((r, i) => { const x = mine[r] || (ideal && ideal.cs[i]); if (x) ourM[r] = x; });
  const keep = new Set(Object.values(ourM).map(x => x.id));
  CH.forEach(x => {
    if (!available(x) || inAnyPool(x) || keep.has(x.id)) return;
    let best = null;
    ROLES.forEach(r => {
      if (em[r] || !viableP(x, r)) return;
      const pro = proRole(x, r);
      const sh = Math.max(share(x, r), pro.pick > 0 ? 0.8 : 0);
      const lik = Math.pow(Math.min(1, (pr(x, r) + banRate(x) * share(x, r) + PROW() * 0.6 * pro.pres) / 0.06), 0.75);
      const meta = power(x, r, true);
      let cnt = 0, why = '';
      const ourC = mine[r] || (ideal && ideal.cs[ROLES.indexOf(r)]);
      if (ourC) {
        const v = wrVs(ourC, x, r);
        cnt = Math.max(0, (0.5 - v.wr) * 100) * (mine[r] ? 2 : 1.6);
        if (cnt > 0.5) why = `counter ${ourC.n}${mine[r] ? '' : (S.target ? ' (compo visée)' : ' (compo idéale)')} : ${pct(1 - v.wr)} pour lui`;
      }
      // Ce champion punit-il notre compo entière (full AD, carries immobiles, pas de dépush…) ?
      const fit = Object.keys(ourM).length ? ctxFit(x, r, em, ourM) : { v: 0, items: [] };
      const cmp = Math.max(0, fit.v);
      // en tournoi, ce que les pros prennent ou bannissent à ce rôle passe devant
      // bans des pros à cette phase (Nocturne, Vi… en phase 1 ; bans ciblés comme Renekton ou Nautilus en phase 2)
      const pb = pdBan(x), pbs = pb ? 8 * (phase === 2 ? pb.b2 : pb.b1) / PRODRAFT.games * (proRef() ? 1 : 0.4) : 0;
      const sc = (wMeta * meta + (proRef() ? 2 : 0.4) * proPrio(x, r) + pbs + wCnt * (cnt + 1.5 * cmp)) * (0.4 + 0.6 * sh) * lik;
      if (!best || sc > best.sc) best = { sc, r, why, fitWhy: cmp > 0.6 ? fit.items.filter(i => i.x > 0.3).slice(0, 2).map(i => `${fmtp(i.x)} ${i.txt}`) : [] };
    });
    if (best) res.push({ c: x, ...best });
  });
  res.sort((a, b) => b.sc - a.sc);
  const cnt = {}; res.forEach(o => { o.sc *= Math.pow(0.85, cnt[o.r] || 0); cnt[o.r] = (cnt[o.r] || 0) + 1; });
  res.sort((a, b) => b.sc - a.sc);
  return res.slice(0, 8).map(o => {
    const why = [`${RL[o.r]} : ${pct(bwr(o.c, o.r))} de WR, ${pct(pr(o.c, o.r))} de pick`];
    if (proTxt(o.c, o.r)) why.push(proTxt(o.c, o.r));
    { const pb = pdBan(o.c); if (pb && pb.n >= 5) why.push(`banni ${pb.n} fois sur ${PRODRAFT.games} chez les pros, ${pct(pb.p1)} en phase 1`); }
    if (o.why) why.push(o.why);
    if (o.fitWhy.length) why.push('contre notre compo : ' + o.fitWhy.join(', '));
    return { ...o, why };
  });
}

// Ordre de pick dans la compo idéale : d'abord ce qui risque d'être pris ou banni, ce qui est sûr en blind, ou ce qui contre un adversaire connu
function pickOrder(ideal) {
  const mine = ourRoles(), em = enemyRoles().m;
  return ROLES.map((r, i) => ({ r, c: ideal.cs[i] })).filter(x => !mine[x.r]).map(x => {
    const steal = 5 * PROW() * proRole(x.c, x.r).pres + Math.max(0, (bwr(x.c, x.r) - 0.5) * 100) + 2 * Math.min(1, banRate(x.c) * 5);
    let pri = steal, why = [];
    // les pros prennent ce champion tôt (pick prioritaire, sûr en blind) ou le gardent pour la fin (counter)
    const ps = proSlot(x.c, x.r);
    pri += (5.5 - ps) * (proRef() ? 0.9 : 0.4);
    const pdt = pdTxt(x.c, x.r); if (pdt) why.push(pdt);
    if (em[x.r]) { pri += 4; why.push(`contre ${em[x.r].n} : ${pct(wrVs(x.c, em[x.r], x.r).wr)}`); }
    else {
      const risk = blindRisk(x.c, x.r);
      pri -= Math.max(0, (0.5 - risk.worst) * 100) * 0.8;
      why.push(`blind : ${pct(risk.exp)} en moyenne, ${pct(risk.worst)} contre ${risk.counters.map(o => o.e.n).join(', ')}`);
    }
    if (proRole(x.c, x.r).pres > 0.3) why.push(`très présent en pro (${proTxt(x.c, x.r)}) : risque d'être pris ou banni`);
    return { ...x, pri, why };
  }).sort((a, b) => b.pri - a.pri);
}

// ===== Plan de jeu =====
function laneWr(r, a, b) { return a && b ? wrVs(a, b, r).wr : null; }
function gamePlan(cs, enemyM, styHint) {
  const t = traitsSum(cs), id = identity(t);
  const ens = Object.values(enemyM || {});
  const et = ens.length ? traitsSum(ens) : null;
  const eid = et && ens.length >= 2 ? identity(et) : null;
  const lw = {}; ROLES.forEach((r, i) => lw[r] = laneWr(r, cs[i], enemyM && enemyM[r]));
  const botS = lw.adc != null && lw.sup != null ? (lw.adc + lw.sup) / 2 : null;
  const topS = lw.top;
  let strong = null;
  if (botS != null && topS != null) strong = botS - topS > 0.015 ? 'bot' : topS - botS > 0.015 ? 'top' : null;
  else if (botS != null) strong = botS >= 0.51 ? 'bot' : null;
  else if (topS != null) strong = topS >= 0.51 ? 'top' : null;
  const early = t.c < 0.9, late = t.c > 1.3;
  const tr0 = (r, k) => cs[ROLES.indexOf(r)] ? cs[ROLES.indexOf(r)].tr[TI[k]] : 0;
  const vsAss = et && et.ass >= 2, vsEngage = et && et.e >= 6, vsPoke = et && et.o >= 7, vsSplit = et && (enemyM.top && enemyM.top.tr[TI.s] >= 3);

  const RD = readComp(ens), F = RD.f, SELF = readComp(cs);
  const lines = [];
  // Style de la compo : celui choisi dans l'onglet Compos, sinon le style dominant
  const isTg = S.target && cs.every((c, k) => c && c.id === S.target.ids[k]);
  const sty = styHint || (isTg && S.target.style) || (typeof styleTags === 'function' && cs.every(Boolean) ? styleTags(cs)[0] : null) || 'teamfight';
  const carry = cs.filter(Boolean).slice().sort((a, b) => carryPow(b) - carryPow(a))[0];
  const OBJ = {
    teamfight: 'Teamfight : jouer à 5 autour des objectifs. Être premier sur la zone avec la vision (posée 60 à 90 s avant le spawn, back au moins 60 s avant), puis lancer le fight quand l’engage est prêt. Après un nashor, pousser ensemble (4-1 si le top tient sa side).',
    poke: 'Poke : prendre la zone de l’objectif en premier, puis la tenir. Une compo de poke est très forte pour garder une position déjà prise, mauvaise pour en prendre une. On use avant l’objectif, on n’engage jamais à pleine vie, et après un dragon on recule plutôt que d’aller sous leur tour.',
    s131: '1-3-1 : deux side lanes poussent, trois tiennent le mid. Avec le nashor, 1-3-1 (le mid peut aussi jouer en side). Ne pas se battre à 3 contre 5 : céder l’objectif et prendre les tours.',
    split: 'Split push (1-4) : le side laner pousse du côté opposé à l’objectif, puis regroupe quand un adversaire vient défendre (5 contre 4). À partir de 20:00, side bot : si plus de deux adversaires viennent sur lui, on lance le nashor. Le split pur est moins fort en saison 16 : regrouper 30 s avant chaque objectif.',
    early: 'Early game : prendre l’avance avant 14:00, quand l’early du top se termine. Plates, carapateur (2:55) avec la prio, premier dragon (5:00), grubs (8:00), herald (15:00). Envahir dès qu’une lane a l’avantage et finir avant 25 minutes.',
    scaling: 'Scaling : tenir l’early. Céder ce qui demande un fight à armes égales, prendre les objectifs gratuits en cross map, farmer. Les objectifs qui comptent arrivent tard : soul, nashor (20:00), ancestral.',
    f2b: 'Front to back : frontline devant, carries derrière, personne ne plonge. Arriver en premier avec la vision et laisser l’adversaire entrer dans la zone : on frappe ce qui arrive.',
    solo: `Solo carry : tout autour de ${carry ? carry.n : 'notre carry'}. C’est avec lui qu’on joue après la lane, le jungle couvre son côté et les objectifs suivent ses objets.`
  };
  let obj = OBJ[sty] || OBJ.teamfight;
  if (early && sty !== 'early') obj += ' Compo forte tôt : prendre de l’avance avant 20 minutes.';
  else if (late && sty !== 'scaling') obj += ' Compo qui scale : jouer la sécurité tôt et viser soul, nashor et ancestral.';
  if (F.nowave && t.u + t.w >= 12) obj += ' Leur compo dépush mal : on étouffe leurs vagues et on arrive sur chaque objectif avec les lanes poussées.';
  else if (F.noeng && t.o >= 4) obj += ' Ils n’ont pas d’engage : poke et siège sans prendre de risque.';
  if (F.nofront && t.d + t.e >= 6) obj += ' Ils n’ont pas de frontline : plonger directement sur leurs carries.';
  if (F.imm && t.k + t.e >= 5) obj += ` Leurs carries sont immobiles (${nm(F.imm.who)}) : chaque engage ou pick sur eux décide le fight.`;

  // Côté fort (guides jungle et ADC) : là où le jungle joue et quel objectif on prend ; l'autre côté joue safe
  if (!strong && (sty === 'split' || sty === 's131') && tr0('top', 's') >= 3) strong = 'top';
  let focus = strong === 'bot' ? 'drake' : strong === 'top' ? 'grubs' : (sty === 'scaling' ? 'safe' : 'drake');
  const focusTxt = strong === 'bot' ? 'Côté fort : bot. Le jungle fait son clear du top vers le bot pour finir sur le premier dragon (5:00), la bot pousse sa wave 30 à 45 s avant. Le top est weak side : il joue safe et garde son TP pour le dragon. Si l’adversaire répond sur les grubs (8:00), c’est le prix du dragon.' :
    strong === 'top' ? 'Côté fort : top. Le jungle fait son clear du bot vers le top, joue les grubs (8:00) puis le herald (15:00), et répond en cross map si l’adversaire prend le dragon. La bot est weak side : crash la wave 3 et back, le premier gank adverse arrive vers la wave 4.' :
    focus === 'safe' ? 'Pas de côté fort net : full clear, tracker le jungle adverse et ne prendre que les objectifs gratuits, en cross map de l’adversaire.' :
    'Pas de côté fort net : full clear et tracking ; le premier dragon (5:00) reste la priorité, il vaut en général plus que les grubs au patch actuel. La lane qui a la prio bouge en premier.';
  const focusTxt2 = focusTxt + ' En jeu, le côté fort devient celui de la lane qui prend l’avantage ; si c’est un adversaire, on le laisse et on joue de l’autre côté.';

  const role = r => cs[ROLES.indexOf(r)];
  const tr = (r, k) => role(r) ? role(r).tr[TI[k]] : 0;
  const ln = r => lw[r] == null ? '' : ` (${pct(lw[r])} estimé contre ${enemyM[r].n})`;

  // Top (guide top)
  {
    const c = role('top'); let s;
    if (lw.top != null && lw.top < 0.48) s = `Lane difficile${ln('top')} : ne conteste pas la prio, farme sous ta tour et ne meurs pas.`;
    else if (lw.top != null && lw.top > 0.52) s = `Lane favorable${ln('top')} : prends la prio dès l’arrivée des sbires et transforme-la en xp, plates ou roam.`;
    else s = `Lane équilibrée${ln('top')} : joue pour la prio sans sur-étendre.`;
    if (strong === 'bot') s += ' Weak side : garde ton TP pour le dragon (5:00), avec ta wave poussée avant.';
    else if (strong === 'top') s += ' Côté fort : pousse ta wave avant les grubs (8:00) pour bouger en premier avec ton jungle.';
    else s += ' TP prêt pour le dragon (5:00) si ta wave est poussée.';
    if (tr('top', 's') >= 3 && (sty === 'split' || sty === 's131')) s += ' Après 14:00 : side lane opposée à l’objectif, rythme push puis regroupe.';
    else if (tr('top', 'f') >= 2) s += ' En teamfight, être la frontline et absorber l’engage adverse ; le TP de flanc peut gagner un fight.';
    lines.push(['top', c, s]);
  }
  // Jungle (guide jungle)
  {
    const c = role('jgl'); let s;
    s = strong === 'bot' ? 'Clear du top vers le bot, gank ou contre-gank la bot, puis dragon à 5:00 avec le support et le mid.' :
      strong === 'top' ? 'Clear du bot vers le top, joue autour du top : grubs à 8:00 puis herald à 15:00.' :
      'Full clear (vers 3:15), tracker le jungle adverse et contester seulement les objectifs où nos lanes ont la prio.';
    s += ' Back au moins 60 s avant chaque objectif pour être premier sur la vision.';
    if (tr('jgl', 'e') >= 2) s += ' C’est toi qui lances les fights : attends que le mid et le bot puissent suivre.';
    if (tr('jgl', 'd') >= 3) s += ' Cherche les carries isolés plutôt que les fights frontaux.';
    if (sty === 'early' || early) s += ' Compo early : envahis dès qu’une lane a l’avantage.';
    if (sty === 'split') s += ' Après 20:00, si plus de deux adversaires viennent sur notre side laner, lance le nashor.';
    lines.push(['jgl', c, s]);
  }
  // Mid (guide mid)
  {
    const c = role('mid'); let s;
    s = lw.mid != null && lw.mid > 0.51 ? `Prends la prio${ln('mid')} : ta wave pousse vers leur tour, tu bouges en premier sur chaque objectif.` :
      lw.mid != null && lw.mid < 0.49 ? `Matchup difficile${ln('mid')} : farme, clear et ne bouge qu’avec ta wave poussée.` :
      `Garde la prio${ln('mid')} pour décaler en premier.`;
    s += strong === 'top' ? ' Arrive en avance aux grubs (8:00) avec la vision.' : ' Back vers 4:30 et TP pour le dragon de 5:00.';
    s += ' En mid game, joue du côté fort de la map, avec ton équipe.';
    if (tr('mid', 'o') >= 2) s += ' Poke avant d’engager les fights d’objectif.';
    if (tr('mid', 'd') >= 3) s += ' Roame sur les lanes poussées et finis les cibles isolées.';
    if (sty === 's131') s += ' Avec le nashor, tu peux jouer une side lane.';
    lines.push(['mid', c, s]);
  }
  // ADC (guide ADC)
  {
    const c = role('adc'); let s = '';
    if (tr('adc', 'h')) s = 'Hypercarry : farme en sécurité (8 sbires par minute), reste derrière la frontline et ne facecheck jamais.';
    else if (t.c < 0.9 || (c && c.tr[TI.c] === 0)) s = 'ADC de lane : joue agressif avec ton support pour les plates et la prio du dragon.';
    else s = 'Farme et prends des trades courts, place-toi pour durer en teamfight.';
    if (lw.adc != null) s += ` Lane${ln('adc')}.`;
    s += strong === 'bot' ? ' Côté fort : crash la wave 3 pour piéger, pousse 30 à 45 s avant le dragon.' : strong === 'top' ? ' Weak side : crash la wave 3 et back avant le premier gank adverse.' : '';
    s += ' Vers 14:00, swap au mid.';
    if (vsAss) s += ' Contre leurs assassins, reste collé au support et garde le flash pour eux.';
    lines.push(['adc', c, s]);
  }
  // Support (guide support)
  {
    const c = role('sup'); let s;
    if (tr('sup', 'p') >= 2 && (vsAss || sty === 'f2b' || sty === 'solo')) s = 'Peel avant tout : garde tes sorts pour ceux qui plongent sur ton carry.';
    else if (tr('sup', 'e') >= 2) s = 'Engage : lance les fights quand le jungle et le mid peuvent suivre, cherche les picks avec la vision.';
    else if (tr('sup', 'p') >= 2) s = 'Protection : garde tes sorts pour ton carry plutôt que pour engager.';
    else s = 'Poke : use la bot lane à chaque last hit adverse et garde un sort de défense.';
    s += ` Vision 60 à 90 s avant chaque objectif. Après la lane, joue avec ${carry ? carry.n : 'celui qui porte la game'}.`;
    lines.push(['sup', c, s]);
  }
  const addL = (r, txt) => { const l = lines.find(x => x[0] === r); if (l) l[2] += ' ' + txt; };
  if (F.nowave) {
    ['top', 'mid'].forEach(r => { if (tr(r, 'u') >= 2 || tr(r, 'w') >= 2) addL(r, 'Ils dépushent mal : garder ta vague poussée sous leur tour avant chaque déplacement.'); });
    addL('jgl', 'Lancer les objectifs juste après que top et mid ont poussé : ils doivent choisir entre la vague et l’objectif.');
  }
  if (F.imm) { ['jgl', 'sup', 'mid'].forEach(r => { if (tr(r, 'k') >= 2 || tr(r, 'e') >= 2) addL(r, `Cible prioritaire : ${nm(F.imm.who)}, peu mobiles.`); }); }
  if (F.hyper) addL('jgl', `Ralentir ${nm(F.hyper.who)} : gank ou dive sa lane tôt, il ne doit pas farmer tranquille.`);
  if (F.ad) ROLES.forEach(r => { if (tr(r, 'f') >= 2) addL(r, 'Armure en premier : leurs dégâts sont presque tous AD.'); });
  if (F.ap) ROLES.forEach(r => { if (tr(r, 'f') >= 2) addL(r, 'Résistance magique en premier : leurs dégâts sont presque tous AP.'); });
  if (F.split && vsSplit) addL('top', `${enemyM.top.n} va split : le tenir en side ou appeler l’aide avant de mourir.`);
  const threats = [];
  if (eid) threats.push(`Leur compo ressemble à : ${ARCH[eid.main]}.`);
  const weak = RD.list.map(k => F[k]);
  const self = SELF.list.filter(k => ['ad', 'ap', 'nowave', 'nofront', 'imm', 'noeng'].includes(k)).map(k => SELF.f[k]);
  return { id, t, obj, focusTxt: focusTxt2, sty, lines, threats, strong, weak, self };
}
