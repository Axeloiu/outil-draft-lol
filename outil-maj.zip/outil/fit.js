// ===== Profils des champions, lecture d'une compo et adéquation d'un pick à toute la partie =====
const LAB = {
  e: ['Engage', 'Capacité à lancer un fight (0 à 3)'], p: ['Peel', 'Protéger un allié, désengager'], k: ['Pick', 'Attraper un joueur isolé'],
  o: ['Poke', 'Dégâts à distance avant le fight'], d: ['Burst / dive', 'Tuer vite une cible, plonger la backline'], f: ['Frontline', 'Encaisser en première ligne'],
  s: ['Split', 'Tenir une side lane seul'], w: ['Waveclear', 'Nettoyer une vague vite (dépush)'], c: ['Courbe', '0 early, 1 mid game, 2 late'],
  h: ['Hypercarry', '1 si le champion porte la partie avec du temps et de la protection'], m: ['Mobilité', 'Dash, blink, escape'],
  g: ['Portée', '0 mêlée, 1 courte, 2 moyenne, 3 longue'], u: ['Push', 'Vitesse pour pousser une vague et taper une tour'],
  a: ['Anti-tank', '%PV, dégâts bruts, réduction de résistances'], x: ['Vs AD', 'Tient bien contre une compo AD (armure, kit)'],
  y: ['Vs AP', 'Tient bien contre une compo AP (RM, kit)'], t: ['Zone', 'Dégâts ou contrôle de zone en teamfight, follow-up']
};
const LKEYS = Object.keys(LAB);
const LMAX = k => k === 'c' ? 2 : k === 'h' ? 1 : 3;

let PROF = {};
try { PROF = JSON.parse(localStorage.getItem('draftTool.prof') || '{}') || {}; } catch (e) { PROF = {}; }
CH.forEach(c => { c.tr0 = c.tr.slice(); c.d0 = c.d; });
let RC_CACHE = {};
function applyProf() {
  CH.forEach(c => {
    const o = PROF[c.id];
    c.tr = o && Array.isArray(o.tr) && o.tr.length === c.tr0.length ? o.tr.slice() : c.tr0.slice();
    c.d = o && o.d ? o.d : c.d0;
  });
  RC_CACHE = {};
}
applyProf();
let PDBREF = null, pdbTimer = null;
function saveProf() {
  try { localStorage.setItem('draftTool.prof', JSON.stringify(PROF)); } catch (e) { }
  if (PDBREF) { clearTimeout(pdbTimer); pdbTimer = setTimeout(() => { PDBREF.set({ prof: PROF, updated: new Date().toISOString() }).catch(() => { }); }, 800); }
}
function setProf(c, k, v) {
  const o = PROF[c.id] || { tr: c.tr.slice(), d: c.d };
  if (k === 'dmg') o.d = v; else o.tr[TI[k]] = v;
  const same = o.d === c.d0 && o.tr.every((x, i) => x === c.tr0[i]);
  if (same) delete PROF[c.id]; else PROF[c.id] = o;
  applyProf(); saveProf();
}

const tv = (c, k) => c.tr[TI[k]];
const nm = l => l.map(c => c.n).join(', ');

// Lecture d'une compo (adverse en général) : faiblesses à exploiter et menaces
function readComp(es) {
  es = (es || []).filter(Boolean);
  const key = es.map(c => c.id).sort().join(',');
  if (RC_CACHE[key]) return RC_CACHE[key];
  const n = es.length, R = { n, f: {}, list: [], es };
  RC_CACHE[key] = R;
  if (n < 2) return R;
  const t = traitsSum(es);
  const add = (k, kind, txt, plan, who) => { R.f[k] = { kind, txt, plan, who: who || [] }; R.list.push(k); };
  const ad = es.filter(c => c.d === 'AD'), ap = es.filter(c => c.d === 'AP');
  if (ad.length >= 4 || (ad.length >= 3 && ap.length === 0))
    add('ad', 'weak', `Dégâts presque tous AD (${nm(ad)})`, 'L’armure suffit : tanks et champions solides contre l’AD montent en priorité, items d’armure tôt.', ad);
  if (ap.length >= 4 || (ap.length >= 3 && ad.length === 0))
    add('ap', 'weak', `Dégâts presque tous AP (${nm(ap)})`, 'La résistance magique suffit : tanks et champions solides contre l’AP montent en priorité, items de RM tôt.', ap);
  const ass = es.filter(c => tv(c, 'd') >= 3);
  if (ass.length >= 2) add('ass', 'threat', `${ass.length} menaces de burst / dive (${nm(ass)})`, 'Jouer groupés, vision sur les flancs, garder le peel et les sorts défensifs pour eux ; les carries immobiles sont en danger.', ass);
  const eng = es.filter(c => tv(c, 'e') >= 2);
  if (t.e >= 6 || eng.length >= 3) add('eng', 'threat', `Beaucoup d’engage (${nm(eng)})`, 'Ne pas facecheck, garder les sorts de désengage, se battre devant l’objectif plutôt que dans la jungle.', eng);
  const pk = es.filter(c => tv(c, 'o') >= 2);
  if (t.o >= 6 || pk.length >= 3) add('poke', 'threat', `Poke (${nm(pk)})`, 'Engager vite ou contourner : ne jamais commencer un objectif à mi-vie devant eux.', pk);
  if (n >= 3 && t.w + 0.5 * t.u <= n * 0.7) {
    const low = es.filter(c => tv(c, 'w') <= 1);
    add('nowave', 'weak', `Peu de dépush (${nm(low)})`, 'Pousser les vagues sous leurs tours avant chaque objectif : ils doivent choisir entre la vague et l’objectif. En mid game, slow push les side lanes puis rotation.', low);
  }
  if (n >= 4 && t.e === 0) add('noeng', 'weak', 'Pas d’engage fiable' + (n < 5 ? ' (à confirmer au dernier pick)' : ''), 'Ils ne peuvent pas forcer le fight : poke, siège et objectifs pris en premier, on les laisse venir.');
  if (n >= 4 && t.f === 0) add('nofront', 'weak', 'Pas de frontline' + (n < 5 ? ' (à confirmer au dernier pick)' : ''), 'Plonger directement sur leurs carries : personne n’arrête le premier qui entre.');
  const tanks = es.filter(c => tv(c, 'f') >= 2);
  if (tanks.length >= 3 || t.f >= 8) add('tank', 'threat', `Compo très solide (${nm(tanks)})`, 'Dégâts sur la durée et anti-tank (%PV, réduction d’armure) ; le burst seul ne suffira pas.', tanks);
  const car = es.filter(c => c.d !== 'T' && tv(c, 'f') <= 1);
  const imm = car.filter(c => tv(c, 'm') === 0);
  if (imm.length >= 2) add('imm', 'weak', `Carries peu mobiles (${nm(imm)})`, 'Chercher les picks sur eux avec la vision, flanquer en teamfight : un engage qui les touche gagne le fight.', imm);
  const mel = es.filter(c => tv(c, 'g') === 0);
  if (n >= 4 && mel.length >= n - 1) add('melee', 'weak', `Compo de mêlée (${nm(mel)})`, 'Kiter : reculer en tapant, peel sur la backline, ne pas les laisser coller.', mel);
  if (t.c <= 0.75 && n >= 3) add('early', 'threat', 'Compo early', 'Elle doit gagner avant 20 min : jouer safe, échanger les objectifs, ne pas donner de kills.');
  if (t.c >= 1.5 && n >= 3) add('late', 'weak', 'Compo qui scale', 'La punir avant 20 min : invades, dives, grubs et dragons tôt.');
  const sp = es.filter(c => tv(c, 's') >= 3);
  if (sp.length) add('split', 'threat', `Split push (${nm(sp)})`, 'Désigner qui défend la side lane, ou forcer l’objectif à 4 contre 4 quand il est loin.', sp);
  const hy = es.filter(c => tv(c, 'h') && tv(c, 'c') === 2 && tv(c, 'm') <= 1);
  if (hy.length) add('hyper', 'weak', `Hypercarry à neutraliser (${nm(hy)})`, 'Le cibler en priorité : pick ou dive sur lui, ou le punir en lane avant qu’il ne scale.', hy);
  return R;
}

// Adéquation d'un champion à toute la partie : compo adverse entière + picks alliés.
// Renvoie des points (même échelle que les points de winrate) et les raisons.
function compFit(c, r, allies, enemies) {
  allies = (allies || []).filter(x => x && x.id !== c.id);
  const W = readComp(enemies), F = W.f;
  const items = [];
  const add = (v, txt) => { if (Math.abs(v) >= 0.2) items.push([v, txt]); };
  const m = tv(c, 'm'), g = tv(c, 'g'), isCarry = c.d !== 'T' && tv(c, 'f') <= 1;
  if (F.ad && tv(c, 'x') >= 2) add(0.9 * (tv(c, 'x') - 1), 'solide contre leur compo AD');
  if (F.ap && tv(c, 'y') >= 2) add(0.9 * (tv(c, 'y') - 1), 'solide contre leur compo AP');
  // Menaces de burst / dive : on regarde chaque assassin, pas seulement le flag
  const ass = (W.es || []).filter(x => tv(x, 'd') >= 3);
  if (ass.length && isCarry) {
    if (m === 0) add(-1.5 * Math.min(3, ass.length), `immobile contre ${ass.length > 1 ? 'leurs menaces de dive' : 'leur menace de dive'} (${nm(ass)})`);
    else if (m === 1) add(-0.8 * Math.min(3, ass.length), `peu mobile contre ${nm(ass)}`);
    else if (m >= 3) add(0.3 * ass.length, 'assez mobile pour survivre à leur dive');
  }
  if (ass.length && tv(c, 'p') >= 2) add(0.5 * ass.length * (tv(c, 'p') - 1), `peel contre ${nm(ass)}`);
  if (F.eng) {
    const k = F.eng.who.length;
    if (isCarry && m <= 1 && g >= 2) add((m === 0 ? -0.9 : -0.5) * Math.min(3, k), `backline ${m === 0 ? 'immobile' : 'peu mobile'} face à leur engage (${nm(F.eng.who)})`);
    if (isCarry && m === 0 && ass.length) add(-1, 'aucune échappatoire contre engage + dive');
    if (tv(c, 'p') >= 2) add(0.4 * (tv(c, 'p') - 1) * Math.min(3, k), 'désengage leur engage');
    if (tv(c, 'o') >= 2 && tv(c, 'e') < 2 && m <= 1) add(-0.6, 'un poke immobile se fait engager');
  }
  if (F.poke) {
    if (tv(c, 'e') >= 2 || (tv(c, 'd') >= 2 && m >= 2)) add(1, `peut engager sur leur poke (${nm(F.poke.who)})`);
    if (g === 0 && m <= 1 && tv(c, 'e') < 2) add(-0.8, 'mêlée lent qui subit leur poke');
  }
  if (F.nowave) {
    if (tv(c, 'u') >= 2) add(0.6 * (tv(c, 'u') - 1) + 0.3, 'pousse vite : leur compo dépush mal');
    if (tv(c, 's') >= 2) add(0.4, 'met la pression en side lane');
  }
  if (F.noeng) {
    if (tv(c, 'o') >= 2) add(0.8, 'poke sans risque : ils ne peuvent pas forcer');
    if (tv(c, 'c') === 2) add(0.5, 'scale sans être forcé à se battre');
  }
  if (F.nofront && (tv(c, 'd') >= 2 || tv(c, 'k') >= 2)) add(0.8, 'plonge sur une compo sans frontline');
  if (F.tank) {
    if (tv(c, 'a') >= 2) add(0.7 * (tv(c, 'a') - 1) + 0.3, `anti-tank contre ${nm(F.tank.who)}`);
    if (tv(c, 'd') >= 3 && tv(c, 'a') === 0) add(-0.8, 'burst peu utile contre leurs tanks');
  }
  if (F.imm && (tv(c, 'k') >= 2 || tv(c, 'd') >= 3)) add(0.8, `attrape leurs carries immobiles (${nm(F.imm.who)})`);
  if (F.melee && isCarry && g >= 2 && (tv(c, 'p') >= 1 || m >= 2)) add(0.6, 'kite leur compo de mêlée');
  if (F.late && tv(c, 'c') === 0) add(0.6, 'punit tôt une compo qui scale');
  if (F.hyper && (tv(c, 'k') >= 2 || tv(c, 'd') >= 3)) add(0.5, `peut atteindre ${nm(F.hyper.who)}`);
  // Synergies avec nos picks
  if (allies.length) {
    const at = traitsSum(allies), na = allies.length, last = na >= 4 ? 1.5 : 1;
    const eng = allies.filter(x => tv(x, 'e') >= 2);
    if (eng.length && tv(c, 't') >= 2) add(0.5 * (tv(c, 't') - 1) + 0.2, `suit l’engage de ${nm(eng)}`);
    const zone = allies.filter(x => tv(x, 't') >= 2);
    if (tv(c, 'e') >= 2 && zone.length >= 2) add(0.8, `lance les fights pour ${nm(zone)}`);
    const hy = allies.filter(x => tv(x, 'h'));
    if (hy.length && tv(c, 'p') >= 2) add(0.8, `protège ${nm(hy)}`);
    if (tv(c, 'h')) { if (at.p >= 3) add(0.8, 'l’équipe peut le protéger'); else if (na >= 3) add(-0.8, 'peu de peel pour le protéger'); }
    if (na >= 2) {
      if (at.f <= 2 && tv(c, 'f') >= 2) add(Math.min(1.2, 0.4 * tv(c, 'f')) * last, 'apporte la frontline qui manque');
      if (at.e <= 1 && tv(c, 'e') >= 2) add(1 * last, 'apporte l’engage qui manque');
      if (at.w <= na * 0.8 && tv(c, 'w') >= 2) add(0.5 * last, 'apporte du waveclear');
      if (na >= 3 && at.f <= 2 && tv(c, 'f') === 0 && c.d !== 'T' && r !== 'adc' && r !== 'mid') add(-0.6 * last, 'encore un champion sans frontline');
    }
  }
  items.sort((a, b) => Math.abs(b[0]) - Math.abs(a[0]));
  let v = items.reduce((s, x) => s + x[0], 0);
  v = Math.max(-7, Math.min(6, v));
  return { v, items, why: items.slice(0, 3).map(([x, txt]) => `${x > 0 ? '+' : '−'} ${txt}`) };
}

// Synergie interne d'une compo complète (pour classer les compos)
function synergy(cs) {
  let v = 0;
  cs.forEach(c => { const f = compFit(c, null, cs, []); v += f.v; });
  return Math.max(-4, Math.min(5, v / 2));
}
