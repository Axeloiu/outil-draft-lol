#!/usr/bin/env python3
"""Mise à jour automatique de l'outil de draft (lancée chaque semaine par GitHub Actions, ou à la main).

Chaque partie n'est publiée que si elle passe son garde-fou ; sinon l'ancienne version est gardée.
  1. Catalogue des objets (Data Dragon, dernière version).
  2. Modèle Master+ : multiplicateurs des priors + côté + effet flex, appris sur les parties postérieures à la date des priors.
     Garde-fou : sur les 20 % de parties les plus récentes, le nouveau modèle (appris sur les 80 % plus anciennes) ne doit pas
     faire moins bien que le modèle en place.
  3. Parties pros (Leaguepedia, 365 derniers jours, réorientées bleu / rouge) : κ par rôle, terrain adverse, recalage avec Elo,
     formes de draft. Garde-fou : le recalage doit garder un poids positif au WR pro et un gain positif sur l'Elo seul.
  4. Objets : effets à valeur en or et durée égales, sur les parties récentes. Garde-fou : gain significatif sur les parties test.
  5. Construction du site (outil/site/index.html) et rapport (rapport.md).

Usage : python3 maj_outil.py --racine <dossier de l'archive> --rows <dossier rows> --actuel <dossier des sorties précédentes>
                             --sortie <dossier de sortie> [--pro-local fichier.json] [--catalogue-local fichier.json] [--objets oui|non]
"""
import argparse, datetime as dt, gzip, json, os, shutil, subprocess, sys, time, urllib.parse, urllib.request
import numpy as np

A = argparse.ArgumentParser()
A.add_argument('--racine', required=True); A.add_argument('--rows', required=True); A.add_argument('--actuel', default='')
A.add_argument('--sortie', required=True); A.add_argument('--pro-local', default=''); A.add_argument('--catalogue-local', default='')
A.add_argument('--objets', default='oui')
a = A.parse_args()
R = os.path.abspath(a.racine); OUT = os.path.abspath(a.sortie); os.makedirs(OUT, exist_ok=True)
CFG = json.load(open(os.path.join(R, 'maj', 'config.json')))
W = os.path.join(OUT, 'travail'); os.makedirs(W, exist_ok=True)
OUTIL = os.path.join(W, 'outil')
if os.path.exists(OUTIL): shutil.rmtree(OUTIL)
shutil.copytree(os.path.join(R, 'outil'), OUTIL)
# données publiées lors du passage précédent : c'est la référence des garde-fous
for f in ('model.json', 'pro2026.json', 'items.json', 'prodraft.json', 'proshape.json'):
    p = os.path.join(a.actuel, f) if a.actuel else ''
    if p and os.path.exists(p): shutil.copy(p, os.path.join(OUTIL, 'data', f))
# données pros publiées par un passage où la récupération Leaguepedia était incomplète : on les ignore
_p = os.path.join(OUTIL, 'data', 'pro2026.json')
if json.load(open(_p)).get('n', 0) < CFG.get('pro_min_parties', 0):
    for f in ('pro2026.json', 'prodraft.json', 'proshape.json'): shutil.copy(os.path.join(R, 'outil', 'data', f), os.path.join(OUTIL, 'data', f))
MOD = os.path.join(R, 'analyses', 'modele'); PRO = os.path.join(R, 'analyses', 'pro'); ITM = os.path.join(R, 'analyses', 'items')
REP = [f'# Mise à jour automatique du {dt.datetime.now(dt.timezone.utc):%d/%m/%Y %H:%M} UTC', '']
def log(s): print(s, flush=True); REP.append(s)
def run(cmd, out=None, env=None, cwd=None):
    e = dict(os.environ, **(env or {}))
    t0 = time.time()
    if out:
        with open(out, 'w') as fh: r = subprocess.run(cmd, stdout=fh, stderr=subprocess.PIPE, text=True, env=e, cwd=cwd)
    else: r = subprocess.run(cmd, capture_output=True, text=True, env=e, cwd=cwd)
    if r.returncode: raise RuntimeError(f'{" ".join(cmd[:3])}… a échoué : {r.stderr[-1500:]}')
    print(f'   ({time.time() - t0:.0f} s) {" ".join(os.path.basename(x) for x in cmd[:2])}', flush=True)
    return r.stdout if not out else ''
def get(url, timeout=60, tries=4):
    for k in range(tries):
        try:
            req = urllib.request.Request(url, headers={'User-Agent': 'outil-draft-lol (mise a jour hebdomadaire)'})
            with urllib.request.urlopen(req, timeout=timeout) as r: return r.read()
        except Exception as ex:
            if k == tries - 1: raise
            time.sleep(5 + 10 * k)
PY = sys.executable
statut = {}

# ---------- 1. catalogue des objets
CAT = os.path.join(W, 'catalogue.json')
try:
    if a.catalogue_local: shutil.copy(a.catalogue_local, CAT); raise StopIteration
    v = json.loads(get('https://ddragon.leagueoflegends.com/api/versions.json'))[0]
    I = json.loads(get(f'https://ddragon.leagueoflegends.com/cdn/{v}/data/fr_FR/item.json'))['data']
    items = {}
    for k, it in I.items():
        if not (it.get('maps') or {}).get('11') or not (it.get('gold') or {}).get('purchasable'): continue
        if it.get('requiredAlly') or it.get('inStore') is False or it.get('hideFromAll'): continue
        into = [x for x in it.get('into') or [] if x in I and (I[x].get('maps') or {}).get('11') and not I[x].get('requiredAlly')]
        tags = it.get('tags') or []
        c = 'C' if into else 'L'
        if 'Boots' in tags: c = 'B'
        if 'Consumable' in tags or 'Trinket' in tags: c = 'X'
        if 'Lane' in tags or 'Jungle' in tags or 'GoldPer' in tags: c = 'S' if (into or c == 'L') else c
        items[k] = {'g': it['gold']['total'], 'c': c, 'n': it['name']}
    json.dump({'v': v, 'items': items}, open(CAT, 'w'), ensure_ascii=False)
    log(f'Catalogue des objets : Data Dragon {v}, {len(items)} objets.')
except StopIteration:
    log('Catalogue des objets : fichier local.')
except Exception as ex:
    shutil.copy(os.path.join(R, 'donnees', 'objets_catalogue.json'), CAT); log(f'Catalogue des objets : Data Dragon injoignable ({ex}), catalogue de l’archive gardé.')

# ---------- 2. modèle Master+
log('\n## Modèle Master+')
PARTIES, META, COMPO = (os.path.join(W, f) for f in ('parties.json', 'meta.json', 'composantes.json'))
env = {'ROWS_DIR': os.path.abspath(a.rows), 'OUTIL_DIR': OUTIL}
try:
    run([PY, os.path.join(MOD, 'dump_parties.py'), PARTIES, META], env=env)
    run(['node', os.path.join(MOD, 'tool_clean.js'), OUTIL, PARTIES], out=COMPO)
    r = json.loads(run([PY, os.path.join(MOD, 'maj_modele.py'), COMPO, META, os.path.join(OUTIL, 'data', 'model.json'), CFG['priors_date'], str(CFG['tolerance_log_loss']), os.path.join(W, 'model_candidat.json')]))
    log(f"Parties postérieures aux priors : {r['n']} ; test sur les {r['n_test']} plus récentes : log loss en place {r['ll_actuel']:.5f}, nouveau {r['ll_nouveau']:.5f}, côté seul {r['ll_cote']:.5f}.")
    if r['accepte']:
        shutil.copy(os.path.join(W, 'model_candidat.json'), os.path.join(OUTIL, 'data', 'model.json')); statut['master'] = 'mis à jour'
        log(f"→ modèle mis à jour : poids {r['mult']}, côté bleu {r['side']:+.2f}, flex {r['flex']:+.2f}.")
    else:
        statut['master'] = 'gardé'; log('→ garde-fou : le nouveau modèle ne fait pas mieux, l’ancien est gardé.')
except Exception as ex:
    statut['master'] = 'erreur'; log(f'→ erreur, ancien modèle gardé : {ex}')

# ---------- 3. parties pros
log('\n## Parties pros')
def niveau(page):
    lg = page.split('/')[0]
    if any(x in lg for x in CFG['internationaux_niveau1']): return 1
    if lg in CFG['ligues_niveau1']: return 1
    if lg in CFG['ligues_niveau2']: return 2
    return 0
def leaguepedia():
    since = (dt.date.today() - dt.timedelta(days=CFG['pro_jours'])).isoformat()
    F = ['PB.GameId=G', 'PB.Team1=P1', 'PB.Team2=P2', 'SG.Team1=S1', 'SG.Team2=S2', 'SG.WinTeam=W', 'SG.DateTime_UTC=DT', 'SG.OverviewPage=O', 'SG.Patch=PA']
    for t in (1, 2):
        for k in range(1, 6): F += [f'PB.Team{t}Pick{k}=T{t}P{k}', f'PB.Team{t}Role{k}=T{t}R{k}', f'PB.Team{t}Ban{k}=T{t}B{k}']
    rows, off, pages = [], 0, 0
    while True:
        q = {'action': 'cargoquery', 'format': 'json', 'tables': 'PicksAndBansS7=PB,ScoreboardGames=SG', 'join_on': 'PB.GameId=SG.GameId',
             'fields': ','.join(F), 'where': f'SG.DateTime_UTC >= "{since}"', 'order_by': 'PB.GameId', 'limit': '500', 'offset': str(off)}
        for k in range(10):  # une réponse d'erreur (limite de débit…) n'est PAS la fin des données : on réessaie
            j = json.loads(get('https://lol.fandom.com/api.php?' + urllib.parse.urlencode(q)))
            if 'cargoquery' in j and 'error' not in j: break
            print(f'   Leaguepedia, page {pages + 1} : {str(j.get("error"))[:200]} ; nouvel essai dans {30 * (k + 1)} s', flush=True); time.sleep(30 * (k + 1))
        else: raise RuntimeError(f'Leaguepedia ne répond plus correctement après {pages} pages')
        L = [x['title'] for x in j['cargoquery']]
        rows += L; off += 500; pages += 1; time.sleep(3)
        if len(L) < 500: break
    print(f'   Leaguepedia : {pages} pages, {len(rows)} lignes', flush=True)
    out, inv = [], 0
    for x in rows:
        tier = niveau(x.get('O') or '')
        if not tier or not x.get('W') or not x.get('DT'): continue
        picks = [[[x.get(f'T{t}P{k}'), x.get(f'T{t}R{k}')] for k in range(1, 6)] for t in (1, 2)]
        bans = [[x.get(f'T{t}B{k}') for k in range(1, 6)] for t in (1, 2)]
        if x['P1'] == x['S1'] and x['P2'] == x['S2']: pass
        elif x['P1'] == x['S2'] and x['P2'] == x['S1']: picks, bans = picks[::-1], bans[::-1]; inv += 1
        else: continue
        w = '1' if x['W'] == x['S1'] else '2' if x['W'] == x['S2'] else ''
        out.append([x['O'], x['DT'][:10], x.get('PA') or '', w, tier, picks, bans, x['G'], x['DT'], x['S1'], x['S2']])
    return out, inv
COTES = os.path.join(W, 'pro_cotes.json')
try:
    if a.pro_local: shutil.copy(a.pro_local, COTES); log('Parties pros : fichier local.')
    else:
        G, inv = leaguepedia(); json.dump(G, open(COTES, 'w'), ensure_ascii=False)
        log(f'Parties pros : {len(G)} parties Leaguepedia sur {CFG["pro_jours"]} jours ({inv} réorientées bleu / rouge).')
        if len(G) < CFG['pro_min_parties']: raise RuntimeError(f'récupération incomplète ({len(G)} parties, minimum {CFG["pro_min_parties"]})')
    PG, LP, LV, MZ, TE, PS, CA = (os.path.join(W, f) for f in ('pro_games.json', 'lanepairs.json', 'lanevals.json', 'mesures_pro.json', 'terrain.json', 'pro_solo.json', 'calib.json'))
    run([PY, os.path.join(PRO, 'prep_pro2.py'), COTES, OUTIL, PG, LP])
    run(['node', os.path.join(MOD, 'lanepairs.js'), OUTIL, LP], out=LV)
    run([PY, os.path.join(PRO, 'mesures_pro.py'), PG, LP, LV, MZ])
    run([PY, os.path.join(PRO, 'terrain.py'), PG, OUTIL, TE])
    run([PY, os.path.join(PRO, 'score_pro.py'), PG, OUTIL, PS])
    run([PY, os.path.join(PRO, 'calib_pro.py'), PG, PS, CA])
    C = json.load(open(CA)); f = C['final']; gain = C['gains'].get('tout: Elo -> Elo + WR pro', [0])[0]
    M = json.load(open(MZ)); kres = [M['kappa'][r]['kappa_residuel'][0] for r in ('top', 'jgl', 'mid', 'adc', 'sup')]
    log(f"Recalage : modèle Master+ × {f['mt']:.3f}, WR pro × {f['mp']:.3f}, côté bleu {f['side']:+.2f} ; gain du WR pro sur l’Elo {gain:+.5f} ; κ par rôle {[round(k, 3) for k in kres]}.")
    n_pro = len(json.load(open(PG)))
    if n_pro >= CFG['pro_min_parties'] and f['mp'] > 0 and f['mt'] >= 0 and gain > 0 and all(np.isfinite(kres)) and all(-0.1 < k < 1 for k in kres):
        run([PY, os.path.join(PRO, 'export_pro.py'), PG, CA, MZ, TE, os.path.join(OUTIL, 'data', 'pro2026.json')])
        run(['node', os.path.join(PRO, 'formes_pro.js'), OUTIL, PG, '1'])
        statut['pro'] = 'mis à jour'; log('→ données pros mises à jour.')
    else:
        statut['pro'] = 'gardé'; log('→ garde-fou : recalage douteux, anciennes données pros gardées.')
except Exception as ex:
    statut['pro'] = 'erreur'; log(f'→ erreur, anciennes données pros gardées : {ex}')

# ---------- 4. objets
log('\n## Objets')
if a.objets == 'oui':
    try:
        TB, FK = os.path.join(W, 'table.npz'), os.path.join(W, 'fit_items.pkl')
        run([PY, os.path.join(ITM, 'table_items.py'), CAT, os.path.join(R, 'outil', 'collector', 'champtraits.json'), TB],
            env={'ROWS_DIR': os.path.abspath(a.rows), 'ITEMS_FENETRE_JOURS': str(CFG['objets_fenetre_jours']), 'ITEMS_MAX_PARTIES': str(CFG['objets_max_parties'])})
        run([PY, os.path.join(ITM, 'fit_items.py'), TB, os.path.join(OUTIL, 'data.js'), FK])
        S = json.load(open(FK + '.json')); g, lo = S['gain_objets'][0], S['gain_objets'][1][0]
        log(f"Effet des objets sur les parties test : gain {g:+.5f} (IC95 bas {lo:+.5f}) sur {S['n_test']} joueurs.")
        if lo > 0:
            run([PY, os.path.join(ITM, 'export_items.py'), FK, TB, CAT, os.path.join(R, 'outil', 'collector', 'champtraits.json'), os.path.join(OUTIL, 'data', 'items.json')])
            statut['objets'] = 'mis à jour'; log('→ objets mis à jour.')
        else:
            statut['objets'] = 'gardé'; log('→ garde-fou : effet non significatif, anciens objets gardés.')
    except Exception as ex:
        statut['objets'] = 'erreur'; log(f'→ erreur, anciens objets gardés : {ex}')
else:
    statut['objets'] = 'non lancé'; log('Non lancé cette fois.')

# ---------- 5. construction et sorties
log('\n## Site')
run([PY, 'build_gh.py'], cwd=OUTIL)
shutil.copy(os.path.join(OUTIL, 'site', 'index.html'), os.path.join(OUT, 'index.html'))
for f in ('model.json', 'pro2026.json', 'items.json', 'prodraft.json', 'proshape.json'):
    shutil.copy(os.path.join(OUTIL, 'data', f), os.path.join(OUT, f))
log(f"Site reconstruit. Bilan : Master+ {statut.get('master')}, pros {statut.get('pro')}, objets {statut.get('objets')}.")
log(f"Rappel : les priors u.gg / LoLalytics datent du {CFG['priors_date']} ; ils se rafraîchissent à la main (puis changer priors_date dans maj/config.json).")
open(os.path.join(OUT, 'rapport.md'), 'w').write('\n'.join(REP) + '\n')
json.dump(statut, open(os.path.join(OUT, 'statut.json'), 'w'), ensure_ascii=False)
